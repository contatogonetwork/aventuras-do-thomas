export const audioConfig = {
  effects: {
    click: "/sounds/click.mp3",
    hover: "/sounds/hover.mp3",
    success: "/sounds/success.mp3",
    error: "/sounds/error.mp3",
    back_button: "/sounds/back.mp3",
    toggle_mode: "/sounds/toggle.mp3",
    theme_select: "/sounds/theme-select.mp3",
    duration_select: "/sounds/duration-select.mp3",
    start_adventure: "/sounds/start-adventure.mp3",
    page_turn: "/sounds/page-turn.mp3",
    favorite: "/sounds/favorite.mp3",
    unfavorite: "/sounds/unfavorite.mp3",
    download: "/sounds/download.mp3",
    delete: "/sounds/delete.mp3",
    notification: "/sounds/notification.mp3",
    page_turn_back: "/sounds/page-turn-back.mp3",
    story_ready: "/sounds/story-ready.mp3",
  },
  ambient: {
    default: "/sounds/ambient/default-ambient.mp3",
    space: "/sounds/ambient/space-ambience.mp3",
    dinosaur: "/sounds/ambient/jungle-ambience.mp3",
    pirate: "/sounds/ambient/ocean-waves.mp3",
    castle: "/sounds/ambient/castle-ambience.mp3",
    jungle: "/sounds/ambient/jungle-ambience.mp3",
    ocean: "/sounds/ambient/ocean-waves.mp3",
    farm: "/sounds/ambient/farm-ambience.mp3",
    superhero: "/sounds/ambient/city-ambience.mp3",
  },
}

export function getSoundEffectPath(effectId: string): string | undefined {
  return (audioConfig.effects as any)[effectId]
}

export function getAmbientSoundPath(themeOrAmbientId: string): string | undefined {
  return (audioConfig.ambient as any)[themeOrAmbientId]
}
