export interface StoryPage {
  text: string
  backgroundUrl: string
  characters?: Array<{
    name: string
    imageUrl?: string
    position: { x: number; y: number }
    scale?: number
  }>
  decorativeElements?: Array<{
    emoji: string
    position: { x: number; y: number }
    scale?: number
  }>
}

export interface Story {
  id: string
  title: string
  theme: string
  duration: string
  audioUrl: string
  pages: StoryPage[]
}

// Histórias de exemplo
const stories: Story[] = [
  {
    id: "espaco-curta-1",
    title: "Thomás e a Aventura Espacial",
    theme: "espaco",
    duration: "curta",
    audioUrl: "/sounds/space-ambient.mp3",
    pages: [
      {
        text: "Era uma vez um menino muito curioso chamado Thomás. Ele adorava olhar para as estrelas e sonhar com aventuras no espaço.",
        backgroundUrl: "/starry-night-sky.png",
        decorativeElements: [
          { emoji: "⭐", position: { x: 20, y: 30 }, scale: 1.2 },
          { emoji: "⭐", position: { x: 70, y: 20 }, scale: 0.8 },
          { emoji: "🌟", position: { x: 40, y: 50 }, scale: 1.5 },
          { emoji: "✨", position: { x: 80, y: 60 }, scale: 1 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?key=hphbf",
            position: { x: 20, y: 60 },
            scale: 1.2,
          },
        ],
      },
      {
        text: "Um dia, enquanto brincava no quintal, Thomás viu uma luz brilhante no céu. Era uma nave espacial colorida!",
        backgroundUrl: "/placeholder.svg?key=ng6q9",
        decorativeElements: [
          { emoji: "🌳", position: { x: 10, y: 70 }, scale: 1.5 },
          { emoji: "🌳", position: { x: 80, y: 75 }, scale: 1.3 },
          { emoji: "🌼", position: { x: 30, y: 85 }, scale: 0.7 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?key=j81qk",
            position: { x: 20, y: 70 },
            scale: 1.2,
          },
          {
            name: "Nave",
            imageUrl: "/placeholder.svg?key=mdttt",
            position: { x: 70, y: 30 },
            scale: 1.5,
          },
        ],
      },
      {
        text: "A nave pousou suavemente e dela saiu um alienígena amigável chamado Zorp. 'Olá, Thomás! Quer conhecer o espaço?'",
        backgroundUrl: "/placeholder.svg?key=sozln",
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=excited cartoon boy",
            position: { x: 30, y: 70 },
            scale: 1.2,
          },
          {
            name: "Zorp",
            imageUrl: "/placeholder.svg?height=200&width=200&query=friendly cartoon alien",
            position: { x: 60, y: 65 },
            scale: 1.3,
          },
          {
            name: "Nave",
            imageUrl: "/placeholder.svg?height=200&width=200&query=colorful cartoon spaceship landed",
            position: { x: 75, y: 50 },
            scale: 1.2,
          },
        ],
      },
      {
        text: "Thomás ficou muito feliz e entrou na nave com Zorp. Juntos, eles voaram até a Lua e brincaram de pular bem alto!",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=moon surface with earth in sky",
        decorativeElements: [
          { emoji: "🌎", position: { x: 80, y: 20 }, scale: 2 },
          { emoji: "⭐", position: { x: 20, y: 15 }, scale: 0.8 },
          { emoji: "⭐", position: { x: 40, y: 25 }, scale: 1 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon boy jumping on moon",
            position: { x: 30, y: 60 },
            scale: 1.2,
          },
          {
            name: "Zorp",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon alien jumping on moon",
            position: { x: 60, y: 55 },
            scale: 1.3,
          },
        ],
      },
      {
        text: "Depois de muita diversão, Zorp levou Thomás de volta para casa. 'Volte sempre que quiser, amigo!' disse o alienígena. E Thomás sabia que teria muitas outras aventuras espaciais!",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=backyard at sunset with spaceship",
        decorativeElements: [
          { emoji: "🌳", position: { x: 10, y: 70 }, scale: 1.5 },
          { emoji: "🌳", position: { x: 80, y: 75 }, scale: 1.3 },
          { emoji: "🌙", position: { x: 85, y: 20 }, scale: 1.2 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon boy waving goodbye",
            position: { x: 20, y: 70 },
            scale: 1.2,
          },
          {
            name: "Zorp",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon alien waving from spaceship",
            position: { x: 60, y: 50 },
            scale: 1.3,
          },
        ],
      },
    ],
  },
  {
    id: "oceano-curta-1",
    title: "Thomás e os Amigos do Mar",
    theme: "oceano",
    duration: "curta",
    audioUrl: "/sounds/ocean-waves.mp3",
    pages: [
      {
        text: "Thomás adorava visitar a praia com seus pais. A água azul do mar sempre o deixava muito feliz.",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=beautiful beach with blue ocean",
        decorativeElements: [
          { emoji: "🌊", position: { x: 20, y: 80 }, scale: 1.2 },
          { emoji: "🌊", position: { x: 50, y: 85 }, scale: 1 },
          { emoji: "🌊", position: { x: 80, y: 82 }, scale: 1.3 },
          { emoji: "☁️", position: { x: 70, y: 20 }, scale: 1.5 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon boy at beach",
            position: { x: 20, y: 70 },
            scale: 1.2,
          },
        ],
      },
      {
        text: "Um dia, enquanto brincava na areia, Thomás encontrou uma concha mágica que brilhava com cores do arco-íris.",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=beach with sand castles",
        decorativeElements: [
          { emoji: "🏖️", position: { x: 80, y: 75 }, scale: 1.5 },
          { emoji: "🦀", position: { x: 30, y: 85 }, scale: 0.7 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon boy finding shell",
            position: { x: 40, y: 70 },
            scale: 1.2,
          },
          {
            name: "Concha",
            imageUrl: "/placeholder.svg?height=100&width=100&query=magical rainbow seashell",
            position: { x: 55, y: 75 },
            scale: 0.8,
          },
        ],
      },
      {
        text: "Quando Thomás colocou a concha perto do ouvido, ele ouviu uma voz: 'Olá, Thomás! Quer conhecer o fundo do mar?'",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=beach close up",
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon boy listening to seashell",
            position: { x: 50, y: 60 },
            scale: 1.3,
          },
        ],
      },
      {
        text: "De repente, a concha brilhou intensamente e Thomás se transformou em um pequeno tritão! Ele podia respirar debaixo d'água!",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=underwater scene with sunlight",
        decorativeElements: [
          { emoji: "🐠", position: { x: 20, y: 30 }, scale: 0.8 },
          { emoji: "🐠", position: { x: 70, y: 40 }, scale: 0.7 },
          { emoji: "🐙", position: { x: 80, y: 80 }, scale: 1.2 },
          { emoji: "🌿", position: { x: 10, y: 85 }, scale: 1.5 },
          { emoji: "🌿", position: { x: 90, y: 75 }, scale: 1.3 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=cartoon boy as merman",
            position: { x: 50, y: 50 },
            scale: 1.3,
          },
        ],
      },
      {
        text: "Thomás nadou pelo oceano e fez amizade com peixes coloridos, uma tartaruga sábia e até um polvo brincalhão! Foi um dia mágico que ele nunca esqueceria.",
        backgroundUrl: "/placeholder.svg?height=600&width=800&query=colorful coral reef",
        decorativeElements: [
          { emoji: "🐠", position: { x: 20, y: 30 }, scale: 0.8 },
          { emoji: "🐠", position: { x: 70, y: 40 }, scale: 0.7 },
          { emoji: "🐢", position: { x: 60, y: 70 }, scale: 1.2 },
          { emoji: "🐙", position: { x: 30, y: 60 }, scale: 1.2 },
          { emoji: "🌿", position: { x: 10, y: 85 }, scale: 1.5 },
          { emoji: "🌿", position: { x: 90, y: 75 }, scale: 1.3 },
        ],
        characters: [
          {
            name: "Thomás",
            imageUrl: "/placeholder.svg?height=200&width=200&query=happy cartoon boy merman",
            position: { x: 50, y: 50 },
            scale: 1.3,
          },
        ],
      },
    ],
  },
]

// Função para obter uma história aleatória com base no tema e duração
export function getRandomStoryByThemeAndDuration(theme: string, duration: string): Story | null {
  const filteredStories = stories.filter((story) => story.theme === theme && story.duration === duration)

  if (filteredStories.length === 0) {
    return null
  }

  const randomIndex = Math.floor(Math.random() * filteredStories.length)
  return filteredStories[randomIndex]
}

// Função para obter todas as histórias
export function getAllStories(): Story[] {
  return stories
}
