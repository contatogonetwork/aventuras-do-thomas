export function calculateParallaxTransform(
  e: MouseEvent,
  element: HTMLElement,
  intensity = 10,
  invert = false,
): string {
  const rect = element.getBoundingClientRect()
  const centerX = rect.left + rect.width / 2
  const centerY = rect.top + rect.height / 2
  const mouseX = e.clientX
  const mouseY = e.clientY

  // Calcular a distância do mouse ao centro do elemento
  const distX = mouseX - centerX
  const distY = mouseY - centerY

  // Normalizar a distância para um valor entre -1 e 1
  const maxDistX = window.innerWidth / 2
  const maxDistY = window.innerHeight / 2
  const normDistX = distX / maxDistX
  const normDistY = distY / maxDistY

  // Aplicar a intensidade e inverter se necessário
  const moveX = normDistX * intensity * (invert ? -1 : 1)
  const moveY = normDistY * intensity * (invert ? -1 : 1)

  return `translate3d(${moveX}px, ${moveY}px, 0)`
}

export function applyParallaxEffect(container: HTMLElement): () => void {
  const layers = container.querySelectorAll(".parallax-layer")

  const handleMouseMove = (e: MouseEvent) => {
    const { clientX, clientY } = e
    const centerX = window.innerWidth / 2
    const centerY = window.innerHeight / 2
    const offsetX = (clientX - centerX) / centerX
    const offsetY = (clientY - centerY) / centerY

    layers.forEach((layer) => {
      const depth = Number.parseFloat(layer.getAttribute("data-depth") || "0.1")
      const moveX = offsetX * depth * 100
      const moveY = offsetY * depth * 100
      ;(layer as HTMLElement).style.transform = `translate3d(${moveX}px, ${moveY}px, 0)`
    })
  }

  const handleDeviceOrientation = (e: DeviceOrientationEvent) => {
    if (!e.beta || !e.gamma) return

    const beta = (e.beta / 180) * 0.2
    const gamma = (e.gamma / 90) * 0.2

    layers.forEach((layer) => {
      const depth = Number.parseFloat(layer.getAttribute("data-depth") || "0.1")
      const moveX = -gamma * depth * 100
      const moveY = beta * depth * 100
      ;(layer as HTMLElement).style.transform = `translate3d(${moveX}px, ${moveY}px, 0)`
    })
  }

  // Detectar se é um dispositivo móvel
  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)

  if (isMobile && window.DeviceOrientationEvent) {
    window.addEventListener("deviceorientation", handleDeviceOrientation)
  } else {
    container.addEventListener("mousemove", handleMouseMove)
  }

  // Função de limpeza
  return () => {
    container.removeEventListener("mousemove", handleMouseMove)
    window.removeEventListener("deviceorientation", handleDeviceOrientation)
  }
}
