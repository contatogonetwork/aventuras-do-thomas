export interface Theme {
  id: string
  name: string
  icon: string
  color: string
  blurDataURL?: string
}

export interface CustomImages {
  default?: string
  [themeId: string]: string | undefined
}
