"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ThemedBackground } from "@/components/themed-background"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen, Heart } from "lucide-react"
import { motion } from "framer-motion"
import { useAudio } from "@/contexts/audio-context"
import { NightModeToggle } from "@/components/night-mode-toggle"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { Loading } from "@/components/loading"

export default function FavoritesPage() {
  const router = useRouter()
  const { playEffect } = useAudio()
  const { nightMode } = useAppContext()
  const [isLoading, setIsLoading] = useState(true)
  const [favorites, setFavorites] = useState<any[]>([])

  // Dados simulados de histórias favoritas
  const favoriteStories = [
    {
      id: "aventura-espacial",
      title: "Aventura Espacial",
      theme: "space",
      description: "Uma jornada incrível pelas estrelas com um alienígena amigável chamado Zorp.",
      createdAt: new Date("2025-04-20"),
      lastRead: new Date("2025-04-25"),
    },
    {
      id: "super-thomas",
      title: "Super Thomás",
      theme: "superhero",
      description: "Thomás ganha superpoderes e ajuda a salvar a cidade de vários perigos.",
      createdAt: new Date("2025-04-01"),
      lastRead: new Date("2025-04-18"),
    },
  ]

  useEffect(() => {
    // Simular carregamento de favoritos
    const timer = setTimeout(() => {
      setFavorites(favoriteStories)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleRemoveFavorite = (id: string) => {
    playEffect("unfavorite")
    setFavorites(favorites.filter((story) => story.id !== id))
  }

  const handleViewStory = (id: string) => {
    playEffect("click")
    router.push(`/narrativas/${id}`)
  }

  const handleBack = () => {
    playEffect("back_button")
    router.push("/")
  }

  // Função para obter a cor do tema
  const getThemeColor = (theme: string) => {
    switch (theme) {
      case "space":
        return nightMode ? "bg-indigo-900 text-indigo-100" : "bg-indigo-100 text-indigo-800"
      case "dinosaur":
        return nightMode ? "bg-green-900 text-green-100" : "bg-green-100 text-green-800"
      case "pirate":
        return nightMode ? "bg-amber-900 text-amber-100" : "bg-amber-100 text-amber-800"
      case "castle":
        return nightMode ? "bg-purple-900 text-purple-100" : "bg-purple-100 text-purple-800"
      case "jungle":
        return nightMode ? "bg-emerald-900 text-emerald-100" : "bg-emerald-100 text-emerald-800"
      case "ocean":
        return nightMode ? "bg-blue-900 text-blue-100" : "bg-blue-100 text-blue-800"
      case "farm":
        return nightMode ? "bg-yellow-900 text-yellow-100" : "bg-yellow-100 text-yellow-800"
      case "superhero":
        return nightMode ? "bg-red-900 text-red-100" : "bg-red-100 text-red-800"
      default:
        return nightMode ? "bg-gray-800 text-gray-100" : "bg-gray-100 text-gray-800"
    }
  }

  if (isLoading) {
    return <Loading />
  }

  return (
    <ThemedBackground theme="default">
      <div className="container mx-auto py-8 px-4">
        {/* Header com botão de voltar e modo noturno */}
        <div className="flex justify-between items-center mb-6">
          <motion.button
            onClick={handleBack}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-blue-600 shadow-md transition-colors"
            aria-label="Voltar"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <ArrowLeft size={24} />
          </motion.button>

          <NightModeToggle size="md" />
        </div>

        <motion.h1
          className={cn("text-3xl font-bold mb-6 text-center", nightMode ? "text-white" : "text-blue-700")}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Minhas Histórias Favoritas
        </motion.h1>

        {favorites.length === 0 ? (
          <motion.div
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <p className={cn("text-xl mb-4", nightMode ? "text-gray-300" : "text-gray-600")}>
              Você ainda não tem histórias favoritas.
            </p>
            <Button onClick={() => router.push("/narrativas")}>Explorar Histórias</Button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {favorites.map((story, index) => (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : ""}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{story.title}</CardTitle>
                        <CardDescription className={nightMode ? "text-gray-300" : ""}>
                          Última leitura: {story.lastRead.toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <Badge className={getThemeColor(story.theme)}>{story.theme}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className={cn("text-sm", nightMode ? "text-gray-300" : "text-gray-600")}>{story.description}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button
                      variant="outline"
                      onClick={() => handleRemoveFavorite(story.id)}
                      className={nightMode ? "border-gray-600 hover:bg-gray-700" : ""}
                    >
                      <Heart className="mr-2 fill-red-500 text-red-500" />
                      Remover
                    </Button>
                    <Button onClick={() => handleViewStory(story.id)}>
                      <BookOpen className="mr-2" />
                      Ver Detalhes
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </ThemedBackground>
  )
}
