"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react"
import { useAudio } from "@/contexts/audio-context"
import { ParallaxInteractiveButton } from "@/components/parallax-interactive-button"
import { Loading } from "@/components/loading"

// Dados simulados das histórias
const storyData = {
  "aventura-espacial": {
    title: "Aventura Espacial",
    theme: "space",
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aventura_espacial-eSOw8pdNOTrLXAxNl2rQgxdisW4YJq.png",
    audioUrl: "/sounds/ambient/space-ambience.mp3",
    content:
      "Era uma vez um menino muito curioso chamado Thomás. Ele adorava olhar para as estrelas e sonhar com aventuras no espaço. Uma noite, enquanto observava o céu pela janela de seu quarto, uma luz brilhante apareceu. Era um pequeno alienígena azul que convidou Thomás para uma incrível jornada pelas estrelas!",
  },
  "mundo-dinossauros": {
    title: "Mundo dos Dinossauros",
    theme: "dinosaur",
    imageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dinossauros-3gHbmK71fRHXJV5ivgOEKe1SpjZ4xW.png",
    audioUrl: "/sounds/ambient/jungle-ambience.mp3",
    content:
      "No dia do seu aniversário, Thomás ganhou um livro mágico sobre dinossauros. Quando abriu o livro, uma luz brilhante envolveu o quarto e, de repente, ele se viu em uma floresta pré-histórica! Um simpático T-Rex com chapéu de festa se aproximou e disse: 'Feliz Aniversário, Thomás! Vamos explorar o mundo dos dinossauros juntos!'",
  },
  "super-thomas": {
    title: "Super Thomás",
    theme: "superhero",
    imageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/super-heroi-eKTyYNXm96GUSbqSb08R3FGLj4TEkQ.png",
    audioUrl: "/sounds/ambient/city-ambience.mp3",
    content:
      "Thomás sempre sonhou em ser um super-herói. Um dia, enquanto brincava no parque, encontrou uma pulseira brilhante. Ao colocá-la no pulso, sentiu uma energia incrível percorrer seu corpo. De repente, podia voar! Transformado em Super Thomás, ele sobrevoou a cidade, pronto para ajudar quem precisasse. As outras crianças olhavam admiradas enquanto ele passava voando entre os prédios.",
  },
}

export default function StoryPage() {
  const params = useParams()
  const router = useRouter()
  const { playEffect, playAmbient, stopAmbient } = useAudio()
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(0)

  const storyId = params.id as string
  const story = storyData[storyId as keyof typeof storyData]

  // Simular páginas da história
  const pages = [
    { type: "intro", content: story?.content || "" },
    { type: "image", content: "" },
    {
      type: "outro",
      content:
        "E assim termina mais uma incrível aventura de Thomás! O que será que nosso herói vai descobrir na próxima história?",
    },
  ]

  useEffect(() => {
    if (!story) {
      router.push("/narrativas")
      return
    }

    // Simular carregamento
    const timer = setTimeout(() => {
      setIsLoading(false)
      playEffect("story_ready")

      // Tocar música ambiente baseada no tema
      if (story.theme) {
        playAmbient(story.theme)
      }
    }, 1500)

    return () => {
      clearTimeout(timer)
      stopAmbient()
    }
  }, [story, router, playEffect, playAmbient, stopAmbient])

  const handleNextPage = () => {
    if (currentPage < pages.length - 1) {
      setCurrentPage(currentPage + 1)
      playEffect("page_turn")
    }
  }

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1)
      playEffect("page_turn_back")
    }
  }

  const handleBack = () => {
    playEffect("back_button")
    router.push("/narrativas")
  }

  if (isLoading || !story) {
    return <Loading />
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-purple-100">
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-blue-700">{story.title}</h1>
          <button
            onClick={handleBack}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-blue-600 shadow-md transition-colors"
            aria-label="Voltar"
          >
            <ArrowLeft size={24} />
          </button>
        </div>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
          {/* Conteúdo da página atual */}
          <div className="relative min-h-[60vh]">
            {pages[currentPage].type === "image" ? (
              <div className="relative w-full h-[60vh]">
                <Image
                  src={story.imageUrl || "/placeholder.svg"}
                  alt={story.title}
                  fill
                  className="object-contain"
                  priority
                />
              </div>
            ) : (
              <div className="p-8">
                <p className="text-xl leading-relaxed">{pages[currentPage].content}</p>
              </div>
            )}
          </div>

          {/* Navegação entre páginas */}
          <div className="bg-gray-50 p-6 flex justify-between items-center">
            <ParallaxInteractiveButton
              onClick={handlePrevPage}
              disabled={currentPage === 0}
              className="px-4 py-2 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              theme={story.theme}
              soundEffect="page_turn_back"
              depth={0.08}
            >
              <ChevronLeft size={20} className="mr-1" /> Anterior
            </ParallaxInteractiveButton>

            <span className="text-sm text-gray-500">
              Página {currentPage + 1} de {pages.length}
            </span>

            <ParallaxInteractiveButton
              onClick={handleNextPage}
              disabled={currentPage === pages.length - 1}
              className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
              theme={story.theme}
              soundEffect="page_turn"
              depth={0.08}
            >
              Próxima <ChevronRight size={20} className="ml-1" />
            </ParallaxInteractiveButton>
          </div>
        </div>
      </div>
    </div>
  )
}
