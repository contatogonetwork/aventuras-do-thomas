"use client"
import { StoryLibrary } from "@/components/story-library"
import { useRouter } from "next/navigation"
import { useAppContext } from "@/contexts/app-context"
import { Toaster } from "@/components/ui/toaster"

export default function BibliotecaPage() {
  const router = useRouter()
  const { themes, savedStories, customImages, toggleFavorite, deleteStory } = useAppContext()

  const handleCreateStory = () => {
    router.push("/criar-historia")
  }

  const handlePlayStory = (storyId: number) => {
    router.push(`/narrativas/${storyId}`)
  }

  const handleToggleFavorite = (storyId: number) => {
    toggleFavorite(storyId)
  }

  const handleDeleteStory = (storyId: number) => {
    deleteStory(storyId)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col items-center">
        <StoryLibrary
          stories={savedStories}
          themes={themes}
          customImages={customImages}
          onCreateStory={handleCreateStory}
          onPlayStory={handlePlayStory}
          onToggleFavorite={handleToggleFavorite}
          onDeleteStory={handleDeleteStory}
        />
      </div>
      <Toaster />
    </div>
  )
}
