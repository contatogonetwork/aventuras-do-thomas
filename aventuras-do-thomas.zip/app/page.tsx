"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Book } from "lucide-react"
import { getRandomStoryByThemeAndDuration } from "@/data/stories-config"
import { useAudio } from "@/contexts/audio-context"
import { NightModeToggle } from "@/components/night-mode-toggle"
import { StoryView } from "@/components/story-view"
import { Loading } from "@/components/loading"
import { SpaceEnhancedBackground } from "@/components/space-enhanced-background"
import { SpaceThemeSelector } from "@/components/space-theme-selector"
import { SpaceDurationSelector } from "@/components/space-duration-selector"
import { SpaceStartAdventureButton } from "@/components/space-start-adventure-button"

export default function Page() {
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null)
  const [selectedDuration, setSelectedDuration] = useState<string | null>(null)
  const [story, setStory] = useState<any | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { playEffect } = useAudio()

  const handleThemeSelect = (theme: string) => {
    setSelectedTheme(theme)
    playEffect("theme_select")
  }

  const handleDurationSelect = (duration: string) => {
    setSelectedDuration(duration)
    playEffect("duration_select")
  }

  const handleStartAdventure = async () => {
    if (selectedTheme && selectedDuration) {
      setIsLoading(true)
      playEffect("loading_story")

      // Simular um pequeno atraso para mostrar a tela de carregamento
      setTimeout(() => {
        const newStory = getRandomStoryByThemeAndDuration(selectedTheme, selectedDuration)
        setStory(newStory)
        setIsLoading(false)
      }, 2000)
    }
  }

  const handleGoToNarrativas = () => {
    playEffect("page_turn")
    router.push("/narrativas")
  }

  if (isLoading) {
    return <Loading />
  }

  if (story) {
    return <StoryView story={story} onBack={() => setStory(null)} />
  }

  return (
    <SpaceEnhancedBackground>
      <div className="container mx-auto px-4 py-6 flex flex-col items-center min-h-screen">
        {/* Cabeçalho com logo e botão de modo noturno */}
        <div className="w-full max-w-md flex justify-between items-center mb-6">
          <motion.div
            className="flex-1"
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <motion.div
              className="relative w-full h-[120px]"
              animate={{
                y: [0, -5, 0, 5, 0],
              }}
              transition={{
                repeat: Number.POSITIVE_INFINITY,
                duration: 5,
                ease: "easeInOut",
              }}
            >
              <Image
                src="/images/space-background.png"
                alt="Aventuras do Thomás"
                width={500}
                height={150}
                className="w-full h-auto object-contain"
                priority
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <h1 className="text-4xl md:text-5xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-orange-300 to-yellow-200 drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">
                  Aventuras do
                  <br />
                  THOMÁS
                </h1>
              </div>
            </motion.div>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            <NightModeToggle size="md" />
          </motion.div>
        </div>

        {/* Seletor de Tema */}
        <SpaceThemeSelector selectedTheme={selectedTheme} onSelectTheme={handleThemeSelect} />

        {/* Seletor de Duração */}
        <SpaceDurationSelector selectedDuration={selectedDuration} onSelectDuration={handleDurationSelect} />

        {/* Botão de Começar Aventura */}
        <SpaceStartAdventureButton onClick={handleStartAdventure} disabled={!selectedTheme || !selectedDuration} />

        {/* Botão para ir para narrativas */}
        <motion.button
          className="mt-8 flex items-center px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-full shadow-lg"
          onClick={handleGoToNarrativas}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <Book size={20} className="mr-2" /> Ver Narrativas Especiais
        </motion.button>
      </div>
    </SpaceEnhancedBackground>
  )
}
