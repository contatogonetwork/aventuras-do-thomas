"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ThemedBackground } from "@/components/themed-background"
import { ArrowLeft, Save, Wand2, Book, Music, Sparkles } from "lucide-react"
import { motion } from "framer-motion"
import { useAudio } from "@/contexts/audio-context"
import { NightModeToggle } from "@/components/night-mode-toggle"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Skeleton } from "@/components/ui/skeleton"
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable"
import { Toaster } from "@/components/ui/sonner"
import { toast } from "sonner"
import { StoryEditor } from "@/components/story-editor"
import { StoryPreview } from "@/components/story-preview"
import { ImageSelector } from "@/components/image-selector"

export default function CriarHistoriaPage() {
  const router = useRouter()
  const { playEffect } = useAudio()
  const { nightMode } = useAppContext()
  const [isLoading, setIsLoading] = useState(false)
  const [storyTitle, setStoryTitle] = useState("Minha Nova Aventura")
  const [storyContent, setStoryContent] = useState("")
  const [selectedTheme, setSelectedTheme] = useState("space")
  const [selectedDuration, setSelectedDuration] = useState("medium")
  const [selectedImage, setSelectedImage] = useState("/placeholder.svg?key=ln9vi")
  const [isGenerating, setIsGenerating] = useState(false)

  const handleBack = () => {
    playEffect("back_button")
    router.push("/")
  }

  const handleSaveStory = () => {
    setIsLoading(true)
    playEffect("click")

    // Simulando o salvamento da história
    setTimeout(() => {
      setIsLoading(false)
      toast.success("História salva com sucesso!", {
        description: "Sua história foi adicionada à biblioteca.",
        action: {
          label: "Ver Biblioteca",
          onClick: () => router.push("/narrativas"),
        },
      })
    }, 1500)
  }

  const handleGenerateStory = () => {
    setIsGenerating(true)
    playEffect("story_ready")

    // Simulando a geração da história
    setTimeout(() => {
      const themes = {
        space: "Uma aventura espacial emocionante com planetas coloridos e alienígenas amigáveis.",
        superhero: "Uma história de super-heróis com poderes incríveis e vilões desafiadores.",
        dinosaur: "Uma viagem ao mundo dos dinossauros com criaturas gigantes e florestas antigas.",
        pirate: "Uma aventura em alto mar com piratas, tesouros escondidos e mapas misteriosos.",
        castle: "Uma história em um castelo encantado com príncipes, princesas e magia.",
        jungle: "Uma exploração pela selva com animais selvagens e plantas exóticas.",
        farm: "Um dia divertido na fazenda com animais adoráveis e muitas atividades.",
        ocean: "Uma aventura submarina com peixes coloridos, sereias e tesouros perdidos.",
      }

      const generatedStory = `Era uma vez um menino muito curioso chamado Thomas. ${themes[selectedTheme as keyof typeof themes]} 

Thomas estava muito animado para explorar e descobrir todos os segredos deste mundo incrível. Ele fez novos amigos, aprendeu lições importantes e viveu momentos inesquecíveis.

No final do dia, Thomas voltou para casa cheio de histórias para contar. Seus pais ouviram atentamente enquanto ele descrevia todas as suas aventuras. "Amanhã será um novo dia com novas aventuras!", pensou Thomas enquanto adormecia com um sorriso no rosto.`

      setStoryContent(generatedStory)
      setIsGenerating(false)

      toast.success("História gerada com sucesso!", {
        description: "Você pode editar a história conforme desejar.",
      })
    }, 3000)
  }

  return (
    <ThemedBackground theme={selectedTheme}>
      <Toaster />
      <div className="container mx-auto py-4 px-4 min-h-screen flex flex-col">
        {/* Header com botão de voltar e modo noturno */}
        <div className="flex justify-between items-center mb-4">
          <motion.button
            onClick={handleBack}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-blue-600 shadow-md transition-colors"
            aria-label="Voltar"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <ArrowLeft size={24} />
          </motion.button>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className={cn("bg-white/90 hover:bg-white", isLoading && "opacity-50 pointer-events-none")}
              onClick={handleSaveStory}
              disabled={isLoading || !storyContent.trim()}
            >
              {isLoading ? (
                <>
                  <Skeleton className="h-4 w-4 rounded-full mr-2" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Salvar História
                </>
              )}
            </Button>
            <NightModeToggle size="md" />
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex-1 flex flex-col"
        >
          <div className="bg-white/90 dark:bg-gray-800/90 rounded-xl shadow-lg p-4 mb-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
              <div className="flex-1">
                <Label htmlFor="story-title" className="text-sm font-medium mb-1 block">
                  Título da História
                </Label>
                <Input
                  id="story-title"
                  value={storyTitle}
                  onChange={(e) => setStoryTitle(e.target.value)}
                  className="text-lg font-bold"
                  placeholder="Digite o título da história"
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <div className="w-full sm:w-40">
                  <Label htmlFor="theme-select" className="text-sm font-medium mb-1 block">
                    Tema
                  </Label>
                  <Select value={selectedTheme} onValueChange={setSelectedTheme}>
                    <SelectTrigger id="theme-select">
                      <SelectValue placeholder="Selecione um tema" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="space">Espaço</SelectItem>
                      <SelectItem value="superhero">Super-Herói</SelectItem>
                      <SelectItem value="dinosaur">Dinossauros</SelectItem>
                      <SelectItem value="pirate">Piratas</SelectItem>
                      <SelectItem value="castle">Castelo</SelectItem>
                      <SelectItem value="jungle">Selva</SelectItem>
                      <SelectItem value="farm">Fazenda</SelectItem>
                      <SelectItem value="ocean">Oceano</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="w-full sm:w-40">
                  <Label htmlFor="duration-select" className="text-sm font-medium mb-1 block">
                    Duração
                  </Label>
                  <Select value={selectedDuration} onValueChange={setSelectedDuration}>
                    <SelectTrigger id="duration-select">
                      <SelectValue placeholder="Selecione a duração" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="short">Curta</SelectItem>
                      <SelectItem value="medium">Média</SelectItem>
                      <SelectItem value="long">Longa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="mt-auto">
                  <Button onClick={handleGenerateStory} className="w-full" disabled={isGenerating}>
                    {isGenerating ? (
                      <>
                        <Skeleton className="h-4 w-4 rounded-full mr-2" />
                        Gerando...
                      </>
                    ) : (
                      <>
                        <Wand2 className="mr-2 h-4 w-4" />
                        Gerar História
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 bg-white/90 dark:bg-gray-800/90 rounded-xl shadow-lg overflow-hidden">
            <ResizablePanelGroup direction="horizontal" className="min-h-[500px]">
              <ResizablePanel defaultSize={50} minSize={30}>
                <div className="h-full flex flex-col">
                  <div className="p-4 border-b">
                    <h2 className="text-lg font-semibold flex items-center">
                      <Book className="mr-2 h-5 w-5" />
                      Editor de História
                    </h2>
                  </div>
                  <ScrollArea className="flex-1 p-4">
                    <StoryEditor content={storyContent} onChange={setStoryContent} isLoading={isGenerating} />
                  </ScrollArea>
                </div>
              </ResizablePanel>

              <ResizableHandle withHandle />

              <ResizablePanel defaultSize={50} minSize={30}>
                <div className="h-full flex flex-col">
                  <div className="p-4 border-b">
                    <h2 className="text-lg font-semibold flex items-center">
                      <Sparkles className="mr-2 h-5 w-5" />
                      Visualização
                    </h2>
                  </div>
                  <ScrollArea className="flex-1">
                    <StoryPreview
                      title={storyTitle}
                      content={storyContent}
                      theme={selectedTheme}
                      imageUrl={selectedImage}
                    />
                  </ScrollArea>
                </div>
              </ResizablePanel>
            </ResizablePanelGroup>
          </div>

          <div className="mt-4 flex justify-between">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="bg-white/90 hover:bg-white">
                  <Image className="mr-2 h-4 w-4" />
                  Escolher Imagem
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[400px] sm:w-[540px]">
                <SheetHeader>
                  <SheetTitle>Selecionar Imagem</SheetTitle>
                  <SheetDescription>Escolha uma imagem para ilustrar sua história</SheetDescription>
                </SheetHeader>
                <Separator className="my-4" />
                <ImageSelector
                  theme={selectedTheme}
                  onSelect={(url) => {
                    setSelectedImage(url)
                    playEffect("click")
                  }}
                  selectedImage={selectedImage}
                />
              </SheetContent>
            </Sheet>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="bg-white/90 hover:bg-white">
                  <Music className="mr-2 h-4 w-4" />
                  Áudio e Efeitos
                </Button>
              </SheetTrigger>
              <SheetContent className="w-[400px] sm:w-[540px]">
                <SheetHeader>
                  <SheetTitle>Áudio e Efeitos Sonoros</SheetTitle>
                  <SheetDescription>Personalize a experiência sonora da sua história</SheetDescription>
                </SheetHeader>
                <Separator className="my-4" />
                <div className="space-y-4">
                  <div>
                    <Label>Música de Fundo</Label>
                    <Select defaultValue="theme">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma música" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="theme">Música do Tema</SelectItem>
                        <SelectItem value="adventure">Aventura</SelectItem>
                        <SelectItem value="calm">Calma</SelectItem>
                        <SelectItem value="mystery">Mistério</SelectItem>
                        <SelectItem value="happy">Alegre</SelectItem>
                        <SelectItem value="none">Sem Música</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Efeitos Sonoros</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <Button variant="outline" size="sm" onClick={() => playEffect("page_turn")}>
                        Virar Página
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => playEffect("story_ready")}>
                        História Pronta
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => playEffect("theme_select")}>
                        Selecionar Tema
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => playEffect("click")}>
                        Clique
                      </Button>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </motion.div>
      </div>
    </ThemedBackground>
  )
}
