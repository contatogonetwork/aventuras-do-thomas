"use client"

import { ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { NarrativasGallery } from "@/components/narrativas-gallery"
import { ThemedBackground } from "@/components/themed-background"
import { useAudio } from "@/contexts/audio-context"
import { motion } from "framer-motion"
import Image from "next/image"
import { NightModeToggle } from "@/components/night-mode-toggle"

export default function NarrativasPage() {
  const router = useRouter()
  const { playEffect } = useAudio()

  return (
    <ThemedBackground theme="default" playAmbient={true}>
      <div className="min-h-screen w-full">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <motion.div
              className="flex items-center"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/top_logo-x8fOkVLmBYeMuy4YLb6O68N0yVNtI8.png"
                alt="Aventuras do Thomás"
                width={200}
                height={60}
                className="h-12 w-auto"
              />
            </motion.div>

            <div className="flex items-center space-x-4">
              <NightModeToggle size="sm" />

              <motion.button
                onClick={() => {
                  playEffect("back_button")
                  router.push("/")
                }}
                className="p-2 rounded-full bg-white/80 hover:bg-white text-blue-600 shadow-md transition-colors"
                aria-label="Voltar"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <ArrowLeft size={24} />
              </motion.button>
            </div>
          </div>

          <NarrativasGallery />
        </div>
      </div>
    </ThemedBackground>
  )
}
