"use client"

import { useParams, useRouter } from "next/navigation"
import { StoryDetails } from "@/components/story-details"
import { ThemedBackground } from "@/components/themed-background"
import { useState, useEffect } from "react"
import { useAudio } from "@/contexts/audio-context"
import { ArrowLeft } from "lucide-react"
import { NightModeToggle } from "@/components/night-mode-toggle"
import { motion } from "framer-motion"
import { Loading } from "@/components/loading"

export default function StoryDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const { playEffect } = useAudio()
  const [isFavorite, setIsFavorite] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Dados simulados das histórias
  const storiesData = {
    "aventura-espacial": {
      id: "aventura-espacial",
      title: "Aventura Espacial",
      theme: "space",
      description:
        "Era uma vez um menino muito curioso chamado Thomás. Ele adorava olhar para as estrelas e sonhar com aventuras no espaço. Uma noite, enquanto observava o céu pela janela de seu quarto, uma luz brilhante apareceu. Era um pequeno alienígena azul que convidou Thomás para uma incrível jornada pelas estrelas!",
      createdAt: new Date("2025-04-20"),
      lastRead: new Date("2025-04-25"),
    },
    "mundo-dinossauros": {
      id: "mundo-dinossauros",
      title: "Mundo dos Dinossauros",
      theme: "dinosaur",
      description:
        "No dia do seu aniversário, Thomás ganhou um livro mágico sobre dinossauros. Quando abriu o livro, uma luz brilhante envolveu o quarto e, de repente, ele se viu em uma floresta pré-histórica! Um simpático T-Rex com chapéu de festa se aproximou e disse: 'Feliz Aniversário, Thomás! Vamos explorar o mundo dos dinossauros juntos!'",
      createdAt: new Date("2025-04-15"),
      lastRead: new Date("2025-04-22"),
    },
    "super-thomas": {
      id: "super-thomas",
      title: "Super Thomás",
      theme: "superhero",
      description:
        "Thomás sempre sonhou em ser um super-herói. Um dia, enquanto brincava no parque, encontrou uma pulseira brilhante. Ao colocá-la no pulso, sentiu uma energia incrível percorrer seu corpo. De repente, podia voar! Transformado em Super Thomás, ele sobrevoou a cidade, pronto para ajudar quem precisasse.",
      createdAt: new Date("2025-04-01"),
      lastRead: new Date("2025-04-18"),
    },
  }

  // Obter dados da história com base no ID
  const storyData = storiesData[params.id as keyof typeof storiesData]

  useEffect(() => {
    // Simular carregamento
    const timer = setTimeout(() => {
      setIsLoading(false)
      playEffect("story_ready")
    }, 1000)

    // Verificar se a história existe
    if (!storyData) {
      router.push("/narrativas")
    }

    // Verificar se a história está nos favoritos (simulado)
    const checkFavorites = async () => {
      // Aqui seria uma chamada para verificar favoritos
      // Por enquanto, vamos simular com um valor aleatório
      setIsFavorite(Math.random() > 0.5)
    }

    checkFavorites()

    return () => clearTimeout(timer)
  }, [params.id, router, playEffect, storyData])

  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite)
    playEffect(isFavorite ? "unfavorite" : "favorite")
  }

  const handleStartReading = () => {
    playEffect("start_adventure")
    router.push(`/story/${params.id}`)
  }

  const handleBack = () => {
    playEffect("back_button")
    router.push("/narrativas")
  }

  if (isLoading || !storyData) {
    return <Loading />
  }

  return (
    <ThemedBackground theme={storyData.theme}>
      <div className="container mx-auto py-8 px-4">
        {/* Header com botão de voltar e modo noturno */}
        <div className="flex justify-between items-center mb-6">
          <motion.button
            onClick={handleBack}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-blue-600 shadow-md transition-colors"
            aria-label="Voltar"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <ArrowLeft size={24} />
          </motion.button>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <NightModeToggle size="md" />
          </motion.div>
        </div>

        <StoryDetails
          storyId={storyData.id}
          title={storyData.title}
          theme={storyData.theme}
          description={storyData.description}
          createdAt={storyData.createdAt}
          lastRead={storyData.lastRead}
          isFavorite={isFavorite}
          onToggleFavorite={handleToggleFavorite}
          onStartReading={handleStartReading}
        />
      </div>
    </ThemedBackground>
  )
}
