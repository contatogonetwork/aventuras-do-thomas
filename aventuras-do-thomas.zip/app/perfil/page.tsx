"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ThemedBackground } from "@/components/themed-background"
import { ArrowLeft, User, Settings, BookOpen, Bell, Volume2 } from "lucide-react"
import { motion } from "framer-motion"
import { useAudio } from "@/contexts/audio-context"
import { NightModeToggle } from "@/components/night-mode-toggle"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Progress } from "@/components/ui/progress"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"

export default function ProfilePage() {
  const router = useRouter()
  const { playEffect, effectsVolume, ambientVolume, setEffectsVolume, setAmbientVolume } = useAudio()
  const { nightMode, setNightMode } = useAppContext()
  const [childName, setChildName] = useState("Thomás")
  const [childAge, setChildAge] = useState("5")
  const [avatar, setAvatar] = useState("/placeholder.svg?key=qeoiy")
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)
  const [voicePreference, setVoicePreference] = useState("infantil")
  const [readingLevel, setReadingLevel] = useState(60)

  const handleBack = () => {
    playEffect("back_button")
    router.push("/")
  }

  const handleSaveProfile = () => {
    playEffect("click")
    // Aqui seria implementada a lógica para salvar o perfil
    alert("Perfil salvo com sucesso!")
  }

  const achievements = [
    { id: 1, name: "Explorador Espacial", description: "Completou 3 histórias do espaço", icon: "🚀", completed: true },
    {
      id: 2,
      name: "Amigo dos Dinossauros",
      description: "Completou 2 histórias de dinossauros",
      icon: "🦖",
      completed: true,
    },
    { id: 3, name: "Super Herói", description: "Completou 1 história de super-herói", icon: "🦸‍♂️", completed: true },
    { id: 4, name: "Pirata Destemido", description: "Complete 3 histórias de piratas", icon: "🏴‍☠️", completed: false },
    { id: 5, name: "Aventureiro da Selva", description: "Complete 3 histórias da selva", icon: "🌴", completed: false },
  ]

  const recentStories = [
    { id: 1, title: "Aventura Espacial", date: "25/04/2025", progress: 100, theme: "space" },
    { id: 2, title: "Mundo dos Dinossauros", date: "22/04/2025", progress: 100, theme: "dinosaur" },
    { id: 3, title: "Super Thomás", date: "18/04/2025", progress: 100, theme: "superhero" },
    { id: 4, title: "Piratas do Caribe", date: "15/04/2025", progress: 50, theme: "pirate" },
  ]

  // Função para obter a cor do tema
  const getThemeColor = (theme: string) => {
    switch (theme) {
      case "space":
        return nightMode ? "bg-indigo-900 text-indigo-100" : "bg-indigo-100 text-indigo-800"
      case "dinosaur":
        return nightMode ? "bg-green-900 text-green-100" : "bg-green-100 text-green-800"
      case "pirate":
        return nightMode ? "bg-amber-900 text-amber-100" : "bg-amber-100 text-amber-800"
      case "castle":
        return nightMode ? "bg-purple-900 text-purple-100" : "bg-purple-100 text-purple-800"
      case "jungle":
        return nightMode ? "bg-emerald-900 text-emerald-100" : "bg-emerald-100 text-emerald-800"
      case "ocean":
        return nightMode ? "bg-blue-900 text-blue-100" : "bg-blue-100 text-blue-800"
      case "farm":
        return nightMode ? "bg-yellow-900 text-yellow-100" : "bg-yellow-100 text-yellow-800"
      case "superhero":
        return nightMode ? "bg-red-900 text-red-100" : "bg-red-100 text-red-800"
      default:
        return nightMode ? "bg-gray-800 text-gray-100" : "bg-gray-100 text-gray-800"
    }
  }

  return (
    <ThemedBackground theme="default">
      <div className="container mx-auto py-8 px-4">
        {/* Header com botão de voltar e modo noturno */}
        <div className="flex justify-between items-center mb-6">
          <motion.button
            onClick={handleBack}
            className="p-2 rounded-full bg-white/80 hover:bg-white text-blue-600 shadow-md transition-colors"
            aria-label="Voltar"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <ArrowLeft size={24} />
          </motion.button>

          <NightModeToggle size="md" />
        </div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Tabs defaultValue="perfil" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="perfil" onClick={() => playEffect("click")}>
                <User className="mr-2 h-4 w-4" /> Perfil
              </TabsTrigger>
              <TabsTrigger value="progresso" onClick={() => playEffect("click")}>
                <BookOpen className="mr-2 h-4 w-4" /> Progresso
              </TabsTrigger>
              <TabsTrigger value="configuracoes" onClick={() => playEffect("click")}>
                <Settings className="mr-2 h-4 w-4" /> Configurações
              </TabsTrigger>
            </TabsList>

            {/* Aba de Perfil */}
            <TabsContent value="perfil">
              <Card className={nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : ""}>
                <CardHeader>
                  <CardTitle>Perfil do Aventureiro</CardTitle>
                  <CardDescription className={nightMode ? "text-gray-300" : ""}>
                    Personalize o perfil do seu pequeno aventureiro.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="flex flex-col items-center space-y-4">
                      <div className="relative">
                        <Avatar className="w-32 h-32 border-4 border-blue-500">
                          <AvatarImage src={avatar || "/placeholder.svg"} alt="Avatar" />
                          <AvatarFallback>TH</AvatarFallback>
                        </Avatar>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="absolute bottom-0 right-0 rounded-full"
                              onClick={() => playEffect("click")}
                            >
                              <Settings className="h-4 w-4" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className={nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : ""}>
                            <div className="space-y-2">
                              <h4 className="font-medium">Escolha um avatar</h4>
                              <div className="flex flex-wrap gap-2">
                                {[
                                  "/placeholder.svg?key=u0ywi",
                                  "/placeholder.svg?key=fkn0g",
                                  "/placeholder.svg?key=7e3vj",
                                  "/placeholder.svg?key=botk8",
                                ].map((src, i) => (
                                  <Avatar
                                    key={i}
                                    className="w-12 h-12 cursor-pointer hover:ring-2 hover:ring-blue-500"
                                    onClick={() => {
                                      setAvatar(src)
                                      playEffect("click")
                                    }}
                                  >
                                    <AvatarImage src={src || "/placeholder.svg"} alt={`Avatar ${i + 1}`} />
                                  </Avatar>
                                ))}
                              </div>
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="flex flex-wrap justify-center gap-2">
                        {achievements
                          .filter((a) => a.completed)
                          .slice(0, 3)
                          .map((achievement) => (
                            <HoverCard key={achievement.id}>
                              <HoverCardTrigger asChild>
                                <Badge
                                  variant="outline"
                                  className={cn(
                                    "text-lg py-1 cursor-help",
                                    nightMode ? "border-gray-600" : "border-gray-300",
                                  )}
                                >
                                  {achievement.icon}
                                </Badge>
                              </HoverCardTrigger>
                              <HoverCardContent
                                className={nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : ""}
                              >
                                <div className="flex flex-col space-y-1">
                                  <h4 className="font-semibold">{achievement.name}</h4>
                                  <p className="text-sm">{achievement.description}</p>
                                </div>
                              </HoverCardContent>
                            </HoverCard>
                          ))}
                      </div>
                    </div>

                    <div className="flex-1 space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="name" className={nightMode ? "text-gray-200" : ""}>
                          Nome
                        </Label>
                        <Input
                          id="name"
                          value={childName}
                          onChange={(e) => setChildName(e.target.value)}
                          className={nightMode ? "bg-gray-700 border-gray-600 text-gray-100" : ""}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="age" className={nightMode ? "text-gray-200" : ""}>
                          Idade
                        </Label>
                        <Input
                          id="age"
                          value={childAge}
                          onChange={(e) => setChildAge(e.target.value)}
                          type="number"
                          min="3"
                          max="10"
                          className={nightMode ? "bg-gray-700 border-gray-600 text-gray-100" : ""}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className={nightMode ? "text-gray-200" : ""}>Voz do Narrador</Label>
                        <RadioGroup
                          value={voicePreference}
                          onValueChange={(value) => {
                            setVoicePreference(value)
                            playEffect("click")
                          }}
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="infantil" id="infantil" />
                            <Label htmlFor="infantil" className={nightMode ? "text-gray-200" : ""}>
                              Infantil
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="adulto" id="adulto" />
                            <Label htmlFor="adulto" className={nightMode ? "text-gray-200" : ""}>
                              Adulto
                            </Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="robo" id="robo" />
                            <Label htmlFor="robo" className={nightMode ? "text-gray-200" : ""}>
                              Robô
                            </Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveProfile}>Salvar Perfil</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Aba de Progresso */}
            <TabsContent value="progresso">
              <Card className={nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : ""}>
                <CardHeader>
                  <CardTitle>Progresso de Leitura</CardTitle>
                  <CardDescription className={nightMode ? "text-gray-300" : ""}>
                    Acompanhe o progresso de leitura e conquistas.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label className={nightMode ? "text-gray-200" : ""}>Nível de Leitura</Label>
                      <span className={nightMode ? "text-gray-300" : "text-gray-500"}>
                        Nível {Math.floor(readingLevel / 10)}
                      </span>
                    </div>
                    <Progress value={readingLevel} className="h-2" />
                    <p className={cn("text-sm", nightMode ? "text-gray-300" : "text-gray-500")}>
                      Continue lendo para aumentar seu nível!
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Histórias Recentes</h3>
                    <div className="space-y-4">
                      {recentStories.map((story) => (
                        <div key={story.id} className={cn("p-4 rounded-lg", nightMode ? "bg-gray-700" : "bg-gray-50")}>
                          <div className="flex justify-between items-center mb-2">
                            <div className="flex items-center gap-2">
                              <Badge className={getThemeColor(story.theme)}>{story.theme}</Badge>
                              <h4 className="font-medium">{story.title}</h4>
                            </div>
                            <span className={cn("text-sm", nightMode ? "text-gray-300" : "text-gray-500")}>
                              {story.date}
                            </span>
                          </div>
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>Progresso</span>
                              <span>{story.progress}%</span>
                            </div>
                            <Progress value={story.progress} className="h-2" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Conquistas</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {achievements.map((achievement) => (
                        <div
                          key={achievement.id}
                          className={cn(
                            "p-4 rounded-lg flex items-center gap-4",
                            achievement.completed
                              ? nightMode
                                ? "bg-blue-900/20"
                                : "bg-blue-50"
                              : nightMode
                                ? "bg-gray-700"
                                : "bg-gray-50",
                          )}
                        >
                          <div
                            className={cn(
                              "w-12 h-12 rounded-full flex items-center justify-center text-2xl",
                              achievement.completed
                                ? nightMode
                                  ? "bg-blue-900"
                                  : "bg-blue-100"
                                : nightMode
                                  ? "bg-gray-600"
                                  : "bg-gray-200",
                            )}
                          >
                            {achievement.icon}
                          </div>
                          <div>
                            <h4 className="font-medium">{achievement.name}</h4>
                            <p className={cn("text-sm", nightMode ? "text-gray-300" : "text-gray-500")}>
                              {achievement.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Aba de Configurações */}
            <TabsContent value="configuracoes">
              <Card className={nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : ""}>
                <CardHeader>
                  <CardTitle>Configurações</CardTitle>
                  <CardDescription className={nightMode ? "text-gray-300" : ""}>
                    Personalize a experiência do aplicativo.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Aparência</h3>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className={nightMode ? "text-gray-200" : ""}>Modo Noturno</Label>
                        <p className={cn("text-sm", nightMode ? "text-gray-300" : "text-gray-500")}>
                          Ative para usar cores mais escuras.
                        </p>
                      </div>
                      <Switch
                        checked={nightMode}
                        onCheckedChange={(checked) => {
                          setNightMode(checked)
                          playEffect("toggle_mode")
                        }}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Som</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="effects-volume" className={nightMode ? "text-gray-200" : ""}>
                            <Volume2 className="h-4 w-4 inline mr-2" /> Volume dos Efeitos
                          </Label>
                          <span className={nightMode ? "text-gray-300" : "text-gray-500"}>
                            {Math.round(effectsVolume * 100)}%
                          </span>
                        </div>
                        <Slider
                          id="effects-volume"
                          value={[effectsVolume * 100]}
                          min={0}
                          max={100}
                          step={1}
                          onValueChange={(value) => setEffectsVolume(value[0] / 100)}
                        />
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <Label htmlFor="ambient-volume" className={nightMode ? "text-gray-200" : ""}>
                            <Volume2 className="h-4 w-4 inline mr-2" /> Volume da Música Ambiente
                          </Label>
                          <span className={nightMode ? "text-gray-300" : "text-gray-500"}>
                            {Math.round(ambientVolume * 100)}%
                          </span>
                        </div>
                        <Slider
                          id="ambient-volume"
                          value={[ambientVolume * 100]}
                          min={0}
                          max={100}
                          step={1}
                          onValueChange={(value) => setAmbientVolume(value[0] / 100)}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Notificações</h3>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <div className="flex items-center">
                          <Bell className="h-4 w-4 mr-2" />
                          <Label className={nightMode ? "text-gray-200" : ""}>Notificações de Novas Histórias</Label>
                        </div>
                        <p className={cn("text-sm", nightMode ? "text-gray-300" : "text-gray-500")}>
                          Receba alertas quando novas histórias forem adicionadas.
                        </p>
                      </div>
                      <Switch
                        checked={notificationsEnabled}
                        onCheckedChange={(checked) => {
                          setNotificationsEnabled(checked)
                          playEffect("click")
                        }}
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveProfile}>Salvar Configurações</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </ThemedBackground>
  )
}
