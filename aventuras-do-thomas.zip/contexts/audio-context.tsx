"use client"

import { createContext, useContext, useState, useEffect, useCallback, useRef, type ReactNode } from "react"
import { getSoundEffectPath, getAmbientSoundPath } from "@/data/audio-config"

interface AudioContextType {
  playEffect: (effectId: string) => boolean
  playAmbient: (themeOrAmbientId: string) => boolean
  stopAmbient: () => boolean
  stopAllSounds: () => boolean
  currentAmbient: string | null
  userInteracted: boolean
  isReady: {
    ambient: boolean
    effects: boolean
  }
  isPlaying: {
    ambient: boolean
  }
  effectsVolume: number
  ambientVolume: number
  setEffectsVolume: (volume: number) => void
  setAmbientVolume: (volume: number) => void
  enabled: boolean
  setEnabled: (enabled: boolean) => void
}

const AudioContext = createContext<AudioContextType | undefined>(undefined)

// Implementação simplificada do gerenciador de áudio
function useAudioManager(options: { effectsVolume: number; ambientVolume: number; enabled: boolean }) {
  const { effectsVolume, ambientVolume, enabled } = options
  const [userInteracted, setUserInteracted] = useState(false)
  const [currentAmbient, setCurrentAmbient] = useState<string | null>(null)
  const ambientAudioRef = useRef<HTMLAudioElement | null>(null)
  const [isReady, setIsReady] = useState({ ambient: false, effects: false })
  const [isPlaying, setIsPlaying] = useState({ ambient: false })
  const currentAmbientIdRef = useRef<string | null>(null)

  // Detectar interação do usuário
  useEffect(() => {
    const handleInteraction = () => {
      setUserInteracted(true)
    }

    window.addEventListener("click", handleInteraction)
    window.addEventListener("touchstart", handleInteraction)

    return () => {
      window.removeEventListener("click", handleInteraction)
      window.removeEventListener("touchstart", handleInteraction)
    }
  }, [])

  // Função para tocar efeito sonoro
  const playEffect = useCallback(
    (effectId: string): boolean => {
      if (!enabled) return false

      try {
        const soundPath = getSoundEffectPath(effectId)
        if (!soundPath) return false

        const audio = new Audio(soundPath)
        audio.volume = effectsVolume
        audio.play().catch((e) => console.log("Erro ao reproduzir efeito sonoro:", e))
        return true
      } catch (error) {
        console.error("Erro ao tocar efeito sonoro:", error)
        return false
      }
    },
    [effectsVolume, enabled],
  )

  // Função para tocar som ambiente
  const playAmbient = useCallback(
    (themeOrAmbientId: string): boolean => {
      if (!enabled) return false

      // Evitar reproduzir o mesmo som ambiente novamente
      if (
        currentAmbientIdRef.current === themeOrAmbientId &&
        ambientAudioRef.current &&
        !ambientAudioRef.current.paused
      ) {
        return true
      }

      try {
        // Parar o som ambiente atual se existir
        if (ambientAudioRef.current) {
          ambientAudioRef.current.pause()
          ambientAudioRef.current.currentTime = 0
        }

        const soundPath = getAmbientSoundPath(themeOrAmbientId)
        if (!soundPath) return false

        const audio = new Audio(soundPath)
        audio.volume = ambientVolume
        audio.loop = true

        // Tentar reproduzir o áudio
        audio
          .play()
          .then(() => {
            setIsPlaying((prev) => ({ ...prev, ambient: true }))
            setIsReady((prev) => ({ ...prev, ambient: true }))
          })
          .catch((e) => {
            console.log("Erro ao reproduzir som ambiente:", e)
            setIsPlaying((prev) => ({ ...prev, ambient: false }))
          })

        ambientAudioRef.current = audio
        currentAmbientIdRef.current = themeOrAmbientId
        setCurrentAmbient(themeOrAmbientId)
        return true
      } catch (error) {
        console.error("Erro ao tocar som ambiente:", error)
        return false
      }
    },
    [ambientVolume, enabled],
  )

  // Função para parar som ambiente
  const stopAmbient = useCallback((): boolean => {
    if (ambientAudioRef.current) {
      ambientAudioRef.current.pause()
      ambientAudioRef.current.currentTime = 0
      setIsPlaying((prev) => ({ ...prev, ambient: false }))
      setCurrentAmbient(null)
      currentAmbientIdRef.current = null
      return true
    }
    return false
  }, [])

  // Função para parar todos os sons
  const stopAllSounds = useCallback((): boolean => {
    stopAmbient()
    return true
  }, [stopAmbient])

  // Atualizar volume do som ambiente quando mudar
  useEffect(() => {
    if (ambientAudioRef.current) {
      ambientAudioRef.current.volume = ambientVolume
    }
  }, [ambientVolume])

  // Limpar recursos ao desmontar
  useEffect(() => {
    return () => {
      if (ambientAudioRef.current) {
        ambientAudioRef.current.pause()
        ambientAudioRef.current.src = ""
      }
    }
  }, [])

  return {
    playEffect,
    playAmbient,
    stopAmbient,
    stopAllSounds,
    currentAmbient,
    userInteracted,
    isReady,
    isPlaying,
  }
}

export function AudioProvider({ children }: { children: ReactNode }) {
  // Estado para volumes e habilitação
  const [effectsVolume, setEffectsVolume] = useState(0.7)
  const [ambientVolume, setAmbientVolume] = useState(0.3)
  const [enabled, setEnabled] = useState(true)

  // Carregar configurações do localStorage
  useEffect(() => {
    try {
      const savedEffectsVolume = localStorage.getItem("effectsVolume")
      const savedAmbientVolume = localStorage.getItem("ambientVolume")
      const savedEnabled = localStorage.getItem("audioEnabled")

      if (savedEffectsVolume) setEffectsVolume(Number.parseFloat(savedEffectsVolume))
      if (savedAmbientVolume) setAmbientVolume(Number.parseFloat(savedAmbientVolume))
      if (savedEnabled) setEnabled(savedEnabled === "true")
    } catch (err) {
      console.warn("Erro ao carregar configurações de áudio:", err)
    }
  }, [])

  // Salvar configurações no localStorage quando mudarem
  useEffect(() => {
    try {
      localStorage.setItem("effectsVolume", effectsVolume.toString())
      localStorage.setItem("ambientVolume", ambientVolume.toString())
      localStorage.setItem("audioEnabled", enabled.toString())
    } catch (err) {
      console.warn("Erro ao salvar configurações de áudio:", err)
    }
  }, [effectsVolume, ambientVolume, enabled])

  // Usar o gerenciador de áudio
  const audioManager = useAudioManager({
    effectsVolume,
    ambientVolume,
    enabled,
  })

  // Função para definir volume de efeitos
  const handleSetEffectsVolume = useCallback((volume: number) => {
    setEffectsVolume(volume)
  }, [])

  // Função para definir volume ambiente
  const handleSetAmbientVolume = useCallback((volume: number) => {
    setAmbientVolume(volume)
  }, [])

  // Função para definir habilitação
  const handleSetEnabled = useCallback(
    (isEnabled: boolean) => {
      setEnabled(isEnabled)

      // Se desabilitado, parar todos os sons
      if (!isEnabled) {
        audioManager.stopAllSounds()
      }
    },
    [audioManager],
  )

  const value = {
    ...audioManager,
    effectsVolume,
    ambientVolume,
    setEffectsVolume: handleSetEffectsVolume,
    setAmbientVolume: handleSetAmbientVolume,
    enabled,
    setEnabled: handleSetEnabled,
  }

  return <AudioContext.Provider value={value}>{children}</AudioContext.Provider>
}

export function useAudio() {
  const context = useContext(AudioContext)

  if (context === undefined) {
    throw new Error("useAudio deve ser usado dentro de um AudioProvider")
  }

  return context
}
