"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback } from "react"
import { useLocalStorage } from "@/hooks/use-local-storage"
import type { Theme, Duration, Story, CustomImages } from "@/types/app-types"
import { AudioProvider } from "@/contexts/audio-context"
import { useEffect } from "react"

// Default custom images
const defaultCustomImages: CustomImages = {
  superhero: "/placeholder.svg?key=1t6ym",
  space: "/placeholder.svg?key=dagsh",
  dinosaur: "/placeholder.svg?key=vzv48",
  pirate: "/placeholder.svg?key=u6x17",
  castle: "/placeholder.svg?key=ehv53",
  jungle: "/placeholder.svg?height=64&width=64&query=jungle%20cartoon",
  ocean: "/placeholder.svg?height=64&width=64&query=ocean%20cartoon",
  farm: "/placeholder.svg?height=64&width=64&query=farm%20cartoon",
}

// Context type
interface AppContextType {
  childName: string
  setChildName: (name: string) => void
  selectedTheme: string | null
  setSelectedTheme: (theme: string | null) => void
  selectedDuration: string | null
  setSelectedDuration: (duration: string | null) => void
  storyContent: string | null
  setStoryContent: (content: string | null) => void
  themes: Theme[]
  durations: Duration[]
  customImages: CustomImages
  setCustomImages: (images: CustomImages) => void
  savedStories: Story[]
  toggleFavorite: (storyId: number) => void
  deleteStory: (storyId: number) => void
  addStory: (story: Story) => void
  nightMode: boolean
  setNightMode: (mode: boolean) => void
}

// Create context
const AppContext = createContext<AppContextType | undefined>(undefined)

// Provider component
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [childName, setChildName] = useState<string>("Thomas")
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null)
  const [selectedDuration, setSelectedDuration] = useState<string | null>(null)
  const [storyContent, setStoryContent] = useState<string | null>(null)

  // Local storage
  const [customImages, setCustomImages, isStorageAvailable] = useLocalStorage<CustomImages>(
    "thomasImages",
    defaultCustomImages,
  )

  // Themes data
  const themes: Theme[] = [
    { id: "superhero", name: "Super-Herói", icon: "🦸‍♂️", color: "#ef4444", bgColor: "bg-red-100" },
    { id: "space", name: "Espaço", icon: "🚀", color: "#6366f1", bgColor: "bg-indigo-100" },
    { id: "dinosaur", name: "Dinossauros", icon: "🦖", color: "#22c55e", bgColor: "bg-green-100" },
    { id: "pirate", name: "Piratas", icon: "🏴‍☠️", color: "#b45309", bgColor: "bg-amber-100" },
    { id: "castle", name: "Castelo", icon: "🏰", color: "#ec4899", bgColor: "bg-pink-100" },
    { id: "jungle", name: "Selva", icon: "🦁", color: "#eab308", bgColor: "bg-yellow-100" },
    { id: "ocean", name: "Oceano", icon: "🐬", color: "#3b82f6", bgColor: "bg-blue-100" },
    { id: "farm", name: "Fazenda", icon: "🐄", color: "#16a34a", bgColor: "bg-green-100" },
  ]

  // Duration options
  const durations: Duration[] = [
    { id: "short", name: "Curta (2 min)", color: "bg-blue-400" },
    { id: "medium", name: "Média (5 min)", color: "bg-blue-500" },
    { id: "long", name: "Longa (10 min)", color: "bg-blue-600" },
  ]

  // Saved stories (mock data - would be replaced with real data in a production app)
  const [savedStories, setSavedStories] = useLocalStorage<Story[]>("savedStories", [
    { id: 1, theme: "superhero", title: "O Super-Herói Thomás", date: "25/04/2025", favorite: true },
    { id: 2, theme: "space", title: "Thomás no Espaço", date: "24/04/2025", favorite: false },
    { id: 3, theme: "dinosaur", title: "Thomás e os Dinossauros", date: "23/04/2025", favorite: true },
  ])

  // Toggle favorite status
  const toggleFavorite = useCallback(
    (storyId: number) => {
      setSavedStories((prevStories) =>
        prevStories.map((story) => (story.id === storyId ? { ...story, favorite: !story.favorite } : story)),
      )
    },
    [setSavedStories],
  )

  // Delete story
  const deleteStory = useCallback(
    (storyId: number) => {
      setSavedStories((prevStories) => prevStories.filter((story) => story.id !== storyId))
    },
    [setSavedStories],
  )

  // Add new story
  const addStory = useCallback(
    (story: Story) => {
      setSavedStories((prevStories) => [...prevStories, story])
    },
    [setSavedStories],
  )

  // Function to generate a story
  const generateStory = useCallback((theme: string, name: string, duration: string) => {
    // Generate story content based on selected theme
    // This is a placeholder - in a real app, this would be more sophisticated
    return `Era uma vez um menino chamado ${name} que adorava aventuras. 
    Um dia, ele encontrou um portal mágico que o levou para um mundo de ${
      theme === "superhero"
        ? "super-heróis"
        : theme === "space"
          ? "aventuras espaciais"
          : theme === "dinosaur"
            ? "dinossauros"
            : theme === "pirate"
              ? "piratas"
              : theme === "castle"
                ? "castelos encantados"
                : theme === "jungle"
                  ? "selvas misteriosas"
                  : theme === "ocean"
                    ? "oceanos profundos"
                    : "fazendas mágicas"
    }. 
    ${name} viveu muitas aventuras incríveis e fez novos amigos.`
  }, [])

  // Usar localStorage para persistir o modo noturno
  const [nightMode, setNightMode] = useLocalStorage("nightMode", false)

  // Aplicar classe ao body para modo noturno
  useEffect(() => {
    if (nightMode) {
      document.documentElement.classList.add("dark-mode")
    } else {
      document.documentElement.classList.remove("dark-mode")
    }
  }, [nightMode])

  const value = {
    childName,
    setChildName,
    selectedTheme,
    setSelectedTheme,
    selectedDuration,
    setSelectedDuration,
    storyContent,
    setStoryContent,
    themes,
    durations,
    customImages,
    setCustomImages,
    savedStories,
    toggleFavorite,
    deleteStory,
    addStory,
    // Settings
    nightMode,
    setNightMode,
  }

  return (
    <AudioProvider>
      <AppContext.Provider value={value}>{children}</AppContext.Provider>
    </AudioProvider>
  )
}

// Hook for using the context
export function useAppContext() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider")
  }
  return context
}
