"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface FloatingParticlesProps {
  type: "stars" | "bubbles" | "leaves" | "confetti"
  count?: number
  intensity?: number
}

interface Particle {
  id: number
  x: number
  y: number
  size: number
  duration: number
  delay: number
  opacity: number
  color: string
}

export function FloatingParticles({ type = "stars", count = 30, intensity = 1 }: FloatingParticlesProps) {
  const [particles, setParticles] = useState<Particle[]>([])

  useEffect(() => {
    const generateParticles = () => {
      const newParticles: Particle[] = []
      const adjustedCount = Math.floor(count * intensity)

      for (let i = 0; i < adjustedCount; i++) {
        const particle: Particle = {
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          size: getRandomSize(type),
          duration: getRandomDuration(type),
          delay: Math.random() * 5,
          opacity: getRandomOpacity(type),
          color: getRandomColor(type),
        }
        newParticles.push(particle)
      }
      setParticles(newParticles)
    }

    generateParticles()
  }, [type, count, intensity])

  const getRandomSize = (type: string): number => {
    switch (type) {
      case "stars":
        return Math.random() * 4 + 1
      case "bubbles":
        return Math.random() * 15 + 5
      case "leaves":
        return Math.random() * 10 + 5
      case "confetti":
        return Math.random() * 6 + 2
      default:
        return Math.random() * 5 + 2
    }
  }

  const getRandomDuration = (type: string): number => {
    switch (type) {
      case "stars":
        return Math.random() * 8 + 4
      case "bubbles":
        return Math.random() * 10 + 10
      case "leaves":
        return Math.random() * 8 + 8
      case "confetti":
        return Math.random() * 5 + 5
      default:
        return Math.random() * 10 + 5
    }
  }

  const getRandomOpacity = (type: string): number => {
    switch (type) {
      case "stars":
        return Math.random() * 0.7 + 0.3
      case "bubbles":
        return Math.random() * 0.4 + 0.2
      case "leaves":
        return Math.random() * 0.7 + 0.3
      case "confetti":
        return Math.random() * 0.8 + 0.2
      default:
        return Math.random() * 0.5 + 0.5
    }
  }

  const getRandomColor = (type: string): string => {
    const colors = {
      stars: ["#ffffff", "#ffffcc", "#eeeeff", "#ffdddd", "#ccffff"],
      bubbles: ["#ffffff", "#aaccff", "#99ffff"],
      leaves: ["#77cc77", "#55aa55", "#99dd99", "#bbee99"],
      confetti: ["#ff9999", "#ffcc99", "#ffff99", "#99ff99", "#99ffff", "#9999ff", "#ff99ff"],
    }

    const typeColors = colors[type as keyof typeof colors] || colors.stars
    return typeColors[Math.floor(Math.random() * typeColors.length)]
  }

  const getParticleStyle = (particle: Particle) => {
    switch (type) {
      case "stars":
        return {
          width: `${particle.size}px`,
          height: `${particle.size}px`,
          borderRadius: "50%",
          background: particle.color,
          boxShadow: `0 0 ${particle.size * 2}px ${particle.color}`,
        }
      case "bubbles":
        return {
          width: `${particle.size}px`,
          height: `${particle.size}px`,
          borderRadius: "50%",
          border: `1px solid ${particle.color}`,
          background: `${particle.color}22`,
        }
      case "leaves":
        return {
          width: `${particle.size}px`,
          height: `${particle.size}px`,
          background: particle.color,
          borderRadius: "30% 70% 70% 30% / 30% 30% 70% 70%",
        }
      case "confetti":
        return {
          width: `${particle.size}px`,
          height: `${particle.size * 0.4}px`,
          background: particle.color,
          borderRadius: "2px",
        }
      default:
        return {
          width: `${particle.size}px`,
          height: `${particle.size}px`,
          background: particle.color,
          borderRadius: "50%",
        }
    }
  }

  const getAnimationClass = (type: string): string => {
    switch (type) {
      case "stars":
        return "animate-twinkle"
      case "bubbles":
        return "animate-float"
      case "leaves":
        return "animate-sway"
      case "confetti":
        return "animate-confetti"
      default:
        return "animate-float"
    }
  }

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-10">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className={`absolute ${getAnimationClass(type)}`}
          style={{
            ...getParticleStyle(particle),
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            opacity: particle.opacity,
            animationDuration: `${particle.duration}s`,
            animationDelay: `${particle.delay}s`,
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: particle.opacity }}
          transition={{ duration: 1 }}
        />
      ))}
    </div>
  )
}
