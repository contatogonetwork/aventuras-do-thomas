"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter, useSearchParams } from "next/navigation"
import { motion } from "framer-motion"
import { useAudio } from "@/contexts/audio-context"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { StorySearchForm } from "@/components/story-search-form"
import { StoryPagination } from "@/components/story-pagination"
import { useAppContext } from "@/contexts/app-context"

interface Narrativa {
  id: string
  title: string
  description: string
  imageUrl: string
  theme: string
}

const narrativas: Narrativa[] = [
  {
    id: "aventura-espacial",
    title: "Aventura Espacial",
    description: "Thomás explora o universo e faz amizade com alienígenas coloridos!",
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aventura_espacial-eSOw8pdNOTrLXAxNl2rQgxdisW4YJq.png",
    theme: "space",
  },
  {
    id: "mundo-dinossauros",
    title: "Mundo dos Dinossauros",
    description: "Thomás viaja no tempo e conhece dinossauros amigáveis!",
    imageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dinossauros-3gHbmK71fRHXJV5ivgOEKe1SpjZ4xW.png",
    theme: "dinosaur",
  },
  {
    id: "super-thomas",
    title: "Super Thomás",
    description: "Thomás ganha superpoderes e ajuda a salvar a cidade!",
    imageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/super-heroi-eKTyYNXm96GUSbqSb08R3FGLj4TEkQ.png",
    theme: "superhero",
  },
  {
    id: "piratas-do-caribe",
    title: "Piratas do Caribe",
    description: "Thomás embarca em uma aventura pelos sete mares em busca de tesouros!",
    imageUrl: "/cartoon-pirate-ship.png",
    theme: "pirate",
  },
  {
    id: "castelo-encantado",
    title: "Castelo Encantado",
    description: "Thomás descobre um castelo mágico cheio de segredos e mistérios!",
    imageUrl: "/placeholder.svg?key=lqivh",
    theme: "castle",
  },
  {
    id: "selva-misteriosa",
    title: "Selva Misteriosa",
    description: "Thomás explora uma selva cheia de animais exóticos e plantas mágicas!",
    imageUrl: "/placeholder.svg?height=400&width=600&query=jungle adventure cartoon",
    theme: "jungle",
  },
]

export function NarrativasGallery() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { playEffect } = useAudio()
  const { nightMode } = useAppContext()

  const [selectedNarrativa, setSelectedNarrativa] = useState<string | null>(null)
  const [hoveredNarrativa, setHoveredNarrativa] = useState<string | null>(null)
  const [filteredNarrativas, setFilteredNarrativas] = useState<Narrativa[]>(narrativas)

  // Parâmetros de busca e paginação
  const searchTerm = searchParams.get("q") || ""
  const themeFilter = searchParams.get("theme") || "all"
  const durationFilter = searchParams.get("duration") || "all"
  const currentPage = Number(searchParams.get("page") || "1")
  const itemsPerPage = 6

  // Filtrar narrativas com base nos parâmetros de busca
  useEffect(() => {
    let filtered = [...narrativas]

    // Filtrar por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (narrativa) =>
          narrativa.title.toLowerCase().includes(term) || narrativa.description.toLowerCase().includes(term),
      )
    }

    // Filtrar por tema
    if (themeFilter !== "all") {
      filtered = filtered.filter((narrativa) => narrativa.theme === themeFilter)
    }

    // Filtrar por duração (simulado, já que não temos essa propriedade)
    // Em um caso real, você teria essa propriedade nas narrativas

    setFilteredNarrativas(filtered)

    // Resetar a seleção quando os filtros mudarem
    setSelectedNarrativa(null)
  }, [searchTerm, themeFilter, durationFilter])

  // Calcular paginação
  const totalPages = Math.ceil(filteredNarrativas.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedNarrativas = filteredNarrativas.slice(startIndex, startIndex + itemsPerPage)

  const handleSelectNarrativa = (id: string) => {
    setSelectedNarrativa(id)
    playEffect("theme_select")

    // Encontrar o tema correspondente à narrativa
    const narrativa = narrativas.find((n) => n.id === id)
    if (narrativa) {
      // Tocar efeito sonoro baseado no tema
      playEffect(`hover_${narrativa.theme}`)
    }
  }

  const handleViewDetails = (id: string) => {
    if (id) {
      playEffect("click")
      router.push(`/narrativas/${id}`)
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-8 px-4">
      <motion.h1
        className={cn("text-3xl font-bold text-center mb-8", nightMode ? "text-gray-100" : "text-blue-700")}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Biblioteca de Histórias
      </motion.h1>

      {/* Formulário de busca */}
      <StorySearchForm />

      {/* Resultados da busca */}
      {paginatedNarrativas.length === 0 ? (
        <motion.div
          className="text-center py-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <p className={cn("text-xl mb-4", nightMode ? "text-gray-300" : "text-gray-600")}>
            Nenhuma história encontrada com os filtros selecionados.
          </p>
          <Button
            onClick={() => {
              router.push("/narrativas")
              playEffect("click")
            }}
          >
            Limpar Filtros
          </Button>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {paginatedNarrativas.map((narrativa, index) => (
            <motion.div
              key={narrativa.id}
              className={cn(
                "relative rounded-2xl overflow-hidden shadow-lg cursor-pointer transition-all",
                "transform-gpu h-80",
                selectedNarrativa === narrativa.id ? "ring-4 ring-yellow-400 scale-105" : "",
                hoveredNarrativa === narrativa.id ? "shadow-xl" : "",
              )}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: selectedNarrativa === narrativa.id ? 1.05 : 1.03 }}
              onClick={() => handleSelectNarrativa(narrativa.id)}
              onDoubleClick={() => handleViewDetails(narrativa.id)}
              onMouseEnter={() => {
                setHoveredNarrativa(narrativa.id)
                playEffect("theme_hover")
              }}
              onMouseLeave={() => setHoveredNarrativa(null)}
            >
              <div className="absolute inset-0">
                <Image
                  src={narrativa.imageUrl || "/placeholder.svg"}
                  alt={narrativa.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 33vw"
                  priority={index < 3}
                />
              </div>

              {/* Overlay gradiente para melhorar legibilidade do texto */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />

              {/* Título e descrição */}
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <h3 className="text-xl font-bold mb-1">{narrativa.title}</h3>
                <p className="text-sm opacity-90">{narrativa.description}</p>
              </div>

              {/* Efeito de brilho quando selecionado */}
              {selectedNarrativa === narrativa.id && (
                <div className="absolute inset-0 bg-yellow-300 opacity-10 animate-pulse-slow"></div>
              )}

              {/* Efeito de partículas quando hover */}
              {hoveredNarrativa === narrativa.id && (
                <div className="absolute inset-0 pointer-events-none">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={`sparkle-${i}`}
                      className="absolute w-1.5 h-1.5 bg-white rounded-full animate-sparkle"
                      style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                        opacity: 0.7,
                        animationDelay: `${Math.random() * 1}s`,
                      }}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      )}

      {/* Paginação */}
      {filteredNarrativas.length > 0 && (
        <div className="mt-8">
          <StoryPagination totalPages={totalPages} currentPage={currentPage} baseUrl="/narrativas" />
        </div>
      )}

      {/* Botão de ação */}
      {selectedNarrativa && (
        <div className="flex justify-center mt-8">
          <motion.div
            className="w-full max-w-md"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Button
              onClick={() => handleViewDetails(selectedNarrativa)}
              className="w-full py-4 rounded-full text-xl font-bold text-white shadow-lg transition-all bg-blue-600 hover:bg-blue-700"
            >
              Ver Detalhes da História
            </Button>
          </motion.div>
        </div>
      )}
    </div>
  )
}
