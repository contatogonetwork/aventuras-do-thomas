"use client"

import { useState } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { useAudio } from "@/contexts/audio-context"
import { motion } from "framer-motion"
import { useAppContext } from "@/contexts/app-context"

interface Theme {
  id: string
  name: string
  icon: string
  color: string
}

const themes: Theme[] = [
  {
    id: "space",
    name: "Espaço",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/espaco-E4JPOrVUHuhC39utbe0WUhIwgJFxH3.png",
    color: "from-indigo-500 to-purple-700",
  },
  {
    id: "dinosaur",
    name: "Dinossauros",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dinossauros-XDnXX65v1fgX1MRXWh5L5oVooQvzwV.png",
    color: "from-green-500 to-green-700",
  },
  {
    id: "farm",
    name: "Fazenda",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fazenda-3iF6lm1H12VJsXZL6lRSkVaVvygBos.png",
    color: "from-yellow-500 to-green-600",
  },
  {
    id: "forest",
    name: "Floresta",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/floresta-OaIN6cCzpJ99rv7qgPOO17OY6NkqPr.png",
    color: "from-emerald-500 to-green-700",
  },
  {
    id: "superhero",
    name: "Super-Herói",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/super-heroi-G9eR2ea8HZ9Y2xnAf6IWWrwGz5k6Za.png",
    color: "from-red-500 to-blue-600",
  },
  {
    id: "pirate",
    name: "Piratas",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/piratas-BbGXi8HbAgMttptzzrQFRdxCswcqtl.png",
    color: "from-amber-500 to-blue-600",
  },
  {
    id: "ocean",
    name: "Oceano",
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/oceano-vOeSbBRXW3MIu4HzKiC6mthTyP8veI.png",
    color: "from-blue-500 to-purple-600",
  },
]

interface ThemeSelectorProps {
  selectedTheme: string | null
  onSelectTheme: (themeId: string) => void
}

export function ThemeSelector({ selectedTheme, onSelectTheme }: ThemeSelectorProps) {
  const [hoveredTheme, setHoveredTheme] = useState<string | null>(null)
  const { playEffect } = useAudio()
  const { nightMode } = useAppContext()

  return (
    <div className="w-full max-w-3xl mx-auto mb-8">
      <h2 className={cn("text-2xl font-bold text-center mb-4", nightMode ? "text-blue-300" : "text-blue-800")}>
        Escolha o tema da aventura:
      </h2>
      <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
        {themes.map((theme, index) => (
          <motion.button
            key={theme.id}
            className={cn(
              "relative rounded-2xl overflow-hidden shadow-lg transition-all duration-300 transform aspect-square",
              selectedTheme === theme.id
                ? `ring-4 ${nightMode ? "ring-yellow-500" : "ring-yellow-400"} scale-105 z-10`
                : "",
              nightMode ? "shadow-blue-900/30" : "",
            )}
            whileHover={{ scale: 1.05 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            onClick={() => {
              onSelectTheme(theme.id)
              playEffect("theme_select")
            }}
            onMouseEnter={() => {
              setHoveredTheme(theme.id)
              playEffect("theme_hover")
            }}
            onMouseLeave={() => setHoveredTheme(null)}
          >
            <div className={cn("absolute inset-0 bg-gradient-to-br", nightMode ? "bg-gray-800" : "bg-white")}></div>

            {/* Ícone do tema */}
            <div className="absolute inset-0 flex items-center justify-center p-2">
              <Image
                src={theme.icon || "/placeholder.svg"}
                alt={theme.name}
                width={100}
                height={100}
                className={cn(
                  "object-contain transition-transform duration-300",
                  hoveredTheme === theme.id ? "scale-110" : "",
                  selectedTheme === theme.id ? "animate-bounce-gentle" : "",
                  nightMode ? "brightness-90" : "",
                )}
              />
            </div>

            {/* Nome do tema */}
            <div
              className={cn(
                "absolute bottom-0 left-0 right-0 text-white text-xs font-bold py-1 text-center",
                "opacity-0 transition-opacity duration-300",
                hoveredTheme === theme.id || selectedTheme === theme.id ? "opacity-100" : "",
                nightMode ? "bg-black/70" : "bg-black/50",
              )}
            >
              {theme.name}
            </div>

            {/* Efeito de brilho quando selecionado */}
            {selectedTheme === theme.id && (
              <div
                className={cn(
                  "absolute inset-0 animate-pulse-slow",
                  nightMode ? "bg-yellow-500 opacity-5" : "bg-yellow-300 opacity-10",
                )}
              ></div>
            )}

            {/* Efeito de partículas quando hover */}
            {hoveredTheme === theme.id && (
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(5)].map((_, i) => (
                  <div
                    key={`sparkle-${i}`}
                    className="absolute w-1.5 h-1.5 bg-white rounded-full animate-sparkle"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                      opacity: nightMode ? 0.5 : 0.7,
                      animationDelay: `${Math.random() * 1}s`,
                    }}
                  />
                ))}
              </div>
            )}
          </motion.button>
        ))}
      </div>
    </div>
  )
}
