"use client"

import { useState } from "react"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, RefreshCw } from "lucide-react"

interface ImageSelectorProps {
  theme: string
  onSelect: (url: string) => void
  selectedImage: string
}

export function ImageSelector({ theme, onSelect, selectedImage }: ImageSelectorProps) {
  const { nightMode } = useAppContext()
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  // Imagens pré-definidas por tema
  const themeImages = {
    space: [
      "/placeholder.svg?key=qrpr6",
      "/placeholder.svg?key=cw3o2",
      "/placeholder.svg?key=v3tr1",
      "/placeholder.svg?key=ydxx3",
    ],
    superhero: [
      "/placeholder.svg?key=ggldh",
      "/placeholder.svg?height=300&width=500&query=superhero%20cape",
      "/placeholder.svg?height=300&width=500&query=superhero%20flying",
      "/placeholder.svg?height=300&width=500&query=superhero%20team",
    ],
    dinosaur: [
      "/placeholder.svg?height=300&width=500&query=friendly%20dinosaurs",
      "/placeholder.svg?height=300&width=500&query=child%20with%20dinosaur",
      "/placeholder.svg?height=300&width=500&query=dinosaur%20park",
      "/placeholder.svg?height=300&width=500&query=dinosaur%20egg",
    ],
    pirate: [
      "/placeholder.svg?height=300&width=500&query=pirate%20ship",
      "/placeholder.svg?height=300&width=500&query=treasure%20map",
      "/placeholder.svg?height=300&width=500&query=pirate%20adventure",
      "/placeholder.svg?height=300&width=500&query=island%20treasure",
    ],
    castle: [
      "/placeholder.svg?height=300&width=500&query=fairy%20tale%20castle",
      "/placeholder.svg?height=300&width=500&query=princess%20and%20prince",
      "/placeholder.svg?height=300&width=500&query=magical%20kingdom",
      "/placeholder.svg?height=300&width=500&query=castle%20dragon",
    ],
    jungle: [
      "/placeholder.svg?height=300&width=500&query=jungle%20adventure",
      "/placeholder.svg?height=300&width=500&query=tropical%20forest",
      "/placeholder.svg?height=300&width=500&query=jungle%20animals",
      "/placeholder.svg?height=300&width=500&query=jungle%20explorer",
    ],
    farm: [
      "/placeholder.svg?height=300&width=500&query=farm%20animals",
      "/placeholder.svg?height=300&width=500&query=barn%20countryside",
      "/placeholder.svg?height=300&width=500&query=tractor%20field",
      "/placeholder.svg?height=300&width=500&query=farm%20harvest",
    ],
    ocean: [
      "/placeholder.svg?height=300&width=500&query=underwater%20adventure",
      "/placeholder.svg?height=300&width=500&query=ocean%20fish",
      "/placeholder.svg?height=300&width=500&query=mermaid%20underwater",
      "/placeholder.svg?height=300&width=500&query=submarine%20exploration",
    ],
  }

  // Imagens populares para todas as histórias
  const popularImages = [
    "/placeholder.svg?height=300&width=500&query=children%20adventure",
    "/placeholder.svg?height=300&width=500&query=magical%20journey",
    "/placeholder.svg?height=300&width=500&query=bedtime%20story",
    "/placeholder.svg?height=300&width=500&query=fantasy%20world",
    "/placeholder.svg?height=300&width=500&query=storybook%20illustration",
    "/placeholder.svg?height=300&width=500&query=fairytale%20scene",
  ]

  const handleSearch = () => {
    if (!searchTerm.trim()) return

    setIsLoading(true)

    // Simulando uma busca
    setTimeout(() => {
      const searchImage = `/placeholder.svg?height=300&width=500&query=${encodeURIComponent(searchTerm)}`
      setIsLoading(false)
      onSelect(searchImage)
    }, 1500)
  }

  const handleGenerateRandom = () => {
    setIsLoading(true)

    // Simulando a geração de uma imagem aleatória
    setTimeout(() => {
      const randomTerms = [
        "adventure story",
        "magical journey",
        "fantasy world",
        "children book illustration",
        "storybook scene",
        "fairy tale moment",
      ]
      const randomTerm = randomTerms[Math.floor(Math.random() * randomTerms.length)]
      const randomImage = `/placeholder.svg?height=300&width=500&query=${encodeURIComponent(randomTerm)}`
      setIsLoading(false)
      onSelect(randomImage)
    }, 1500)
  }

  const currentThemeImages = themeImages[theme as keyof typeof themeImages] || themeImages.space

  return (
    <div className="space-y-4">
      <Tabs defaultValue="theme">
        <TabsList className="w-full">
          <TabsTrigger value="theme" className="flex-1">
            Tema Atual
          </TabsTrigger>
          <TabsTrigger value="popular" className="flex-1">
            Populares
          </TabsTrigger>
          <TabsTrigger value="search" className="flex-1">
            Buscar
          </TabsTrigger>
        </TabsList>

        <TabsContent value="theme" className="space-y-4 mt-4">
          <div className="grid grid-cols-2 gap-4">
            {currentThemeImages.map((image, index) => (
              <div
                key={index}
                className={cn(
                  "relative rounded-lg overflow-hidden cursor-pointer transition-all",
                  "hover:shadow-md hover:scale-[1.02]",
                  selectedImage === image && "ring-2 ring-blue-500",
                )}
                onClick={() => onSelect(image)}
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`Imagem do tema ${theme} ${index + 1}`}
                  className="w-full h-40 object-cover"
                />
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="popular" className="space-y-4 mt-4">
          <div className="grid grid-cols-2 gap-4">
            {popularImages.map((image, index) => (
              <div
                key={index}
                className={cn(
                  "relative rounded-lg overflow-hidden cursor-pointer transition-all",
                  "hover:shadow-md hover:scale-[1.02]",
                  selectedImage === image && "ring-2 ring-blue-500",
                )}
                onClick={() => onSelect(image)}
              >
                <img
                  src={image || "/placeholder.svg"}
                  alt={`Imagem popular ${index + 1}`}
                  className="w-full h-40 object-cover"
                />
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="search" className="space-y-4 mt-4">
          <div className="flex gap-2">
            <Input
              placeholder="Buscar imagens..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={cn(nightMode ? "bg-gray-700 border-gray-600" : "bg-white")}
            />
            <Button onClick={handleSearch} disabled={isLoading || !searchTerm.trim()}>
              {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </div>

          <div className="flex flex-col items-center justify-center gap-4 py-4">
            <Button variant="outline" onClick={handleGenerateRandom} disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin mr-2" />
                  Gerando...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Gerar Imagem Aleatória
                </>
              )}
            </Button>

            {selectedImage && (
              <div className="w-full">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Imagem selecionada:</p>
                <div className="rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
                  <img src={selectedImage || "/placeholder.svg"} alt="Imagem selecionada" className="w-full h-auto" />
                </div>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
