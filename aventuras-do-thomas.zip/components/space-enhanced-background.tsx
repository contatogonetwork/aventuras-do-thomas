"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { FloatingParticles } from "@/components/floating-particles"

interface SpaceEnhancedBackgroundProps {
  children: React.ReactNode
}

export function SpaceEnhancedBackground({ children }: SpaceEnhancedBackgroundProps) {
  const [mounted, setMounted] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const backgroundRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setMounted(true)

    const handleMouseMove = (e: MouseEvent) => {
      if (backgroundRef.current) {
        const { left, top, width, height } = backgroundRef.current.getBoundingClientRect()
        const x = (e.clientX - left) / width - 0.5
        const y = (e.clientY - top) / height - 0.5
        setMousePosition({ x, y })
      }
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [])

  if (!mounted) return null

  return (
    <div ref={backgroundRef} className="min-h-screen w-full relative overflow-hidden bg-[#0a0339]">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <Image src="/images/space-background.png" alt="Space background" fill priority className="object-cover" />
      </div>

      {/* Floating stars */}
      <FloatingParticles type="stars" count={50} intensity={1} />

      {/* Floating planets with parallax effect */}
      <motion.div
        className="absolute top-[10%] left-[5%] z-10 w-24 h-24 md:w-32 md:h-32"
        animate={{
          x: mousePosition.x * -20,
          y: mousePosition.y * -20,
          rotate: [0, 5, 0, -5, 0],
        }}
        transition={{
          x: { type: "spring", stiffness: 50 },
          y: { type: "spring", stiffness: 50 },
          rotate: { repeat: Number.POSITIVE_INFINITY, duration: 20 },
        }}
      >
        <Image
          src="/images/purple-planet.png"
          alt="Purple planet"
          width={128}
          height={128}
          className="w-full h-full object-contain"
        />
      </motion.div>

      <motion.div
        className="absolute bottom-[15%] right-[8%] z-10 w-36 h-36 md:w-48 md:h-48"
        animate={{
          x: mousePosition.x * -30,
          y: mousePosition.y * -30,
          rotate: [0, -3, 0, 3, 0],
        }}
        transition={{
          x: { type: "spring", stiffness: 40 },
          y: { type: "spring", stiffness: 40 },
          rotate: { repeat: Number.POSITIVE_INFINITY, duration: 25 },
        }}
      >
        <Image
          src="/images/saturn-planet.png"
          alt="Saturn planet"
          width={192}
          height={192}
          className="w-full h-full object-contain"
        />
      </motion.div>

      {/* Floating astronaut */}
      <motion.div
        className="absolute top-[20%] right-[10%] z-20 w-20 h-20 md:w-28 md:h-28"
        animate={{
          y: [0, -15, 0],
          x: mousePosition.x * 40,
          rotate: [0, 10, 0, -10, 0],
        }}
        transition={{
          y: { repeat: Number.POSITIVE_INFINITY, duration: 4 },
          x: { type: "spring", stiffness: 60 },
          rotate: { repeat: Number.POSITIVE_INFINITY, duration: 10 },
        }}
      >
        <Image
          src="/images/monkey-astronaut.png"
          alt="Monkey astronaut"
          width={112}
          height={112}
          className="w-full h-full object-contain"
        />
      </motion.div>

      {/* Floating rocket */}
      <motion.div
        className="absolute bottom-[30%] left-[15%] z-20 w-16 h-16 md:w-24 md:h-24"
        animate={{
          y: [0, -20, 0],
          x: [0, 15, 0, -15, 0],
          rotate: 15,
        }}
        transition={{
          y: { repeat: Number.POSITIVE_INFINITY, duration: 3, ease: "easeInOut" },
          x: { repeat: Number.POSITIVE_INFINITY, duration: 6, ease: "easeInOut" },
        }}
      >
        <Image src="/images/rocket.png" alt="Rocket" width={96} height={96} className="w-full h-full object-contain" />
      </motion.div>

      {/* Floating dino */}
      <motion.div
        className="absolute bottom-[15%] left-[40%] z-20 w-16 h-16 md:w-20 md:h-20 hidden md:block"
        animate={{
          y: [0, -10, 0],
          rotate: [0, 5, 0, -5, 0],
        }}
        transition={{
          y: { repeat: Number.POSITIVE_INFINITY, duration: 3.5, ease: "easeInOut" },
          rotate: { repeat: Number.POSITIVE_INFINITY, duration: 8 },
        }}
      >
        <Image
          src="/images/dino-astronaut.png"
          alt="Dino astronaut"
          width={80}
          height={80}
          className="w-full h-full object-contain"
        />
      </motion.div>

      {/* Content container */}
      <div className="relative z-30 min-h-screen">{children}</div>
    </div>
  )
}
