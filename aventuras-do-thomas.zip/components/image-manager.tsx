"use client"

import { useState, useRef, useEffect } from "react"
import { X, Upload, ImageIcon, Trash2 } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Theme, CustomImages } from "@/types/app-types"

interface ImageManagerProps {
  themes: Theme[]
  customImages: CustomImages
  onClose: () => void
  onImageUpload: (themeId: string) => void
}

export function ImageManager({ themes, customImages, onClose, onImageUpload }: ImageManagerProps) {
  const [activeTab, setActiveTab] = useState<"themes" | "advanced">("themes")
  const modalRef = useRef<HTMLDivElement>(null)

  // Add animation effect when opening
  useEffect(() => {
    const modal = modalRef.current
    if (!modal) return

    // Animate modal entrance
    modal.style.opacity = "0"
    modal.style.transform = "scale(0.95)"

    setTimeout(() => {
      modal.style.opacity = "1"
      modal.style.transform = "scale(1)"
    }, 10)

    // Add escape key handler
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }

    window.addEventListener("keydown", handleEscape)

    return () => {
      window.removeEventListener("keydown", handleEscape)
    }
  }, [onClose])

  // Function to reset an image
  const handleResetImage = (themeId: string) => {
    // This would be handled by the parent component through context
    // For now, we'll just show a confirmation dialog
    if (
      confirm(
        `Tem certeza que deseja remover a imagem do tema ${themes.find((t) => t.id === themeId)?.name || themeId}?`,
      )
    ) {
      // This would trigger the actual reset in the parent component
      console.log(`Reset image for theme: ${themeId}`)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div
        ref={modalRef}
        className="bg-white rounded-3xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl transition-all duration-300"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-blue-700">
            Gerenciar Imagens do {customImages.default ? "Thomás" : "Personagem"}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-800 p-2 rounded-full hover:bg-gray-100 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b mb-6">
          <button
            className={cn(
              "px-4 py-2 font-medium transition-colors",
              activeTab === "themes" ? "border-b-2 border-blue-500 text-blue-700" : "text-gray-500 hover:text-gray-700",
            )}
            onClick={() => setActiveTab("themes")}
          >
            Temas
          </button>
          <button
            className={cn(
              "px-4 py-2 font-medium transition-colors",
              activeTab === "advanced"
                ? "border-b-2 border-blue-500 text-blue-700"
                : "text-gray-500 hover:text-gray-700",
            )}
            onClick={() => setActiveTab("advanced")}
          >
            Avançado
          </button>
        </div>

        {activeTab === "themes" ? (
          <>
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">Imagem Padrão do Personagem</h3>
              <div className="flex items-center">
                <div className="relative w-24 h-24 rounded-lg overflow-hidden mr-4 border border-gray-200 shadow-md">
                  {customImages.default ? (
                    <img
                      src={customImages.default || "/placeholder.svg"}
                      alt="Imagem padrão do personagem"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-200">
                      <ImageIcon size={32} className="text-gray-400" />
                    </div>
                  )}
                </div>
                <div className="flex flex-col space-y-2">
                  <button
                    onClick={() => onImageUpload("default")}
                    className="flex items-center bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    <Upload size={20} className="mr-2" /> {customImages.default ? "Alterar" : "Carregar"} Imagem
                  </button>
                  {customImages.default && (
                    <button
                      onClick={() => handleResetImage("default")}
                      className="flex items-center bg-red-100 hover:bg-red-200 text-red-600 px-4 py-2 rounded-lg transition-colors"
                    >
                      <Trash2 size={20} className="mr-2" /> Remover
                    </button>
                  )}
                </div>
              </div>
            </div>

            <h3 className="text-xl font-semibold mb-4">Imagens por Tema</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {themes.map((theme) => (
                <div
                  key={theme.id}
                  className="p-4 rounded-lg transition-all duration-300 hover:shadow-md"
                  style={{ backgroundColor: `${theme.color}22` }}
                >
                  <div className="flex items-center mb-2">
                    <span className="text-2xl mr-2" aria-hidden="true">
                      {theme.icon}
                    </span>
                    <h4 className="text-lg font-medium">{theme.name}</h4>
                  </div>
                  <div className="flex items-center">
                    <div className="relative w-20 h-20 rounded-lg overflow-hidden mr-4 border border-white shadow-md">
                      {customImages[theme.id] ? (
                        <img
                          src={customImages[theme.id] || ""}
                          alt={`Imagem do tema ${theme.name}`}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-gray-200">
                          <ImageIcon size={24} className="text-gray-400" />
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col space-y-2">
                      <button
                        onClick={() => onImageUpload(theme.id)}
                        className="flex items-center bg-white hover:bg-gray-100 text-gray-800 px-3 py-1 rounded-lg text-sm transition-colors"
                      >
                        <Upload size={16} className="mr-1" />
                        {customImages[theme.id] ? "Alterar" : "Adicionar"}
                      </button>
                      {customImages[theme.id] && (
                        <button
                          onClick={() => handleResetImage(theme.id)}
                          className="flex items-center bg-red-100 hover:bg-red-200 text-red-600 px-3 py-1 rounded-lg text-sm transition-colors"
                        >
                          <Trash2 size={16} className="mr-1" /> Remover
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Gerenciamento de Armazenamento</h3>
              <div className="bg-gray-100 p-4 rounded-lg">
                <div className="mb-2">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">Espaço utilizado:</span>
                    <span className="text-sm font-medium">2.3 MB / 5 MB</span>
                  </div>
                  <div className="w-full bg-gray-300 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: "46%" }}></div>
                  </div>
                </div>
                <p className="text-xs text-gray-600">
                  As imagens são armazenadas localmente no seu dispositivo. Remova imagens não utilizadas para liberar
                  espaço.
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-2">Otimização de Imagens</h3>
              <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                <div>
                  <p className="font-medium text-blue-700">Compressão automática</p>
                  <p className="text-sm text-gray-600">Reduz o tamanho das imagens para economizar espaço</p>
                </div>
                <div className="w-12 h-6 flex items-center rounded-full p-1 bg-blue-500 justify-end cursor-pointer">
                  <div className="bg-white w-4 h-4 rounded-full shadow-md"></div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-2">Limpar Dados</h3>
              <button
                className="w-full bg-red-100 hover:bg-red-200 text-red-600 py-2 rounded-lg flex items-center justify-center"
                onClick={() => {
                  if (
                    confirm(
                      "Tem certeza que deseja remover todas as imagens personalizadas? Esta ação não pode ser desfeita.",
                    )
                  ) {
                    // This would trigger the actual reset in the parent component
                    console.log("Reset all images")
                  }
                }}
              >
                <Trash2 size={20} className="mr-2" /> Remover Todas as Imagens
              </button>
            </div>
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full mt-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium"
        >
          Fechar
        </button>
      </div>
    </div>
  )
}
