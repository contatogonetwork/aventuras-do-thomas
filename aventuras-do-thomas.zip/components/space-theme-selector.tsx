"use client"
import Image from "next/image"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface SpaceThemeSelectorProps {
  selectedTheme: string | null
  onSelectTheme: (theme: string) => void
}

interface ThemeOption {
  id: string
  name: string
  image: string
  bgColor: string
}

export function SpaceThemeSelector({ selectedTheme, onSelectTheme }: SpaceThemeSelectorProps) {
  const themeOptions: ThemeOption[] = [
    {
      id: "space",
      name: "Espaço",
      image: "/images/rocket.png",
      bgColor: "from-blue-500 to-indigo-600",
    },
    {
      id: "dinosaur",
      name: "Dinossauros",
      image: "/images/dino-astronaut.png",
      bgColor: "from-green-500 to-emerald-600",
    },
    {
      id: "pirate",
      name: "Piratas",
      image: "/public/cartoon-pirate-ship.png",
      bgColor: "from-amber-500 to-red-600",
    },
    {
      id: "superhero",
      name: "Super-heróis",
      image: "/images/monkey-astronaut.png",
      bgColor: "from-red-500 to-purple-600",
    },
    {
      id: "castle",
      name: "Castelo",
      image: "/placeholder.svg?key=g1j6j",
      bgColor: "from-purple-500 to-pink-600",
    },
    {
      id: "jungle",
      name: "Selva",
      image: "/placeholder.svg?key=u89wl",
      bgColor: "from-emerald-500 to-green-600",
    },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="w-full max-w-3xl mx-auto mb-8"
    >
      <h2 className="text-2xl font-bold text-center mb-4 text-yellow-300">Escolha um tema para sua aventura</h2>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {themeOptions.map((theme) => (
          <motion.div
            key={theme.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelectTheme(theme.id)}
            className={cn(
              "relative overflow-hidden rounded-2xl cursor-pointer border-4 transition-all",
              selectedTheme === theme.id
                ? "border-yellow-300 shadow-lg shadow-yellow-300/30"
                : "border-transparent hover:border-blue-400",
            )}
          >
            <div
              className={cn("bg-gradient-to-br p-4 h-full flex flex-col items-center justify-center", theme.bgColor)}
            >
              <div className="w-16 h-16 md:w-20 md:h-20 mb-2 relative">
                <Image
                  src={theme.image || "/placeholder.svg"}
                  alt={theme.name}
                  width={80}
                  height={80}
                  className="object-contain"
                />
              </div>
              <p className="font-medium text-white text-center">{theme.name}</p>
            </div>

            {selectedTheme === theme.id && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-2 right-2 bg-yellow-300 text-indigo-900 rounded-full p-1"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </motion.div>
            )}
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}
