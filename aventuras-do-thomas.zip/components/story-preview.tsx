"use client"

import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

interface StoryPreviewProps {
  title: string
  content: string
  theme: string
  imageUrl: string
}

export function StoryPreview({ title, content, theme, imageUrl }: StoryPreviewProps) {
  const { nightMode } = useAppContext()

  // Função para obter a cor do tema
  const getThemeColor = () => {
    switch (theme) {
      case "space":
        return nightMode ? "#3730a3" : "#818cf8" // indigo
      case "superhero":
        return nightMode ? "#9f1239" : "#f43f5e" // rose
      case "dinosaur":
        return nightMode ? "#166534" : "#22c55e" // green
      case "pirate":
        return nightMode ? "#854d0e" : "#f59e0b" // amber
      case "castle":
        return nightMode ? "#581c87" : "#a855f7" // purple
      case "jungle":
        return nightMode ? "#065f46" : "#10b981" // emerald
      case "farm":
        return nightMode ? "#854d0e" : "#eab308" // yellow
      case "ocean":
        return nightMode ? "#0c4a6e" : "#0ea5e9" // sky
      default:
        return nightMode ? "#1e40af" : "#3b82f6" // blue
    }
  }

  const themeColor = getThemeColor()

  // Dividir o conteúdo em parágrafos
  const paragraphs = content
    .split("\n")
    .filter((p) => p.trim() !== "")
    .map((p, i) => (
      <p key={i} className="mb-4 leading-relaxed">
        {p}
      </p>
    ))

  if (!content) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <div className="text-4xl mb-4">📝</div>
        <h3 className="text-lg font-medium mb-2">Sua história aparecerá aqui</h3>
        <p className="text-gray-500 dark:text-gray-400">
          Use o editor à esquerda para escrever sua história ou clique em "Gerar História" para criar uma
          automaticamente.
        </p>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className={cn("rounded-xl overflow-hidden shadow-lg", nightMode ? "bg-gray-900" : "bg-white")}>
        <div className="relative h-64 overflow-hidden">
          <img src={imageUrl || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />
          <div
            className="absolute inset-0"
            style={{
              background: `linear-gradient(to bottom, transparent 50%, ${themeColor}99 100%)`,
            }}
          />
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-2xl font-bold text-white drop-shadow-md"
            >
              {title}
            </motion.h1>
          </div>
        </div>

        <div className="p-6">
          <div className={cn("prose max-w-none", nightMode ? "prose-invert" : "")}>{paragraphs}</div>
        </div>
      </div>
    </div>
  )
}
