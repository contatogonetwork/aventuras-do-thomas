"use client"

import { useState } from "react"
import { useAudio } from "@/contexts/audio-context"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Volume2, VolumeX, Music, Zap, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"

export function AudioManager() {
  const {
    effectsVolume,
    ambientVolume,
    setEffectsVolume,
    setAmbientVolume,
    enabled,
    setEnabled,
    playEffect,
    playAmbient,
    stopAmbient,
    currentAmbient,
  } = useAudio()

  const [testSoundPlaying, setTestSoundPlaying] = useState<string | null>(null)

  // Lista de efeitos sonoros para teste
  const testEffects = [
    { id: "click", name: "Clique" },
    { id: "hover", name: "Hover" },
    { id: "page_turn", name: "Virar Página" },
    { id: "story_ready", name: "História Pronta" },
    { id: "theme_select", name: "Selecionar Tema" },
    { id: "start_adventure", name: "Iniciar Aventura" },
  ]

  // Lista de sons ambiente para teste
  const testAmbients = [
    { id: "space", name: "Espaço" },
    { id: "ocean", name: "Oceano" },
    { id: "jungle", name: "Selva" },
    { id: "dinosaur", name: "Dinossauros" },
    { id: "castle", name: "Castelo" },
    { id: "pirate", name: "Piratas" },
    { id: "farm", name: "Fazenda" },
  ]

  // Função para tocar um efeito sonoro de teste
  const handlePlayTestEffect = (effectId: string) => {
    setTestSoundPlaying(effectId)
    playEffect(effectId)

    // Limpar o estado após um tempo
    setTimeout(() => {
      setTestSoundPlaying(null)
    }, 1000)
  }

  // Função para tocar um som ambiente de teste
  const handlePlayTestAmbient = (ambientId: string) => {
    playAmbient(ambientId)
  }

  // Função para parar todos os sons
  const handleStopAllSounds = () => {
    stopAmbient()
  }

  return (
    <div className="w-full max-w-2xl bg-white rounded-2xl shadow-xl p-6">
      {/* Controle principal de áudio */}
      <div className="flex items-center justify-between mb-8 pb-4 border-b">
        <div className="flex items-center">
          {enabled ? <Volume2 size={24} className="text-blue-600" /> : <VolumeX size={24} className="text-gray-400" />}
          <span className="ml-2 font-medium">{enabled ? "Áudio Ativado" : "Áudio Desativado"}</span>
        </div>
        <Switch checked={enabled} onCheckedChange={setEnabled} />
      </div>

      {/* Controles de volume */}
      <div className="space-y-6 mb-8">
        <div className="space-y-2">
          <div className="flex justify-between">
            <label className="font-medium flex items-center">
              <Zap size={18} className="mr-2 text-amber-500" /> Volume dos Efeitos Sonoros
            </label>
            <span className="text-sm text-gray-500">{Math.round(effectsVolume * 100)}%</span>
          </div>
          <Slider
            value={[effectsVolume * 100]}
            min={0}
            max={100}
            step={1}
            onValueChange={(value) => setEffectsVolume(value[0] / 100)}
            disabled={!enabled}
            className={cn(!enabled && "opacity-50")}
          />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between">
            <label className="font-medium flex items-center">
              <Music size={18} className="mr-2 text-indigo-500" /> Volume da Música Ambiente
            </label>
            <span className="text-sm text-gray-500">{Math.round(ambientVolume * 100)}%</span>
          </div>
          <Slider
            value={[ambientVolume * 100]}
            min={0}
            max={100}
            step={1}
            onValueChange={(value) => setAmbientVolume(value[0] / 100)}
            disabled={!enabled}
            className={cn(!enabled && "opacity-50")}
          />
        </div>
      </div>

      {/* Testar efeitos sonoros */}
      <div className="mb-8">
        <h3 className="font-semibold mb-3 flex items-center">
          <Zap size={18} className="mr-2 text-amber-500" /> Testar Efeitos Sonoros
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {testEffects.map((effect) => (
            <Button
              key={effect.id}
              variant="outline"
              size="sm"
              onClick={() => handlePlayTestEffect(effect.id)}
              disabled={!enabled}
              className={cn(
                "h-auto py-2",
                testSoundPlaying === effect.id && "bg-blue-100 border-blue-300",
                !enabled && "opacity-50",
              )}
            >
              {effect.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Testar sons ambiente */}
      <div className="mb-8">
        <h3 className="font-semibold mb-3 flex items-center">
          <Music size={18} className="mr-2 text-indigo-500" /> Testar Música Ambiente
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {testAmbients.map((ambient) => (
            <Button
              key={ambient.id}
              variant="outline"
              size="sm"
              onClick={() => handlePlayTestAmbient(ambient.id)}
              disabled={!enabled}
              className={cn(
                "h-auto py-2",
                currentAmbient === ambient.id && "bg-blue-100 border-blue-300",
                !enabled && "opacity-50",
              )}
            >
              {ambient.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Botão para parar todos os sons */}
      <div className="flex justify-center">
        <Button
          variant="destructive"
          onClick={handleStopAllSounds}
          disabled={!enabled || !currentAmbient}
          className="flex items-center"
        >
          <RefreshCw size={18} className="mr-2" /> Parar Todos os Sons
        </Button>
      </div>
    </div>
  )
}
