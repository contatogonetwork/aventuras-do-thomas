"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"
import Image from "next/image"

interface EnhancedButtonProps {
  children: React.ReactNode
  onClick?: () => void
  className?: string
  disabled?: boolean
  icon?: string
  iconPosition?: "left" | "right"
  glow?: "teal" | "indigo" | "orange" | "none"
}

export function EnhancedButton({
  children,
  onClick,
  className,
  disabled = false,
  icon,
  iconPosition = "left",
  glow = "none",
}: EnhancedButtonProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [glowIntensity, setGlowIntensity] = useState(0)

  useEffect(() => {
    if (!isHovered || disabled || glow === "none") {
      setGlowIntensity(0)
      return
    }

    // Animação de pulso para o brilho
    let direction = 1
    let value = 0

    const interval = setInterval(() => {
      value += 0.05 * direction

      if (value >= 1) {
        direction = -1
      } else if (value <= 0.3) {
        direction = 1
      }

      setGlowIntensity(value)
    }, 50)

    return () => clearInterval(interval)
  }, [isHovered, disabled, glow])

  // Definir cor do brilho com base na propriedade glow
  const getGlowColor = () => {
    switch (glow) {
      case "teal":
        return "rgba(20, 184, 166, 0.7)"
      case "indigo":
        return "rgba(99, 102, 241, 0.7)"
      case "orange":
        return "rgba(249, 115, 22, 0.7)"
      default:
        return "transparent"
    }
  }

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn("relative overflow-hidden transition-all", className)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        boxShadow:
          isHovered && !disabled && glow !== "none" ? `0 0 ${10 + glowIntensity * 15}px ${getGlowColor()}` : "none",
        transition: "box-shadow 0.3s ease-in-out",
      }}
    >
      <div className="relative z-10 flex items-center justify-center">
        {icon && iconPosition === "left" && (
          <div className="mr-2 relative w-6 h-6">
            <Image src={icon || "/placeholder.svg"} alt="ícone" width={24} height={24} />
          </div>
        )}

        {children}

        {icon && iconPosition === "right" && (
          <div className="ml-2 relative w-6 h-6">
            <Image src={icon || "/placeholder.svg"} alt="ícone" width={24} height={24} />
          </div>
        )}
      </div>

      {isHovered && !disabled && (
        <div className="absolute inset-0 z-0">
          {[...Array(5)].map((_, i) => (
            <div
              key={`sparkle-${i}`}
              className="absolute w-1 h-1 bg-white rounded-full animate-sparkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                opacity: 0.7,
                animationDelay: `${Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      )}
    </button>
  )
}
