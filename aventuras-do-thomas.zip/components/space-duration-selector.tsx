"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface SpaceDurationSelectorProps {
  selectedDuration: string | null
  onSelectDuration: (duration: string) => void
}

export function SpaceDurationSelector({ selectedDuration, onSelectDuration }: SpaceDurationSelectorProps) {
  const durations = [
    { id: "short", name: "CURTA", icon: "⭐", color: "from-teal-400 to-cyan-500" },
    { id: "long", name: "LONGA", icon: "🌟", color: "from-blue-500 to-indigo-600" },
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="w-full max-w-md mx-auto mb-8"
    >
      <h2 className="text-2xl font-bold text-center mb-4 text-yellow-300">Escolha a duração</h2>

      <div className="flex justify-center gap-6">
        {durations.map((duration) => (
          <motion.button
            key={duration.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelectDuration(duration.id)}
            className={cn(
              "relative px-8 py-4 rounded-full text-white font-bold text-lg",
              "bg-gradient-to-r shadow-lg transition-all",
              duration.color,
              selectedDuration === duration.id
                ? "ring-4 ring-yellow-300 ring-opacity-70"
                : "hover:ring-2 hover:ring-blue-300",
            )}
          >
            <span className="mr-2">{duration.icon}</span>
            {duration.name}
          </motion.button>
        ))}
      </div>
    </motion.div>
  )
}
