"use client"

import { useState } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { useAudio } from "@/contexts/audio-context"
import { motion } from "framer-motion"
import { useAppContext } from "@/contexts/app-context"

interface StartAdventureButtonProps {
  onClick: () => void
  disabled?: boolean
}

export function StartAdventureButton({ onClick, disabled = false }: StartAdventureButtonProps) {
  const { playEffect } = useAudio()
  const [isHovered, setIsHovered] = useState(false)
  const { nightMode } = useAppContext()

  const handleClick = () => {
    if (disabled) return
    playEffect("start_adventure")
    onClick()
  }

  return (
    <motion.div
      className={cn(
        "relative w-full max-w-md mx-auto cursor-pointer transition-all",
        disabled ? "opacity-60 cursor-not-allowed" : "hover:scale-105",
      )}
      whileHover={{ scale: disabled ? 1 : 1.05 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
    >
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/comecar_aventura-KOLjikoTowWwQVfEZhrZX4ixD38rUe.png"
        alt="Começar Aventura"
        width={400}
        height={100}
        className={cn("w-full h-auto object-contain", nightMode ? "brightness-90 contrast-125" : "")}
      />

      {/* Efeito de brilho quando hover */}
      {isHovered && !disabled && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(8)].map((_, i) => (
            <div
              key={`sparkle-${i}`}
              className="absolute w-2 h-2 bg-white rounded-full animate-sparkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                opacity: nightMode ? 0.5 : 0.7,
                animationDelay: `${Math.random() * 1}s`,
              }}
            />
          ))}
        </div>
      )}
    </motion.div>
  )
}
