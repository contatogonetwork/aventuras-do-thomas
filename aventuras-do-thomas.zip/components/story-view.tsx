"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { ChevronLeft, Volume2, VolumeX } from "lucide-react"
import type { Story } from "@/data/stories-config"
import { useAudio } from "@/contexts/audio-context"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import { NightModeToggle } from "./night-mode-toggle"

interface StoryViewProps {
  story: Story
  onBack: () => void
}

export function StoryView({ story, onBack }: StoryViewProps) {
  const [currentPage, setCurrentPage] = useState(0)
  const [isMuted, setIsMuted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const { playEffect, playAmbient, stopAmbient } = useAudio()
  const { nightMode } = useAppContext()
  const ambientInitializedRef = useRef<boolean>(false)

  useEffect(() => {
    // Simular carregamento
    const timer = setTimeout(() => {
      setIsLoading(false)
      playEffect("story_ready")

      // Tocar música ambiente baseada no tema da história apenas uma vez
      if (story.theme && !ambientInitializedRef.current) {
        playAmbient(story.theme)
        ambientInitializedRef.current = true
      }
    }, 1500)

    return () => {
      clearTimeout(timer)
      stopAmbient()
    }
  }, [story, playEffect, playAmbient, stopAmbient])

  const handleToggleMute = () => {
    setIsMuted(!isMuted)
    playEffect("toggle_mute")
  }

  const handleNextPage = () => {
    if (currentPage < story.pages.length - 1) {
      setCurrentPage(currentPage + 1)
      playEffect("page_turn")
    }
  }

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1)
      playEffect("page_turn_back")
    }
  }

  const handleBack = () => {
    playEffect("back_button")
    onBack()
  }

  const currentPageData = story.pages[currentPage]

  return (
    <div
      className={cn(
        "min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden",
        nightMode
          ? "bg-gradient-to-b from-gray-900 to-indigo-950 text-gray-100"
          : "bg-gradient-to-b from-blue-100 to-purple-100 text-gray-900",
      )}
    >
      {/* Áudio de fundo */}
      <audio loop src={story.audioUrl} muted={isMuted} />

      {/* Botão de voltar */}
      <motion.button
        onClick={handleBack}
        className={cn(
          "absolute top-4 left-4 z-30 rounded-full p-2 transition-colors",
          nightMode ? "bg-gray-800/80 hover:bg-gray-800 text-gray-200" : "bg-white/80 hover:bg-white text-blue-600",
        )}
        aria-label="Voltar"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <ChevronLeft className="h-6 w-6" />
      </motion.button>

      {/* Botão de áudio */}
      <motion.button
        onClick={handleToggleMute}
        className={cn(
          "absolute top-4 right-16 z-30 rounded-full p-2 transition-colors",
          nightMode ? "bg-gray-800/80 hover:bg-gray-800 text-gray-200" : "bg-white/80 hover:bg-white text-blue-600",
        )}
        aria-label={isMuted ? "Ativar som" : "Desativar som"}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        {isMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
      </motion.button>

      {/* Botão de modo noturno */}
      <div className="absolute top-4 right-4 z-30">
        <NightModeToggle size="sm" />
      </div>

      {/* Conteúdo da história */}
      <div
        className={cn(
          "w-full max-w-4xl h-[80vh] rounded-3xl overflow-hidden shadow-2xl",
          nightMode ? "shadow-blue-900/20" : "",
        )}
      >
        {isLoading ? (
          <div
            className={cn("absolute inset-0 flex items-center justify-center", nightMode ? "bg-gray-900" : "bg-white")}
          >
            <div
              className={cn(
                "animate-spin rounded-full h-16 w-16 border-b-2",
                nightMode ? "border-blue-400" : "border-blue-500",
              )}
            ></div>
          </div>
        ) : (
          <>
            {/* Camada de fundo */}
            <div
              className="absolute inset-0"
              style={{
                backgroundImage: `url(${currentPageData.backgroundUrl})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                zIndex: 0,
                filter: nightMode ? "brightness(0.7) contrast(1.1)" : "none",
              }}
            ></div>

            {/* Camada do meio (elementos decorativos) */}
            <div className="absolute inset-0 z-10">
              {currentPageData.decorativeElements?.map((element, index) => (
                <div
                  key={index}
                  className="absolute"
                  style={{
                    left: `${element.position.x}%`,
                    top: `${element.position.y}%`,
                    fontSize: `${(element.scale || 1) * 2}rem`,
                    filter: nightMode ? "brightness(0.9)" : "none",
                  }}
                >
                  {element.emoji}
                </div>
              ))}
            </div>

            {/* Camada frontal (personagens) */}
            <div className="absolute inset-0 z-20">
              {/* Personagens */}
              {currentPageData.characters?.map((character, index) => (
                <div
                  key={index}
                  className="absolute transition-all duration-500"
                  style={{
                    left: `${character.position.x}%`,
                    top: `${character.position.y}%`,
                  }}
                >
                  <div
                    className="relative w-32 h-32"
                    style={{
                      transform: `scale(${character.scale || 1})`,
                      filter: nightMode ? "brightness(0.9)" : "none",
                    }}
                  >
                    <Image
                      src={character.imageUrl || `/placeholder.svg?height=128&width=128&query=character`}
                      alt={character.name}
                      width={128}
                      height={128}
                      className="object-contain"
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Texto da história - fixo sem parallax */}
            <div
              className={cn(
                "absolute bottom-0 left-0 right-0 p-6 rounded-t-3xl z-30",
                nightMode ? "bg-gray-900/90 backdrop-blur-sm" : "bg-white/90 backdrop-blur-sm",
              )}
            >
              <p className={cn("text-xl font-medium leading-relaxed", nightMode ? "text-gray-100" : "text-gray-900")}>
                {currentPageData.text}
              </p>

              {/* Navegação entre páginas */}
              <div className="flex justify-between mt-4">
                <button
                  onClick={handlePrevPage}
                  disabled={currentPage === 0}
                  className={cn(
                    "px-4 py-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed",
                    nightMode
                      ? "bg-blue-900 hover:bg-blue-800 text-white"
                      : "bg-blue-100 hover:bg-blue-200 text-blue-700",
                  )}
                >
                  Anterior
                </button>

                <span className={cn("text-sm self-center", nightMode ? "text-gray-400" : "text-gray-500")}>
                  Página {currentPage + 1} de {story.pages.length}
                </span>

                <button
                  onClick={handleNextPage}
                  disabled={currentPage === story.pages.length - 1}
                  className={cn(
                    "px-4 py-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed",
                    nightMode ? "bg-blue-700 hover:bg-blue-600 text-white" : "bg-blue-500 hover:bg-blue-600 text-white",
                  )}
                >
                  Próxima
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
