"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useAudio } from "@/contexts/audio-context"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Search, Filter } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

export function StorySearchForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { playEffect } = useAudio()
  const { nightMode } = useAppContext()

  const [searchTerm, setSearchTerm] = useState(searchParams.get("q") || "")
  const [theme, setTheme] = useState(searchParams.get("theme") || "all")
  const [duration, setDuration] = useState(searchParams.get("duration") || "all")
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  // Atualizar os estados quando os parâmetros de URL mudarem
  useEffect(() => {
    setSearchTerm(searchParams.get("q") || "")
    setTheme(searchParams.get("theme") || "all")
    setDuration(searchParams.get("duration") || "all")
  }, [searchParams])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    playEffect("click")

    // Criar uma nova instância de URLSearchParams
    const params = new URLSearchParams()

    // Adicionar parâmetros apenas se tiverem valores
    if (searchTerm) params.set("q", searchTerm)
    if (theme !== "all") params.set("theme", theme)
    if (duration !== "all") params.set("duration", duration)

    // Navegar para a URL com os parâmetros
    router.push(`/narrativas?${params.toString()}`)

    // Fechar o popover de filtros se estiver aberto
    setIsFilterOpen(false)
  }

  return (
    <form onSubmit={handleSearch} className="w-full max-w-3xl mx-auto mb-8">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type="text"
            placeholder="Buscar histórias..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={cn(
              "pl-10",
              nightMode ? "bg-gray-800 border-gray-700 text-gray-100 placeholder:text-gray-400" : "",
            )}
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>

        <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
          <PopoverTrigger asChild>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsFilterOpen(!isFilterOpen)
                playEffect("click")
              }}
              className={nightMode ? "border-gray-700 bg-gray-800 text-gray-100 hover:bg-gray-700" : ""}
            >
              <Filter className="h-4 w-4 mr-2" />
              Filtros
            </Button>
          </PopoverTrigger>
          <PopoverContent className={cn("w-80", nightMode ? "bg-gray-800 border-gray-700 text-gray-100" : "")}>
            <div className="space-y-4">
              <div className="space-y-2">
                <h4 className="font-medium">Tema</h4>
                <RadioGroup value={theme} onValueChange={setTheme}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="all" id="theme-all" />
                    <Label htmlFor="theme-all" className={nightMode ? "text-gray-200" : ""}>
                      Todos
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="space" id="theme-space" />
                    <Label htmlFor="theme-space" className={nightMode ? "text-gray-200" : ""}>
                      Espaço
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dinosaur" id="theme-dinosaur" />
                    <Label htmlFor="theme-dinosaur" className={nightMode ? "text-gray-200" : ""}>
                      Dinossauros
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="superhero" id="theme-superhero" />
                    <Label htmlFor="theme-superhero" className={nightMode ? "text-gray-200" : ""}>
                      Super-Heróis
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="pirate" id="theme-pirate" />
                    <Label htmlFor="theme-pirate" className={nightMode ? "text-gray-200" : ""}>
                      Piratas
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Duração</h4>
                <RadioGroup value={duration} onValueChange={setDuration}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="all" id="duration-all" />
                    <Label htmlFor="duration-all" className={nightMode ? "text-gray-200" : ""}>
                      Todas
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="short" id="duration-short" />
                    <Label htmlFor="duration-short" className={nightMode ? "text-gray-200" : ""}>
                      Curta
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="medium" id="duration-medium" />
                    <Label htmlFor="duration-medium" className={nightMode ? "text-gray-200" : ""}>
                      Média
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="long" id="duration-long" />
                    <Label htmlFor="duration-long" className={nightMode ? "text-gray-200" : ""}>
                      Longa
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <Button
                type="submit"
                className="w-full"
                onClick={() => {
                  handleSearch
                  setIsFilterOpen(false)
                }}
              >
                Aplicar Filtros
              </Button>
            </div>
          </PopoverContent>
        </Popover>

        <Button type="submit">Buscar</Button>
      </div>
    </form>
  )
}
