"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Trash2, Sparkles, Undo, Redo } from "lucide-react"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"

interface StoryEditorProps {
  content: string
  onChange: (content: string) => void
  isLoading?: boolean
}

export function StoryEditor({ content, onChange, isLoading = false }: StoryEditorProps) {
  const { nightMode } = useAppContext()
  const [history, setHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [localContent, setLocalContent] = useState(content)

  // Sincronizar o conteúdo local com o conteúdo do prop
  useEffect(() => {
    setLocalContent(content)
    // Adicionar ao histórico apenas se o conteúdo for diferente do último item
    if (content && (history.length === 0 || history[history.length - 1] !== content)) {
      setHistory([...history, content])
      setHistoryIndex(history.length)
    }
  }, [content])

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setLocalContent(e.target.value)
    onChange(e.target.value)
  }

  const handleClear = () => {
    // Adicionar ao histórico antes de limpar
    if (localContent) {
      setHistory([...history, localContent])
      setHistoryIndex(history.length)
    }
    setLocalContent("")
    onChange("")
  }

  const handleUndo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1
      setHistoryIndex(newIndex)
      setLocalContent(history[newIndex])
      onChange(history[newIndex])
    }
  }

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1
      setHistoryIndex(newIndex)
      setLocalContent(history[newIndex])
      onChange(history[newIndex])
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="w-full h-4" />
        <Skeleton className="w-[90%] h-4" />
        <Skeleton className="w-[95%] h-4" />
        <Skeleton className="w-full h-4" />
        <Skeleton className="w-[85%] h-4" />
        <Skeleton className="w-[92%] h-4" />
        <Skeleton className="w-full h-4" />
        <Skeleton className="w-[88%] h-4" />
        <div className="flex items-center justify-center mt-8">
          <Sparkles className="animate-pulse text-blue-500 mr-2" />
          <span className="text-sm text-blue-500 animate-pulse">Gerando história mágica...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={handleUndo}
          disabled={historyIndex <= 0}
          className={cn("bg-white hover:bg-gray-100", nightMode && "bg-gray-800 hover:bg-gray-700 text-gray-300")}
        >
          <Undo className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRedo}
          disabled={historyIndex >= history.length - 1}
          className={cn("bg-white hover:bg-gray-100", nightMode && "bg-gray-800 hover:bg-gray-700 text-gray-300")}
        >
          <Redo className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={handleClear}
          disabled={!localContent}
          className={cn(
            "ml-auto bg-white hover:bg-gray-100 text-red-500 hover:text-red-600",
            nightMode && "bg-gray-800 hover:bg-gray-700 text-red-400 hover:text-red-300",
          )}
        >
          <Trash2 className="h-4 w-4 mr-1" /> Limpar
        </Button>
      </div>
      <Textarea
        value={localContent}
        onChange={handleChange}
        placeholder="Era uma vez um menino muito curioso chamado Thomas..."
        className={cn(
          "min-h-[400px] text-base leading-relaxed p-4 resize-none",
          nightMode ? "bg-gray-800 text-gray-100" : "bg-white",
        )}
      />
      <div className="text-xs text-gray-500 dark:text-gray-400">
        {localContent.length} caracteres | {localContent.split(/\s+/).filter(Boolean).length} palavras
      </div>
    </div>
  )
}
