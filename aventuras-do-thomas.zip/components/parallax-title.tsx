"use client"

import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"

interface ParallaxTitleProps {
  text: string
  className?: string
  glowColor?: string
  depth?: number
}

export function ParallaxTitle({
  text,
  className,
  glowColor = "rgba(59, 130, 246, 0.7)",
  depth = 0.1,
}: ParallaxTitleProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const container = containerRef.current
    if (!container) return

    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e
      const rect = container.getBoundingClientRect()

      // Calcular posição relativa do mouse
      const x = clientX - rect.left
      const y = clientY - rect.top

      // Calcular distância do centro
      const centerX = rect.width / 2
      const centerY = rect.height / 2

      // Calcular deslocamento do centro (normalizado de -1 a 1)
      const offsetX = (x - centerX) / centerX
      const offsetY = (y - centerY) / centerY

      // Aplicar transformação aos elementos
      const letters = container.querySelectorAll(".parallax-letter")
      letters.forEach((letter, index) => {
        const letterDepth = depth * (1 + (index % 3) * 0.2) // Variação de profundidade
        const moveX = offsetX * letterDepth * 20
        const moveY = offsetY * letterDepth * 10
        const rotate = offsetX * letterDepth * 5

        // Aplicar transformação
        ;(letter as HTMLElement).style.transform = `translate3d(${moveX}px, ${moveY}px, 0) rotate(${rotate}deg)`
      })
    }

    container.addEventListener("mousemove", handleMouseMove)

    return () => {
      container.removeEventListener("mousemove", handleMouseMove)
    }
  }, [depth])

  // Dividir o texto em letras
  const letters = text.split("")

  return (
    <div ref={containerRef} className={cn("relative py-4 px-2 overflow-hidden cursor-default", className)}>
      <div className="flex justify-center items-center">
        {letters.map((letter, index) => (
          <span
            key={index}
            className={cn(
              "parallax-letter inline-block transition-transform duration-200",
              "text-4xl md:text-5xl font-bold",
            )}
            style={{
              opacity: mounted ? 1 : 0,
              transition: `opacity 0.5s ease, transform 0.2s ease`,
              transitionDelay: `${index * 0.03}s`,
              textShadow: `0 0 10px ${glowColor}`,
            }}
          >
            {letter === " " ? "\u00A0" : letter}
          </span>
        ))}
      </div>
    </div>
  )
}
