"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useAudio } from "@/contexts/audio-context"
import { cn } from "@/lib/utils"

interface ParallaxInteractiveButtonProps {
  children: React.ReactNode
  onClick?: () => void
  className?: string
  disabled?: boolean
  icon?: string
  iconPosition?: "left" | "right"
  theme?: string
  depth?: number
  soundEffect?: string
  hoverSoundEffect?: string
}

export function ParallaxInteractiveButton({
  children,
  onClick,
  className,
  disabled = false,
  icon,
  iconPosition = "left",
  theme = "default",
  depth = 0.1,
  soundEffect,
  hoverSoundEffect,
}: ParallaxInteractiveButtonProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isPressed, setIsPressed] = useState(false)
  const buttonRef = useRef<HTMLButtonElement>(null)

  // Usar try/catch para lidar com o caso em que o contexto de áudio não está disponível
  let playEffect: (effectId: string) => boolean = () => false
  const audio = useAudio()
  try {
    playEffect = audio.playEffect
  } catch (error) {
    console.warn("Contexto de áudio não disponível:", error)
  }

  // Efeito para aplicar transformação 3D
  useEffect(() => {
    const button = buttonRef.current
    if (!button) return

    const handleMouseMove = (e: MouseEvent) => {
      if (disabled) return

      const rect = button.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const centerX = rect.width / 2
      const centerY = rect.height / 2

      const moveX = ((x - centerX) / centerX) * 10
      const moveY = ((y - centerY) / centerY) * 10

      button.style.transform = `perspective(1000px) rotateX(${-moveY}deg) rotateY(${moveX}deg) translateZ(${depth * 10}px)`
    }

    const handleMouseLeave = () => {
      button.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0)`
    }

    button.addEventListener("mousemove", handleMouseMove)
    button.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      button.removeEventListener("mousemove", handleMouseMove)
      button.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [disabled, depth])

  // Função para lidar com o clique
  const handleClick = () => {
    if (disabled) return

    // Tocar efeito sonoro específico ou baseado no tema
    if (soundEffect) {
      playEffect(soundEffect)
    } else {
      playEffect(`click_${theme}`)
    }

    if (onClick) onClick()
  }

  // Função para lidar com o hover
  const handleMouseEnter = () => {
    if (disabled) return
    setIsHovered(true)

    // Tocar efeito sonoro de hover
    if (hoverSoundEffect) {
      playEffect(hoverSoundEffect)
    } else {
      playEffect(`hover_${theme}`)
    }
  }

  // Função para lidar com o mouse down
  const handleMouseDown = () => {
    if (disabled) return
    setIsPressed(true)
  }

  // Função para lidar com o mouse up
  const handleMouseUp = () => {
    if (disabled) return
    setIsPressed(false)
  }

  // Obter cor de brilho baseada no tema
  const getGlowColor = () => {
    switch (theme) {
      case "superhero":
        return "rgba(239, 68, 68, 0.7)" // red
      case "space":
        return "rgba(99, 102, 241, 0.7)" // indigo
      case "dinosaur":
        return "rgba(34, 197, 94, 0.7)" // green
      case "pirate":
        return "rgba(180, 83, 9, 0.7)" // amber
      case "castle":
        return "rgba(236, 72, 153, 0.7)" // pink
      case "jungle":
        return "rgba(234, 179, 8, 0.7)" // yellow
      case "ocean":
        return "rgba(59, 130, 246, 0.7)" // blue
      case "farm":
        return "rgba(22, 163, 74, 0.7)" // green
      default:
        return "rgba(59, 130, 246, 0.7)" // blue
    }
  }

  return (
    <button
      ref={buttonRef}
      onClick={handleClick}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={() => setIsHovered(false)}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      disabled={disabled}
      className={cn("relative overflow-hidden transition-all duration-300", "transform-gpu", className)}
      style={{
        boxShadow: isHovered && !disabled ? `0 0 ${isPressed ? 10 : 20}px ${getGlowColor()}` : "none",
        transform: `perspective(1000px) translateZ(0)`,
        transition: "box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out",
      }}
    >
      <div className="relative z-10 flex items-center justify-center">
        {icon && iconPosition === "left" && (
          <div className="mr-2 relative w-6 h-6">
            <img src={icon || "/placeholder.svg"} alt="ícone" width={24} height={24} />
          </div>
        )}

        {children}

        {icon && iconPosition === "right" && (
          <div className="ml-2 relative w-6 h-6">
            <img src={icon || "/placeholder.svg"} alt="ícone" width={24} height={24} />
          </div>
        )}
      </div>

      {isHovered && !disabled && (
        <div className="absolute inset-0 z-0">
          {[...Array(5)].map((_, i) => (
            <div
              key={`sparkle-${i}`}
              className="absolute w-1 h-1 bg-white rounded-full animate-sparkle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                opacity: 0.7,
                animationDelay: `${Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      )}
    </button>
  )
}
