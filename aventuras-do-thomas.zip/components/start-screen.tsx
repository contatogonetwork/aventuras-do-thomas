"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Book } from "lucide-react"
import { EnhancedSpaceBackground } from "./enhanced-space-background"
import { AnimatedMonkey } from "./animated-monkey"
import { ParallaxInteractiveButton } from "./parallax-interactive-button"
import { ParallaxTitle } from "./parallax-title"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { useOptimizedIcons } from "@/hooks/use-optimized-icons"
import { useAudioParallax } from "@/hooks/use-audio-parallax"
import { useAudio } from "@/contexts/audio-context"

interface StartScreenProps {
  onThemeSelect: (theme: string) => void
  onDurationSelect: (duration: string) => void
  onStartAdventure: () => void
  selectedTheme: string | null
  selectedDuration: string | null
}

export function StartScreen({
  onThemeSelect,
  onDurationSelect,
  onStartAdventure,
  selectedTheme,
  selectedDuration,
}: StartScreenProps) {
  const [hoveredIcon, setHoveredIcon] = useState<string | null>(null)
  const { themes, iconsLoaded, animatingIcons } = useOptimizedIcons()
  const { playEffect } = useAudio()
  const router = useRouter()

  const { containerRef, nightMode } = useAudioParallax<HTMLDivElement>({
    enabled: true,
    mobileEnabled: true,
  })

  const handleThemeSelect = (theme: string) => {
    playEffect("theme_select")
    onThemeSelect(theme)
  }

  const handleDurationSelect = (duration: string) => {
    playEffect("duration_select")
    onDurationSelect(duration)
  }

  const handleStartAdventure = () => {
    if (selectedTheme && selectedDuration) {
      playEffect("start_adventure")
      onStartAdventure()
    }
  }

  const handleGoToNarrativas = () => {
    playEffect("page_turn")
    router.push("/narrativas")
  }

  return (
    <div className="relative min-h-screen flex flex-col items-center p-4">
      <EnhancedSpaceBackground intensity={1.2} />

      {/* Conteúdo principal (com z-index para ficar acima do background) */}
      <div ref={containerRef} className="relative z-10 flex flex-col items-center w-full">
        {/* Título com efeito parallax */}
        <div className="w-full max-w-md mb-6 mt-4">
          <ParallaxTitle
            text="Aventuras do Thomás"
            glowColor={nightMode ? "rgba(96, 165, 250, 0.7)" : "rgba(59, 130, 246, 0.7)"}
            className="text-center text-blue-600"
            depth={0.15}
          />
          <p
            className={cn("text-lg text-center drop-shadow-md", nightMode ? "text-blue-200" : "text-blue-700")}
            data-depth="0.05"
          >
            Escolha sua aventura mágica!
          </p>
        </div>

        {/* Grade de ícones de temas */}
        <div className="grid grid-cols-3 gap-4 w-full max-w-md mb-8">
          {themes.map((theme, index) => (
            <button
              key={theme.id}
              onClick={() => handleThemeSelect(theme.id)}
              onMouseEnter={() => {
                setHoveredIcon(theme.id)
                playEffect("theme_hover")
              }}
              onMouseLeave={() => setHoveredIcon(null)}
              className={cn(
                "relative rounded-2xl overflow-hidden shadow-lg transition-all duration-300 transform aspect-square",
                "bg-gradient-to-br",
                theme.color,
                selectedTheme === theme.id
                  ? "ring-4 ring-yellow-400 scale-110 z-10"
                  : hoveredIcon === theme.id
                    ? "scale-105 shadow-xl"
                    : "",
                animatingIcons ? `animate-float-in delay-${index * 100}` : "",
                !iconsLoaded ? "bg-gray-200" : "",
              )}
              aria-label={`Tema ${theme.name}`}
              data-depth={selectedTheme === theme.id ? "0.12" : "0.08"}
              style={{
                animationDelay: animatingIcons ? `${index * 100}ms` : "0ms",
              }}
            >
              {/* Efeito de brilho quando selecionado */}
              {selectedTheme === theme.id && (
                <div className="absolute inset-0 bg-yellow-300 opacity-20 animate-pulse-slow z-0"></div>
              )}

              {/* Efeito de partículas quando hover */}
              {hoveredIcon === theme.id && (
                <div className="absolute inset-0 z-0">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={`sparkle-${i}`}
                      className="absolute w-1.5 h-1.5 bg-white rounded-full animate-sparkle"
                      style={{
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                        opacity: 0.7,
                        animationDelay: `${Math.random() * 1}s`,
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Conteúdo do ícone */}
              <div className="absolute inset-0 flex items-center justify-center">
                {theme.id === "monkey" ? (
                  <AnimatedMonkey />
                ) : (
                  <div className="relative w-full h-full">
                    {theme.icon && (
                      <Image
                        src={theme.icon || "/placeholder.svg"}
                        alt={theme.name}
                        fill
                        className={cn(
                          "object-cover z-10 transition-transform duration-300",
                          hoveredIcon === theme.id ? "scale-110" : "",
                          selectedTheme === theme.id ? "animate-bounce-gentle" : "",
                        )}
                        sizes="(max-width: 768px) 33vw, 120px"
                        quality={75}
                        loading={index < 6 ? "eager" : "lazy"}
                        placeholder="blur"
                        blurDataURL={
                          theme.blurDataURL ||
                          "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2NjY2NjYyIvPjwvc3ZnPg=="
                        }
                      />
                    )}
                  </div>
                )}
              </div>

              {/* Nome do tema */}
              <div
                className={cn(
                  "absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs font-bold py-1 text-center",
                  "opacity-0 transition-opacity duration-300",
                  hoveredIcon === theme.id || selectedTheme === theme.id ? "opacity-100" : "",
                )}
              >
                {theme.name}
              </div>
            </button>
          ))}
        </div>

        {/* Botão de duração (CURTA/LONGA) */}
        <div className="w-full max-w-md mb-6" data-depth="0.07">
          <div className="w-full h-14 rounded-full flex overflow-hidden shadow-lg" aria-label="Selecionar duração">
            <ParallaxInteractiveButton
              onClick={() => handleDurationSelect("short")}
              className={cn(
                "w-1/2 h-full flex items-center justify-center text-white font-bold text-xl transition-colors",
                selectedDuration === "short" ? "bg-teal-500" : "bg-teal-400 hover:bg-teal-500",
              )}
              icon="/stickers/foguete.png"
              iconPosition="left"
              theme="space"
              soundEffect="duration_select"
              depth={0.1}
            >
              CURTA
            </ParallaxInteractiveButton>
            <ParallaxInteractiveButton
              onClick={() => handleDurationSelect("long")}
              className={cn(
                "w-1/2 h-full flex items-center justify-center text-white font-bold text-xl transition-colors",
                selectedDuration === "long" ? "bg-indigo-600" : "bg-indigo-500 hover:bg-indigo-600",
              )}
              icon="/stickers/planeta2.png"
              iconPosition="right"
              theme="space"
              soundEffect="duration_select"
              depth={0.1}
            >
              LONGA
            </ParallaxInteractiveButton>
          </div>
        </div>

        {/* Botão de começar aventura */}
        <div data-depth="0.09">
          <ParallaxInteractiveButton
            onClick={handleStartAdventure}
            disabled={!selectedTheme || !selectedDuration}
            className={cn(
              "w-full max-w-md py-4 rounded-full text-xl font-bold text-white shadow-lg transition-all",
              selectedTheme && selectedDuration
                ? "bg-orange-500 hover:bg-orange-600"
                : "bg-gray-400 cursor-not-allowed",
            )}
            icon="/stickers/nave.png"
            iconPosition="right"
            theme="space"
            soundEffect="start_adventure"
            depth={0.12}
          >
            COMEÇAR AVENTURA
          </ParallaxInteractiveButton>
        </div>

        {/* Botão para ir para narrativas */}
        <div className="mt-6" data-depth="0.07">
          <ParallaxInteractiveButton
            onClick={handleGoToNarrativas}
            className="flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg"
            theme="default"
            soundEffect="page_turn"
            depth={0.1}
          >
            <Book size={20} className="mr-2" /> Ver Narrativas Especiais
          </ParallaxInteractiveButton>
        </div>
      </div>
    </div>
  )
}
