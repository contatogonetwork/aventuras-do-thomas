"use client"

import { useEffect, useState, useRef } from "react"
import Image from "next/image"

export function SpaceBackground() {
  const [mounted, setMounted] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setMounted(true)

    const container = containerRef.current
    if (!container) return

    // Parallax responsivo
    const handleMovement = (e: MouseEvent | TouchEvent) => {
      const elements = container.querySelectorAll(".parallax-element")
      let clientX, clientY
      if ("touches" in e) {
        clientX = e.touches[0].clientX
        clientY = e.touches[0].clientY
      } else {
        clientX = e.clientX
        clientY = e.clientY
      }
      const centerX = window.innerWidth / 2
      const centerY = window.innerHeight / 2
      const offsetX = (clientX - centerX) / centerX
      const offsetY = (clientY - centerY) / centerY
      elements.forEach((element) => {
        const depth = Number.parseFloat(element.getAttribute("data-depth") || "0.1")
        const moveX = offsetX * depth * 60
        const moveY = offsetY * depth * 60
        ;(element as HTMLElement).style.transform = `translate3d(${moveX}px, ${moveY}px, 0)`
      })
    }

    container.addEventListener("mousemove", handleMovement)
    container.addEventListener("touchmove", handleMovement)

    return () => {
      container.removeEventListener("mousemove", handleMovement)
      container.removeEventListener("touchmove", handleMovement)
    }
  }, [])

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-hidden z-0"
      style={{
        opacity: mounted ? 1 : 0,
        transition: "opacity 0.7s cubic-bezier(.4,2,.6,1)",
        // Fundo mais "night sky", tons escuros e roxos suaves
        background: "radial-gradient(ellipse at 60% 10%, #363f64 0%, #140d2a 100%)",
      }}
    >
      {/* Estrelas pequenas */}
      {[...Array(40)].map((_, i) => (
        <div
          key={`star-${i}`}
          className="parallax-element absolute rounded-full"
          data-depth={Math.random() * 0.15 + 0.02}
          style={{
            width: `${Math.random() * 2 + 1}px`,
            height: `${Math.random() * 2 + 1}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: `rgba(255,255,${Math.floor(Math.random() * 80 + 200)},${Math.random() * 0.5 + 0.5})`,
            boxShadow: "0 0 6px 2px #fff7",
            zIndex: 1,
          }}
        />
      ))}

      {/* Estrelas brilhantes maiores */}
      {[...Array(12)].map((_, i) => (
        <div
          key={`star-big-${i}`}
          className="parallax-element absolute rounded-full"
          data-depth={Math.random() * 0.2 + 0.15}
          style={{
            width: `${Math.random() * 7 + 5}px`,
            height: `${Math.random() * 7 + 5}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: "white",
            boxShadow: "0 0 20px 6px #fff, 0 0 60px 12px #fff4",
            opacity: 0.8,
            zIndex: 2,
          }}
        />
      ))}

      {/* Planetas coloridos */}
      <div
        className="parallax-element absolute rounded-full"
        data-depth="0.22"
        style={{
          width: "90px",
          height: "90px",
          left: "12%",
          top: "16%",
          background: "radial-gradient(circle at 65% 35%, #ffeaa7 0%, #fd79a8 80%, #3d3d94 100%)",
          boxShadow: "0 0 40px 10px #fd79a880",
          border: "2px solid #fff6",
          zIndex: 5,
        }}
      />
      <div
        className="parallax-element absolute rounded-full"
        data-depth="0.16"
        style={{
          width: "60px",
          height: "60px",
          left: "70%",
          top: "25%",
          background: "radial-gradient(circle at 30% 70%, #81ecec 0%, #0984e3 80%, #2e1a47 100%)",
          boxShadow: "0 0 32px 10px #81ecec99",
          border: "2px solid #fff6",
          zIndex: 5,
        }}
      />
      <div
        className="parallax-element absolute rounded-full"
        data-depth="0.18"
        style={{
          width: "70px",
          height: "70px",
          left: "18%",
          top: "65%",
          background: "radial-gradient(circle at 60% 40%, #ffeaa7 0%, #00b894 90%)",
          boxShadow: "0 0 30px 8px #00b89488",
          border: "2px solid #fff6",
          zIndex: 5,
        }}
      />

      {/* Foguete animado */}
      <div
        className="parallax-element absolute"
        data-depth="0.28"
        style={{
          width: "64px",
          height: "64px",
          left: "62%",
          top: "70%",
          zIndex: 10,
          pointerEvents: "none",
        }}
      >
        <Image
          src="/space/rocket1.png"
          alt="Foguete"
          width={64}
          height={64}
          className="animate-rocket-wiggle"
          draggable={false}
        />
      </div>

      {/* Astronauta animado */}
      <div
        className="parallax-element absolute"
        data-depth="0.35"
        style={{
          width: "64px",
          height: "64px",
          left: "80%",
          top: "60%",
          zIndex: 10,
          pointerEvents: "none",
        }}
      >
        <Image
          src="/space/astronaut1.png"
          alt="Astronauta"
          width={64}
          height={64}
          className="animate-astronaut-float"
          draggable={false}
        />
      </div>

      {/* Outro astronauta */}
      <div
        className="parallax-element absolute"
        data-depth="0.19"
        style={{
          width: "48px",
          height: "48px",
          left: "28%",
          top: "32%",
          zIndex: 8,
          pointerEvents: "none",
        }}
      >
        <Image
          src="/space/astronaut2.png"
          alt="Astronauta 2"
          width={48}
          height={48}
          className="animate-astronaut-float"
          draggable={false}
        />
      </div>

      {/* Cometa colorido */}
      <div
        className="parallax-element absolute"
        data-depth="0.29"
        style={{
          width: "110px",
          height: "28px",
          left: "11%",
          top: "82%",
          zIndex: 10,
          pointerEvents: "none",
        }}
      >
        <Image
          src="/space/comet1.png"
          alt="Cometa"
          width={110}
          height={28}
          className="animate-comet-slide"
          draggable={false}
        />
      </div>

      {/* Lua sorridente */}
      <div
        className="parallax-element absolute"
        data-depth="0.12"
        style={{
          width: "70px",
          height: "70px",
          left: "84%",
          top: "10%",
          zIndex: 7,
          pointerEvents: "none",
        }}
      >
        <Image src="/space/moon1.png" alt="Lua" width={70} height={70} draggable={false} />
      </div>

      {/* Brilho suave para dar efeito de "cosmos" */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(circle at 70% 80%, #ffffff11 0%, transparent 60%)",
        }}
      />

      {/* Animações CSS */}
      <style jsx global>{`
        .animate-rocket-wiggle {
          animation: rocket-wiggle 2s infinite alternate ease-in-out;
        }
        @keyframes rocket-wiggle {
          0% { transform: translateY(0) rotate(-8deg);}
          100% { transform: translateY(-18px) rotate(8deg);}
        }
        .animate-astronaut-float {
          animation: astronaut-float 2.5s infinite ease-in-out alternate;
        }
        @keyframes astronaut-float {
          0% { transform: translateY(0);}
          100% { transform: translateY(-12px);}
        }
        .animate-comet-slide {
          animation: comet-slide 5s linear infinite;
        }
        @keyframes comet-slide {
          0% { transform: translateX(-30px) scale(1);}
          100% { transform: translateX(60px) scale(1.2);}
        }
      `}</style>
    </div>
  )
}
