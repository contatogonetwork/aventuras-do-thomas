"use client"

import { type ReactNode, useEffect, useState, useRef } from "react"
import { cn } from "@/lib/utils"
import { useAudio } from "@/contexts/audio-context"
import { FloatingParticles } from "@/components/floating-particles"
import { useAppContext } from "@/contexts/app-context"

interface ThemedBackgroundProps {
  children: ReactNode
  theme?: string
  playAmbient?: boolean
}

export function ThemedBackground({ children, theme = "default", playAmbient = true }: ThemedBackgroundProps) {
  const [mounted, setMounted] = useState(false)
  const { playAmbient: playAmbientSound, stopAmbient } = useAudio()
  const { nightMode } = useAppContext()
  const prevThemeRef = useRef<string>(theme)

  useEffect(() => {
    setMounted(true)

    // Tocar som ambiente baseado no tema apenas se o tema mudou
    if (playAmbient && theme && prevThemeRef.current !== theme) {
      playAmbientSound(theme)
      prevThemeRef.current = theme
    }

    return () => {
      // Parar som ambiente ao desmontar
      if (playAmbient) {
        stopAmbient()
      }
    }
  }, [playAmbient, theme, playAmbientSound, stopAmbient])

  // Cores de fundo baseadas no tema e modo noturno
  const getBackgroundColor = () => {
    if (nightMode) {
      switch (theme) {
        case "superhero":
          return "bg-gradient-to-b from-gray-900 to-red-950"
        case "space":
          return "bg-gradient-to-b from-gray-950 to-indigo-950"
        case "dinosaur":
          return "bg-gradient-to-b from-gray-900 to-green-950"
        case "pirate":
          return "bg-gradient-to-b from-gray-900 to-amber-950"
        case "castle":
          return "bg-gradient-to-b from-gray-900 to-purple-950"
        case "jungle":
        case "forest":
          return "bg-gradient-to-b from-gray-900 to-emerald-950"
        case "ocean":
          return "bg-gradient-to-b from-gray-900 to-blue-950"
        case "farm":
          return "bg-gradient-to-b from-gray-900 to-yellow-950"
        default:
          return "bg-gradient-to-b from-gray-950 to-gray-900"
      }
    } else {
      switch (theme) {
        case "superhero":
          return "bg-gradient-to-b from-red-100 to-blue-100"
        case "space":
          return "bg-gradient-to-b from-indigo-100 to-purple-100"
        case "dinosaur":
          return "bg-gradient-to-b from-green-100 to-yellow-100"
        case "pirate":
          return "bg-gradient-to-b from-amber-100 to-blue-100"
        case "castle":
          return "bg-gradient-to-b from-purple-100 to-pink-100"
        case "jungle":
        case "forest":
          return "bg-gradient-to-b from-emerald-100 to-green-100"
        case "ocean":
          return "bg-gradient-to-b from-blue-100 to-cyan-100"
        case "farm":
          return "bg-gradient-to-b from-yellow-100 to-green-100"
        default:
          return "bg-gradient-to-b from-blue-50 to-purple-50"
      }
    }
  }

  // Determinar o tipo de partículas com base no tema
  const getParticleType = () => {
    switch (theme) {
      case "ocean":
        return "bubbles"
      case "jungle":
      case "forest":
      case "farm":
        return "leaves"
      case "dinosaur":
        return "leaves"
      case "pirate":
        return "confetti"
      case "superhero":
        return "confetti"
      case "space":
      default:
        return "stars"
    }
  }

  return (
    <div
      className={cn(
        "min-h-screen w-full transition-colors duration-500",
        getBackgroundColor(),
        nightMode ? "text-gray-100" : "text-gray-900",
      )}
    >
      <FloatingParticles type={getParticleType()} count={20} intensity={0.8} />
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen">{children}</div>
    </div>
  )
}
