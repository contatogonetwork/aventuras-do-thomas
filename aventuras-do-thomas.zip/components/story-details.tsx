"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { BookOpen, Heart, Info } from "lucide-react"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

interface StoryDetailsProps {
  storyId: string
  title: string
  theme: string
  description: string
  createdAt: Date
  lastRead?: Date
  isFavorite?: boolean
  onToggleFavorite?: () => void
  onStartReading?: () => void
}

export function StoryDetails({
  storyId,
  title,
  theme,
  description,
  createdAt,
  lastRead,
  isFavorite = false,
  onToggleFavorite,
  onStartReading,
}: StoryDetailsProps) {
  const { nightMode } = useAppContext()
  const [date, setDate] = useState<Date | undefined>(lastRead)

  // Função para obter a cor do tema
  const getThemeColor = () => {
    switch (theme) {
      case "space":
        return nightMode ? "bg-indigo-900 text-indigo-100" : "bg-indigo-100 text-indigo-800"
      case "dinosaur":
        return nightMode ? "bg-green-900 text-green-100" : "bg-green-100 text-green-800"
      case "pirate":
        return nightMode ? "bg-amber-900 text-amber-100" : "bg-amber-100 text-amber-800"
      case "castle":
        return nightMode ? "bg-purple-900 text-purple-100" : "bg-purple-100 text-purple-800"
      case "jungle":
        return nightMode ? "bg-emerald-900 text-emerald-100" : "bg-emerald-100 text-emerald-800"
      case "ocean":
        return nightMode ? "bg-blue-900 text-blue-100" : "bg-blue-100 text-blue-800"
      case "farm":
        return nightMode ? "bg-yellow-900 text-yellow-100" : "bg-yellow-100 text-yellow-800"
      case "superhero":
        return nightMode ? "bg-red-900 text-red-100" : "bg-red-100 text-red-800"
      default:
        return nightMode ? "bg-gray-800 text-gray-100" : "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Breadcrumb */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="mb-4"
      >
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/" className={nightMode ? "text-gray-300 hover:text-white" : ""}>
                Início
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href="/narrativas" className={nightMode ? "text-gray-300 hover:text-white" : ""}>
                Narrativas
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink className={nightMode ? "text-gray-100" : ""}>{title}</BreadcrumbLink>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </motion.div>

      {/* Alerta para histórias novas */}
      {new Date().getTime() - createdAt.getTime() < 7 * 24 * 60 * 60 * 1000 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="mb-6"
        >
          <Alert className={nightMode ? "bg-blue-900/30 border-blue-700" : ""}>
            <Info className="h-4 w-4" />
            <AlertTitle>Nova história!</AlertTitle>
            <AlertDescription className={nightMode ? "text-gray-300" : ""}>
              Esta história foi adicionada recentemente à nossa biblioteca. Aproveite esta nova aventura!
            </AlertDescription>
          </Alert>
        </motion.div>
      )}

      {/* Card principal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className={cn(nightMode ? "bg-gray-800 text-gray-100 border-gray-700" : "")}>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-3xl">{title}</CardTitle>
                <CardDescription className={nightMode ? "text-gray-300" : ""}>
                  Uma aventura incrível no tema {theme}
                </CardDescription>
              </div>
              <Badge className={getThemeColor()}>{theme}</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <h3 className="text-lg font-semibold mb-2">Sobre esta história</h3>
                <p className={cn("text-gray-600 mb-4", nightMode && "text-gray-300")}>{description}</p>

                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="personagens" className={nightMode ? "border-gray-700" : ""}>
                    <AccordionTrigger className={nightMode ? "hover:text-gray-100" : ""}>Personagens</AccordionTrigger>
                    <AccordionContent>
                      <div className="flex flex-wrap gap-4">
                        <div className="flex items-center gap-2">
                          <Avatar>
                            <AvatarImage src="/placeholder.svg?key=svjzc" alt="Thomás" />
                            <AvatarFallback>TH</AvatarFallback>
                          </Avatar>
                          <span>Thomás</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Avatar>
                            <AvatarImage src="/placeholder.svg?key=znojy" alt="Zorp" />
                            <AvatarFallback>ZP</AvatarFallback>
                          </Avatar>
                          <span>Zorp</span>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="cenarios" className={nightMode ? "border-gray-700" : ""}>
                    <AccordionTrigger className={nightMode ? "hover:text-gray-100" : ""}>Cenários</AccordionTrigger>
                    <AccordionContent>
                      <p>
                        Esta história se passa em vários cenários mágicos, incluindo o espaço sideral, a Lua e o quintal
                        de Thomás.
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2">Última leitura</h3>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className={cn("rounded-md border", nightMode && "bg-gray-700 border-gray-600")}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={onToggleFavorite}
              className={nightMode ? "border-gray-600 hover:bg-gray-700" : ""}
            >
              <Heart className={cn("mr-2", isFavorite && "fill-red-500 text-red-500")} />
              {isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
            </Button>
            <Button onClick={onStartReading}>
              <BookOpen className="mr-2" />
              Começar a ler
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  )
}
