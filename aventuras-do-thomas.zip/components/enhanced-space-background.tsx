"use client"

import { useEffect, useState } from "react"
import { useAudioParallax } from "@/hooks/use-audio-parallax"
import { useAppContext } from "@/contexts/app-context"

interface EnhancedSpaceBackgroundProps {
  intensity?: number
  mobileEnabled?: boolean
  soundEffects?: boolean
}

export function EnhancedSpaceBackground({
  intensity = 1,
  mobileEnabled = true,
  soundEffects = true,
}: EnhancedSpaceBackgroundProps) {
  const [mounted, setMounted] = useState(false)
  const { nightMode } = useAppContext()

  // Mapeamento de sons para elementos específicos
  const soundMapping = {
    "planet-saturn": "planet_hover",
    rocket: "rocket_hover",
    ufo: "ufo_hover",
    astronaut: "astronaut_hover",
    satellite: "satellite_hover",
    comet: "comet_hover",
  }

  const { containerRef } = useAudioParallax<HTMLDivElement>({
    enabled: true,
    mobileEnabled,
    sensitivity: intensity,
    soundEffects,
    soundMapping,
    theme: "space",
  })

  useEffect(() => {
    setMounted(true)
  }, [])

  // Renderizar estrelas com diferentes profundidades
  const renderStars = (count: number) =>
    Array.from({ length: count }).map((_, i) => {
      const size = Math.random() * 2 + 1.5
      const colors = nightMode
        ? ["#fff", "#ffe066", "#ff6bcb", "#4fd8ff", "#c3fae8", "#ffd6e0"]
        : ["#fff", "#ffe066", "#ff6bcb", "#4fd8ff", "#c3fae8", "#ffd6e0"]
      const color = colors[Math.floor(Math.random() * colors.length)]
      const depth = Math.random() * 0.12 + 0.02

      return (
        <div
          key={`star-${i}`}
          className="absolute rounded-full"
          data-depth={depth.toFixed(3)}
          style={{
            width: `${size}px`,
            height: `${size}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: color,
            boxShadow: `0 0 6px 2px ${color}88`,
            zIndex: 1,
          }}
        />
      )
    })

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-hidden z-0"
      style={{
        background: nightMode
          ? `url('https://img.freepik.com/free-vector/dark-gradient-galaxy-background_23-2150890716.jpg?w=740') center center / cover no-repeat`
          : `url('https://img.freepik.com/free-vector/gradient-galaxy-background_23-2150890716.jpg?w=740') center center / cover no-repeat`,
        opacity: mounted ? 1 : 0,
        transition: "opacity 0.7s cubic-bezier(.4,2,.6,1)",
      }}
    >
      {/* Estrelas coloridas */}
      {renderStars(90)}

      {/* Lua cartoon no canto inferior esquerdo */}
      <img
        src="https://pngimg.com/d/moon_PNG52.png"
        alt="Lua"
        data-depth="0.05"
        style={{
          position: "absolute",
          left: "-50px",
          bottom: "-10px",
          width: "220px",
          height: "90px",
          opacity: 0.9,
          zIndex: 2,
          pointerEvents: "none",
          filter: "drop-shadow(0 0 24px #fff7)",
        }}
        draggable={false}
      />

      {/* Planeta laranja com anel */}
      <img
        id="planet-saturn"
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Saturn_%28cartoon%29.svg/1200px-Saturn_%28cartoon%29.svg.png"
        alt="Planeta com anel"
        data-depth="0.22"
        style={{
          position: "absolute",
          left: "65%",
          top: "22%",
          width: "90px",
          height: "90px",
          zIndex: 4,
          pointerEvents: "none",
        }}
        draggable={false}
      />

      {/* Foguete colorido */}
      <img
        id="rocket"
        src="https://cdn.pixabay.com/photo/2017/01/31/13/14/rocket-2028245_1280.png"
        alt="Foguete"
        data-depth="0.27"
        style={{
          position: "absolute",
          left: "58%",
          top: "68%",
          width: "80px",
          height: "80px",
          zIndex: 10,
          pointerEvents: "none",
          filter: "drop-shadow(0 0 16px #fff7)",
        }}
        draggable={false}
      />

      {/* Alienígena cartoon em nave */}
      <img
        id="ufo"
        src="https://pngimg.com/d/ufo_PNG17.png"
        alt="Alienígena em nave"
        data-depth="0.26"
        style={{
          position: "absolute",
          left: "15%",
          top: "35%",
          width: "95px",
          height: "95px",
          zIndex: 10,
          pointerEvents: "none",
        }}
        draggable={false}
      />

      {/* Astronauta cartoon no centro */}
      <img
        id="astronaut"
        src="https://cdn.pixabay.com/photo/2014/12/21/23/55/astronaut-579049_1280.png"
        alt="Astronauta"
        data-depth="0.34"
        style={{
          position: "absolute",
          left: "42%",
          top: "32%",
          width: "120px",
          height: "120px",
          zIndex: 11,
          pointerEvents: "none",
        }}
        draggable={false}
      />

      {/* Satélite cartoon canto superior esquerdo */}
      <img
        id="satellite"
        src="https://static.vecteezy.com/system/resources/previews/029/944/441/original/satellite-cartoon-icon-in-flat-style-illustration-vector.jpg"
        alt="Satélite"
        data-depth="0.16"
        style={{
          position: "absolute",
          left: "7%",
          top: "6%",
          width: "60px",
          height: "60px",
          zIndex: 7,
          pointerEvents: "none",
        }}
        draggable={false}
      />

      {/* Cometa colorido */}
      <img
        id="comet"
        src="https://pngimg.com/d/comet_PNG17.png"
        alt="Cometa"
        data-depth="0.23"
        style={{
          position: "absolute",
          left: "8%",
          top: "80%",
          width: "110px",
          height: "32px",
          zIndex: 9,
          pointerEvents: "none",
        }}
        draggable={false}
      />
    </div>
  )
}
