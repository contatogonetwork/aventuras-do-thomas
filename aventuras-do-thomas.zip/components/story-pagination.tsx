"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { useAudio } from "@/contexts/audio-context"
import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"

interface StoryPaginationProps {
  totalPages: number
  currentPage: number
  baseUrl: string
}

export function StoryPagination({ totalPages, currentPage, baseUrl }: StoryPaginationProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { playEffect } = useAudio()
  const { nightMode } = useAppContext()

  // Criar uma nova instância de URLSearchParams para manipular os parâmetros
  const createPageUrl = (page: number) => {
    const params = new URLSearchParams(searchParams.toString())
    params.set("page", page.toString())
    return `${baseUrl}?${params.toString()}`
  }

  // Determinar quais páginas mostrar
  const getPageNumbers = () => {
    const pages = []

    // Sempre mostrar a primeira página
    pages.push(1)

    // Adicionar elipses se necessário
    if (currentPage > 3) {
      pages.push("ellipsis1")
    }

    // Adicionar páginas ao redor da página atual
    for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
      if (i > 1 && i < totalPages) {
        pages.push(i)
      }
    }

    // Adicionar elipses se necessário
    if (currentPage < totalPages - 2) {
      pages.push("ellipsis2")
    }

    // Sempre mostrar a última página se houver mais de uma página
    if (totalPages > 1) {
      pages.push(totalPages)
    }

    return pages
  }

  const handlePageClick = (page: number) => {
    if (page !== currentPage) {
      playEffect("click")
      router.push(createPageUrl(page))
    }
  }

  // Se houver apenas uma página, não mostrar a paginação
  if (totalPages <= 1) {
    return null
  }

  return (
    <Pagination>
      <PaginationContent>
        <PaginationItem>
          <PaginationPrevious
            href={currentPage > 1 ? createPageUrl(currentPage - 1) : "#"}
            onClick={(e) => {
              if (currentPage <= 1) {
                e.preventDefault()
                return
              }
              playEffect("click")
            }}
            className={cn(
              currentPage <= 1 && "pointer-events-none opacity-50",
              nightMode && "text-gray-300 hover:text-white",
            )}
          />
        </PaginationItem>

        {getPageNumbers().map((page, i) => {
          if (page === "ellipsis1" || page === "ellipsis2") {
            return (
              <PaginationItem key={`ellipsis-${i}`}>
                <PaginationEllipsis />
              </PaginationItem>
            )
          }

          const isActive = page === currentPage

          return (
            <PaginationItem key={page}>
              <PaginationLink
                href={createPageUrl(page as number)}
                isActive={isActive}
                onClick={(e) => {
                  e.preventDefault()
                  handlePageClick(page as number)
                }}
                className={nightMode && !isActive ? "text-gray-300 hover:text-white" : ""}
              >
                {page}
              </PaginationLink>
            </PaginationItem>
          )
        })}

        <PaginationItem>
          <PaginationNext
            href={currentPage < totalPages ? createPageUrl(currentPage + 1) : "#"}
            onClick={(e) => {
              if (currentPage >= totalPages) {
                e.preventDefault()
                return
              }
              playEffect("click")
            }}
            className={cn(
              currentPage >= totalPages && "pointer-events-none opacity-50",
              nightMode && "text-gray-300 hover:text-white",
            )}
          />
        </PaginationItem>
      </PaginationContent>
    </Pagination>
  )
}
