"use client"

import { useState, useEffect } from "react"
import Image from "next/image"

export function AnimatedMonkey() {
  const [frame, setFrame] = useState(0)
  const [direction, setDirection] = useState(1)
  const totalFrames = 3

  useEffect(() => {
    const interval = setInterval(() => {
      setFrame((prevFrame) => {
        const nextFrame = prevFrame + direction
        if (nextFrame >= totalFrames - 1) {
          setDirection(-1)
          return totalFrames - 1
        } else if (nextFrame <= 0) {
          setDirection(1)
          return 0
        }
        return nextFrame
      })
    }, 300)

    return () => clearInterval(interval)
  }, [direction])

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <Image
        src={`/stickers/monkey${frame + 1}.png`}
        alt="Macaco animado"
        width={100}
        height={100}
        className="object-contain"
      />
    </div>
  )
}
