"use client"

import { useState, useEffect } from "react"
import { Moon, Sun } from "lucide-react"
import { motion } from "framer-motion"
import { useAppContext } from "@/contexts/app-context"
import { useAudio } from "@/contexts/audio-context"
import { cn } from "@/lib/utils"

interface NightModeToggleProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function NightModeToggle({ className, size = "md" }: NightModeToggleProps) {
  const { nightMode, setNightMode } = useAppContext()
  const { playEffect } = useAudio()
  const [mounted, setMounted] = useState(false)

  // Evitar problemas de hidratação
  useEffect(() => {
    setMounted(true)
  }, [])

  const toggleNightMode = () => {
    playEffect("toggle_mode")
    setNightMode(!nightMode)
  }

  // Tamanhos do botão
  const sizeClasses = {
    sm: "w-10 h-5",
    md: "w-14 h-7",
    lg: "w-16 h-8",
  }

  // Tamanhos do ícone
  const iconSizes = {
    sm: 12,
    md: 16,
    lg: 20,
  }

  if (!mounted) {
    return null
  }

  return (
    <button
      onClick={toggleNightMode}
      className={cn(
        "relative rounded-full p-1 transition-colors duration-300 focus:outline-none",
        nightMode ? "bg-blue-900" : "bg-yellow-400",
        sizeClasses[size],
        className,
      )}
      aria-label={nightMode ? "Ativar modo dia" : "Ativar modo noite"}
    >
      <motion.div
        className={cn(
          "absolute rounded-full flex items-center justify-center",
          nightMode ? "bg-indigo-300" : "bg-white",
          size === "sm" ? "w-3 h-3" : size === "md" ? "w-5 h-5" : "w-6 h-6",
        )}
        initial={false}
        animate={{ x: nightMode ? "100%" : "0%" }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        {nightMode ? (
          <Moon size={iconSizes[size]} className="text-blue-900" />
        ) : (
          <Sun size={iconSizes[size]} className="text-yellow-600" />
        )}
      </motion.div>
    </button>
  )
}
