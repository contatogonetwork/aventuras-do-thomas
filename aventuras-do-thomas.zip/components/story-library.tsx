"use client"

import { useState, useRef, useEffect } from "react"
import { Heart, Download, Trash, Play, Search } from "lucide-react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import { createMagicSound, createSurpriseSound } from "@/lib/audio-generators"
import { useOfflineMode } from "@/hooks/use-offline-mode"
import type { Theme, Story, CustomImages } from "@/types/app-types"

interface StoryLibraryProps {
  stories: Story[]
  themes: Theme[]
  customImages: CustomImages
  onCreateStory: () => void
  onPlayStory?: (storyId: number) => void
  onToggleFavorite?: (storyId: number) => void
  onDownloadStory?: (storyId: number) => void
  onDeleteStory?: (storyId: number) => void
}

export function StoryLibrary({
  stories,
  themes,
  customImages,
  onCreateStory,
  onPlayStory,
  onToggleFavorite,
  onDownloadStory,
  onDeleteStory,
}: StoryLibraryProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterFavorites, setFilterFavorites] = useState(false)
  const [hoveredStory, setHoveredStory] = useState<number | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()
  const { isOffline, saveStoryOffline } = useOfflineMode()

  // Filter stories based on search term and favorites filter
  const filteredStories = stories.filter((story) => {
    const matchesSearch = story.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFavorite = filterFavorites ? story.favorite : true
    return matchesSearch && matchesFavorite
  })

  // Add parallax effect to story cards
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const handleMouseMove = (e: MouseEvent) => {
      const cards = container.querySelectorAll(".story-card")

      cards.forEach((card) => {
        const rect = card.getBoundingClientRect()
        const x = e.clientX - rect.left
        const y = e.clientY - rect.top

        // Calculate distance from center
        const centerX = rect.width / 2
        const centerY = rect.height / 2

        // Calculate offset from center (normalized from -1 to 1)
        const offsetX = (x - centerX) / centerX
        const offsetY = (y - centerY) / centerY

        // Apply subtle rotation based on mouse position
        const rotateX = offsetY * 5 // 5 degrees max
        const rotateY = -offsetX * 5 // 5 degrees max

        // Apply transform
        card.setAttribute(
          "style",
          `transform: perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02);`,
        )
      })
    }

    const handleMouseLeave = () => {
      const cards = container.querySelectorAll(".story-card")
      cards.forEach((card) => {
        card.setAttribute("style", "transform: perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1);")
      })
    }

    container.addEventListener("mousemove", handleMouseMove)
    container.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      container.removeEventListener("mousemove", handleMouseMove)
      container.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [filteredStories.length])

  // Handle play story
  const handlePlayStory = async (storyId: number) => {
    try {
      // Play magic sound effect
      const audio = await createMagicSound()
      audio.volume = 0.3
      audio.play()

      // Call the onPlayStory callback if provided
      if (onPlayStory) {
        onPlayStory(storyId)
      }

      toast({
        title: "Iniciando história",
        description: "Preparando a aventura para começar...",
      })
    } catch (error) {
      console.error("Error playing story:", error)
    }
  }

  // Handle toggle favorite
  const handleToggleFavorite = async (storyId: number) => {
    try {
      // Play surprise sound effect
      const audio = await createSurpriseSound()
      audio.volume = 0.2
      audio.play()

      // Call the onToggleFavorite callback if provided
      if (onToggleFavorite) {
        onToggleFavorite(storyId)
      }

      // Find the story
      const story = stories.find((s) => s.id === storyId)

      if (story) {
        const isFavorite = !story.favorite

        toast({
          title: isFavorite ? "Adicionado aos favoritos" : "Removido dos favoritos",
          description: isFavorite
            ? "Esta história foi adicionada aos seus favoritos!"
            : "Esta história foi removida dos seus favoritos.",
        })
      }
    } catch (error) {
      console.error("Error toggling favorite:", error)
    }
  }

  // Handle download story
  const handleDownloadStory = async (storyId: number) => {
    try {
      // Find the story
      const story = stories.find((s) => s.id === storyId)

      if (story) {
        // Save story for offline use
        const saved = await saveStoryOffline(story)

        if (saved) {
          toast({
            title: "História salva",
            description: "Esta história está disponível para leitura offline.",
          })
        } else {
          toast({
            title: "Erro ao salvar",
            description: "Não foi possível salvar a história para uso offline.",
            variant: "destructive",
          })
        }
      }

      // Call the onDownloadStory callback if provided
      if (onDownloadStory) {
        onDownloadStory(storyId)
      }
    } catch (error) {
      console.error("Error downloading story:", error)

      toast({
        title: "Erro ao baixar",
        description: "Ocorreu um erro ao baixar a história.",
        variant: "destructive",
      })
    }
  }

  // Handle delete story
  const handleDeleteStory = (storyId: number) => {
    // Call the onDeleteStory callback if provided
    if (onDeleteStory) {
      onDeleteStory(storyId)
    }

    toast({
      title: "História excluída",
      description: "A história foi removida da sua biblioteca.",
    })
  }

  return (
    <div className="w-full max-w-2xl bg-white rounded-3xl shadow-xl p-6" ref={containerRef}>
      <h2 className="text-3xl font-bold text-blue-700 mb-6">Biblioteca de Histórias</h2>

      {/* Search and filter controls */}
      <div className="mb-6 flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar histórias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          </div>
        </div>
        <div className="flex items-center">
          <button
            onClick={() => setFilterFavorites(!filterFavorites)}
            className={cn(
              "flex items-center px-4 py-2 rounded-lg transition-all",
              filterFavorites ? "bg-red-100 text-red-500" : "bg-gray-100 text-gray-500",
              "hover:bg-red-100 hover:text-red-500",
            )}
          >
            <Heart size={20} className="mr-2" fill={filterFavorites ? "currentColor" : "none"} />
            Favoritos
          </button>
        </div>
      </div>

      {filteredStories.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500 text-xl">
            {searchTerm || filterFavorites ? "Nenhuma história encontrada." : "Nenhuma história salva ainda."}
          </p>
          <button
            onClick={onCreateStory}
            className="mt-4 px-6 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors"
          >
            Criar História
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredStories.map((story) => {
            const themeColor = themes.find((t) => t.id === story.theme)?.color || "#e5e7eb"

            return (
              <div
                key={story.id}
                className={cn(
                  "story-card flex items-center p-4 rounded-xl transition-all duration-300",
                  "hover:shadow-md",
                )}
                style={{
                  background: `linear-gradient(135deg, ${themeColor}33, ${themeColor}11)`,
                  borderLeft: `4px solid ${themeColor}`,
                }}
                onMouseEnter={() => setHoveredStory(story.id)}
                onMouseLeave={() => setHoveredStory(null)}
              >
                <div className="w-16 h-16 flex items-center justify-center rounded-full bg-white mr-4 overflow-hidden shadow-md">
                  {customImages[story.theme] ? (
                    <img
                      src={customImages[story.theme] || "/placeholder.svg?height=64&width=64&query=cartoon%20character"}
                      alt={`Imagem da história ${story.title}`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-3xl" aria-hidden="true">
                      {themes.find((t) => t.id === story.theme)?.icon || "📖"}
                    </span>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold">{story.title}</h3>
                  <p className="text-gray-600 text-sm">Criada em: {story.date}</p>
                </div>
                <div className="flex space-x-2">
                  <button
                    className={cn(
                      "p-2 rounded-full transition-transform",
                      hoveredStory === story.id ? "scale-110" : "",
                      "bg-white text-blue-500 hover:bg-blue-50",
                    )}
                    onClick={() => handlePlayStory(story.id)}
                    aria-label="Reproduzir história"
                  >
                    <Play size={20} />
                  </button>
                  <button
                    className={cn(
                      "p-2 rounded-full transition-transform",
                      hoveredStory === story.id ? "scale-110" : "",
                      "bg-white",
                      story.favorite ? "text-red-500" : "text-gray-400 hover:text-red-500",
                    )}
                    onClick={() => handleToggleFavorite(story.id)}
                    aria-label={story.favorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}
                  >
                    <Heart size={20} fill={story.favorite ? "currentColor" : "none"} />
                  </button>
                  <button
                    className={cn(
                      "p-2 rounded-full transition-transform",
                      hoveredStory === story.id ? "scale-110" : "",
                      "bg-white text-blue-500 hover:bg-blue-50",
                    )}
                    onClick={() => handleDownloadStory(story.id)}
                    aria-label="Baixar história"
                  >
                    <Download size={20} />
                  </button>
                  <button
                    className={cn(
                      "p-2 rounded-full transition-transform",
                      hoveredStory === story.id ? "scale-110" : "",
                      "bg-white text-red-500 hover:bg-red-50",
                    )}
                    onClick={() => handleDeleteStory(story.id)}
                    aria-label="Excluir história"
                  >
                    <Trash size={20} />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
