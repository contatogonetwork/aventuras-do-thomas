"use client"

import { useAppContext } from "@/contexts/app-context"
import { cn } from "@/lib/utils"

export function Loading() {
  const { nightMode } = useAppContext()

  return (
    <div
      className={cn(
        "min-h-screen flex items-center justify-center",
        nightMode ? "bg-gradient-to-b from-gray-900 to-indigo-950" : "bg-gradient-to-b from-blue-100 to-purple-100",
      )}
    >
      <div className="text-center">
        <div
          className={cn(
            "inline-block animate-spin rounded-full h-16 w-16 border-b-4 mb-4",
            nightMode ? "border-blue-400" : "border-blue-500",
          )}
        ></div>
        <p className={cn("text-xl font-medium", nightMode ? "text-blue-300" : "text-blue-700")}>
          Carregando aventura...
        </p>
      </div>
    </div>
  )
}
