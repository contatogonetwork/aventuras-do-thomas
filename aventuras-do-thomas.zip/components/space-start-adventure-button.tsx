"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface SpaceStartAdventureButtonProps {
  onClick: () => void
  disabled?: boolean
}

export function SpaceStartAdventureButton({ onClick, disabled = false }: SpaceStartAdventureButtonProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="w-full max-w-md mx-auto"
    >
      <motion.button
        onClick={onClick}
        disabled={disabled}
        whileHover={!disabled ? { scale: 1.05 } : {}}
        whileTap={!disabled ? { scale: 0.95 } : {}}
        className={`
          relative w-full py-4 px-8 rounded-full 
          bg-gradient-to-r from-blue-500 to-indigo-600
          text-white text-xl font-bold
          shadow-lg shadow-blue-500/30
          transition-all duration-300
          flex items-center justify-center
          ${disabled ? "opacity-50 cursor-not-allowed" : "hover:shadow-xl hover:shadow-blue-500/40"}
        `}
      >
        <div className="absolute left-4 w-10 h-10">
          <Image src="/images/rocket.png" alt="Rocket" width={40} height={40} className="object-contain" />
        </div>
        COMEÇAR AVENTURA
        <div className="absolute right-4 w-10 h-10">
          <Image
            src="/images/rocket.png"
            alt="Rocket"
            width={40}
            height={40}
            className="object-contain transform rotate-180"
          />
        </div>
      </motion.button>
    </motion.div>
  )
}
