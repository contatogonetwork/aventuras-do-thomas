"use client"

import type React from "react"

import { useEffect, useState, useRef, useCallback } from "react"
import { useAudioParallax } from "@/hooks/use-audio-parallax"
import { cn } from "@/lib/utils"

interface ThemedParallaxBackgroundProps {
  children: React.ReactNode
  theme?: string
  intensity?: number
  playAmbient?: boolean
}

export function ThemedParallaxBackground({
  children,
  theme = "default",
  intensity = 1,
  playAmbient = true,
}: ThemedParallaxBackgroundProps) {
  const [mounted, setMounted] = useState(false)
  const { containerRef, nightMode } = useAudioParallax<HTMLDivElement>({
    sensitivity: intensity,
    theme,
  })

  // Tentar acessar o contexto de áudio
  const playAmbientSoundRef = useRef<(themeId: string) => boolean>(() => false)
  const stopAmbientRef = useRef<() => boolean>(() => false)
  const prevThemeRef = useRef<string>(theme)
  const ambientInitializedRef = useRef<boolean>(false)
  const audioContextReadyRef = useRef<boolean>(false)

  // Usar useCallback para garantir que as funções não sejam recriadas em cada renderização
  const initializeAudioContext = useCallback(() => {
    if (ambientInitializedRef.current || audioContextReadyRef.current) return

    try {
      // Importação dinâmica para evitar erros durante a renderização do servidor
      import("@/contexts/audio-context")
        .then((module) => {
          const { useAudio } = module
          try {
            const audio = useAudio()
            playAmbientSoundRef.current = audio.playAmbient
            stopAmbientRef.current = audio.stopAmbient
            audioContextReadyRef.current = true

            // Tocar som ambiente baseado no tema apenas na primeira vez
            if (playAmbient && theme && !ambientInitializedRef.current) {
              playAmbientSoundRef.current(theme)
              prevThemeRef.current = theme
              ambientInitializedRef.current = true
            }
          } catch (error) {
            console.warn("Contexto de áudio não disponível:", error)
          }
        })
        .catch((error) => {
          console.warn("Erro ao importar contexto de áudio:", error)
        })
    } catch (error) {
      console.warn("Erro ao importar contexto de áudio:", error)
    }
  }, [playAmbient, theme])

  useEffect(() => {
    setMounted(true)
    initializeAudioContext() // Inicializar o contexto de áudio

    return () => {
      // Parar som ambiente ao desmontar
      if (playAmbient && ambientInitializedRef.current) {
        stopAmbientRef.current()
      }
    }
  }, [initializeAudioContext, playAmbient])

  // Cores de fundo baseadas no tema
  const getBackgroundColor = () => {
    if (nightMode) return "bg-gray-900"

    switch (theme) {
      case "superhero":
        return "bg-red-100"
      case "space":
        return "bg-indigo-100"
      case "dinosaur":
        return "bg-green-100"
      case "pirate":
        return "bg-amber-100"
      case "castle":
        return "bg-purple-100"
      case "jungle":
        return "bg-emerald-100"
      case "ocean":
        return "bg-blue-100"
      case "farm":
        return "bg-yellow-100"
      default:
        return "bg-blue-50"
    }
  }

  // Elementos decorativos baseados no tema
  const renderThemeElements = () => {
    if (!mounted) return null

    switch (theme) {
      case "space":
        return (
          <>
            <div className="parallax-layer" data-depth="0.1">
              <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-indigo-300 opacity-30 blur-xl"></div>
              <div className="absolute bottom-20 right-20 w-32 h-32 rounded-full bg-purple-300 opacity-30 blur-xl"></div>
            </div>
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={`star-${i}`}
                className="absolute rounded-full bg-white"
                data-depth={`${0.05 + Math.random() * 0.1}`}
                style={{
                  width: `${Math.random() * 3 + 1}px`,
                  height: `${Math.random() * 3 + 1}px`,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  boxShadow: "0 0 5px 2px rgba(255, 255, 255, 0.3)",
                }}
              />
            ))}
          </>
        )
      case "ocean":
        return (
          <>
            <div className="parallax-layer" data-depth="0.05">
              <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-blue-200 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 h-60 bg-gradient-to-t from-blue-300 to-transparent"></div>
            </div>
            {Array.from({ length: 10 }).map((_, i) => (
              <div
                key={`bubble-${i}`}
                className="absolute rounded-full bg-white/30 backdrop-blur-sm"
                data-depth={`${0.1 + Math.random() * 0.2}`}
                style={{
                  width: `${Math.random() * 20 + 10}px`,
                  height: `${Math.random() * 20 + 10}px`,
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  border: "1px solid rgba(255, 255, 255, 0.5)",
                }}
              />
            ))}
          </>
        )
      case "jungle":
        return (
          <>
            <div className="parallax-layer" data-depth="0.05">
              <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-green-200/50 to-transparent"></div>
            </div>
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={`leaf-${i}`}
                className="absolute text-3xl"
                data-depth={`${0.1 + Math.random() * 0.15}`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
              >
                {["🍃", "🌿", "🌱", "🍂"][Math.floor(Math.random() * 4)]}
              </div>
            ))}
          </>
        )
      case "dinosaur":
        return (
          <>
            <div className="parallax-layer" data-depth="0.05">
              <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-green-300/30 to-transparent"></div>
            </div>
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={`footprint-${i}`}
                className="absolute text-4xl opacity-20"
                data-depth={`${0.08 + Math.random() * 0.1}`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  transform: `rotate(${Math.random() * 360}deg)`,
                }}
              >
                👣
              </div>
            ))}
          </>
        )
      case "castle":
        return (
          <>
            <div className="parallax-layer" data-depth="0.05">
              <div className="absolute top-0 left-0 right-0 h-60 bg-gradient-to-b from-purple-200/30 to-transparent"></div>
            </div>
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={`sparkle-${i}`}
                className="absolute text-xl"
                data-depth={`${0.1 + Math.random() * 0.2}`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
              >
                ✨
              </div>
            ))}
          </>
        )
      case "pirate":
        return (
          <>
            <div className="parallax-layer" data-depth="0.05">
              <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-amber-300/30 to-transparent"></div>
            </div>
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={`wave-${i}`}
                className="absolute text-2xl"
                data-depth={`${0.08 + Math.random() * 0.12}`}
                style={{
                  left: `${Math.random() * 100}%`,
                  bottom: `${Math.random() * 30}%`,
                }}
              >
                {["🌊", "⚓", "🏝️"][Math.floor(Math.random() * 3)]}
              </div>
            ))}
          </>
        )
      case "farm":
        return (
          <>
            <div className="parallax-layer" data-depth="0.05">
              <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-yellow-200/30 to-transparent"></div>
            </div>
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={`farm-${i}`}
                className="absolute text-2xl"
                data-depth={`${0.1 + Math.random() * 0.15}`}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                }}
              >
                {["🌾", "🌻", "🍎", "🥕"][Math.floor(Math.random() * 4)]}
              </div>
            ))}
          </>
        )
      default:
        return (
          <div className="parallax-layer" data-depth="0.1">
            <div className="absolute top-0 left-0 w-32 h-32 rounded-full bg-blue-300 blur-3xl transform -translate-x-1/2 -translate-y-1/2 opacity-20"></div>
            <div className="absolute top-1/4 right-0 w-64 h-64 rounded-full bg-purple-300 blur-3xl transform translate-x-1/2 opacity-20"></div>
            <div className="absolute bottom-0 left-1/3 w-48 h-48 rounded-full bg-pink-300 blur-3xl transform -translate-y-1/2 opacity-20"></div>
          </div>
        )
    }
  }

  return (
    <div
      ref={containerRef}
      className={cn(
        "min-h-screen w-full overflow-hidden transition-colors duration-500",
        getBackgroundColor(),
        nightMode ? "text-white" : "text-gray-900",
      )}
    >
      {/* Elementos de fundo com efeito parallax */}
      {renderThemeElements()}

      {/* Conteúdo */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen">{children}</div>
    </div>
  )
}
