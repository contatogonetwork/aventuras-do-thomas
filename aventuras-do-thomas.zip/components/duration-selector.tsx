"use client"

import { useState } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { useAudio } from "@/contexts/audio-context"
import { motion } from "framer-motion"
import { useAppContext } from "@/contexts/app-context"

interface DurationSelectorProps {
  selectedDuration: string | null
  onSelectDuration: (duration: string) => void
}

export function DurationSelector({ selectedDuration, onSelectDuration }: DurationSelectorProps) {
  const { playEffect } = useAudio()
  const [hovering, setHovering] = useState(false)
  const { nightMode } = useAppContext()

  return (
    <div className="w-full max-w-md mx-auto mb-8">
      <h2 className={cn("text-xl font-bold text-center mb-3", nightMode ? "text-blue-300" : "text-blue-800")}>
        Escolha a duração:
      </h2>
      <motion.div
        className="relative w-full h-20 cursor-pointer"
        whileHover={{ scale: 1.03 }}
        onMouseEnter={() => setHovering(true)}
        onMouseLeave={() => setHovering(false)}
      >
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/curta_longa-4R4hdmoQOiXVkUfuPo4iTqkLJTW2YR.png"
          alt="Selecionar duração: Curta ou Longa"
          width={400}
          height={100}
          className={cn("w-full h-auto object-contain", nightMode ? "brightness-90 contrast-125" : "")}
        />

        {/* Overlay para área clicável esquerda (CURTA) */}
        <div
          className={cn(
            "absolute left-0 top-0 w-1/2 h-full transition-all duration-300",
            selectedDuration === "short"
              ? nightMode
                ? "bg-teal-600/20"
                : "bg-teal-400/20"
              : hovering
                ? nightMode
                  ? "bg-white/5"
                  : "bg-white/10"
                : "",
            "rounded-l-full",
          )}
          onClick={() => {
            onSelectDuration("short")
            playEffect("duration_select")
          }}
        />

        {/* Overlay para área clicável direita (LONGA) */}
        <div
          className={cn(
            "absolute right-0 top-0 w-1/2 h-full transition-all duration-300",
            selectedDuration === "long"
              ? nightMode
                ? "bg-blue-600/20"
                : "bg-blue-500/20"
              : hovering
                ? nightMode
                  ? "bg-white/5"
                  : "bg-white/10"
                : "",
            "rounded-r-full",
          )}
          onClick={() => {
            onSelectDuration("long")
            playEffect("duration_select")
          }}
        />

        {/* Indicador de seleção */}
        {selectedDuration && (
          <motion.div
            className={cn("absolute top-0 h-full w-1/2", selectedDuration === "short" ? "left-0" : "right-0")}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div
              className={cn(
                "absolute inset-0 border-4 rounded-full opacity-70",
                nightMode ? "border-yellow-500" : "border-yellow-400",
              )}
            ></div>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}
