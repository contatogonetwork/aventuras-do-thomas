"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { cn } from "@/lib/utils"
import { applyParallaxEffect } from "@/lib/parallax"

interface ParallaxBackgroundProps {
  children: React.ReactNode
  theme?: string
  nightMode?: boolean
}

export function ParallaxBackground({ children, theme = "default", nightMode = false }: ParallaxBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [mounted, setMounted] = useState(false)

  // Cores de fundo baseadas no tema
  const getBackgroundColor = () => {
    if (nightMode) return "bg-gray-900"

    switch (theme) {
      case "superhero":
        return "bg-blue-100"
      case "space":
        return "bg-indigo-100"
      case "dinosaur":
        return "bg-green-100"
      case "pirate":
        return "bg-cyan-100"
      case "castle":
        return "bg-purple-100"
      case "jungle":
        return "bg-emerald-100"
      case "ocean":
        return "bg-sky-100"
      case "farm":
        return "bg-amber-100"
      default:
        return "bg-blue-50"
    }
  }

  // Inicializar efeito de parallax após montagem
  useEffect(() => {
    setMounted(true)

    if (containerRef.current) {
      const cleanup = applyParallaxEffect(containerRef.current)
      return cleanup
    }
  }, [])

  return (
    <div
      ref={containerRef}
      className={cn(
        "min-h-screen w-full overflow-hidden transition-colors duration-500",
        getBackgroundColor(),
        nightMode ? "text-white" : "text-gray-900",
      )}
    >
      {/* Elementos de fundo com efeito parallax */}
      <div className="parallax-layer" data-depth="0.1" style={{ opacity: mounted ? 0.2 : 0 }}>
        <div className="absolute top-0 left-0 w-32 h-32 rounded-full bg-blue-300 blur-3xl transform -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute top-1/4 right-0 w-64 h-64 rounded-full bg-purple-300 blur-3xl transform translate-x-1/2"></div>
        <div className="absolute bottom-0 left-1/3 w-48 h-48 rounded-full bg-pink-300 blur-3xl transform -translate-y-1/2"></div>
      </div>

      {/* Conteúdo */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen">{children}</div>
    </div>
  )
}
