"use client"

import { useEffect, useRef, useState } from "react"
import { applyParallaxEffect } from "@/lib/parallax"

interface ParallaxOptions {
  enabled?: boolean
  mobileEnabled?: boolean
  sensitivity?: number
}

export function useParallax<T extends HTMLElement>(options: ParallaxOptions = {}) {
  const { enabled = true, mobileEnabled = false, sensitivity = 1 } = options

  const containerRef = useRef<T>(null)
  const [isMobile, setIsMobile] = useState(false)

  // Detectar dispositivo móvel
  useEffect(() => {
    const checkMobile = () => {
      const mobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
      setIsMobile(mobile)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)

    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  // Aplicar efeito de parallax
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    // Não aplicar em dispositivos móveis se não estiver habilitado
    if (isMobile && !mobileEnabled) return

    // Aplicar efeito com sensibilidade personalizada
    const originalElements = container.querySelectorAll("[data-depth]")

    // Ajustar a sensibilidade
    originalElements.forEach((element) => {
      const originalDepth = Number.parseFloat(element.getAttribute("data-depth") || "0.1")
      element.setAttribute("data-depth", String(originalDepth * sensitivity))
    })

    // Aplicar o efeito
    if (enabled) {
      const cleanup = applyParallaxEffect(container)
      return cleanup
    }
  }, [enabled, isMobile, mobileEnabled, sensitivity])

  return { containerRef, isMobile }
}
