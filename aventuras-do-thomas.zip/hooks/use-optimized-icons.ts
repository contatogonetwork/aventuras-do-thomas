"use client"

import { useState, useEffect } from "react"
import type { Theme } from "@/types/app-types"

export function useOptimizedIcons() {
  const [iconsLoaded, setIconsLoaded] = useState(false)
  const [animatingIcons, setAnimatingIcons] = useState(false)

  // Temas disponíveis
  const themes: Theme[] = [
    {
      id: "space",
      name: "Espaço",
      icon: "/icons/space.png",
      color: "from-indigo-500 to-purple-700",
      blurDataURL:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FAP5FDvcfRYWgAAAAAElFTkSuQmCC",
    },
    {
      id: "ocean",
      name: "Oceano",
      icon: "/icons/ocean.png",
      color: "from-blue-400 to-blue-700",
      blurDataURL:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FAP5FDvcfRYWgAAAAAElFTkSuQmCC",
    },
    {
      id: "dinosaur",
      name: "Dinossauros",
      icon: "/icons/dinosaur.png",
      color: "from-green-500 to-green-700",
      blurDataURL:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FAP5FDvcfRYWgAAAAAElFTkSuQmCC",
    },
    {
      id: "pirate",
      name: "Piratas",
      icon: "/icons/pirate.png",
      color: "from-amber-500 to-orange-600",
      blurDataURL:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FAP5FDvcfRYWgAAAAAElFTkSuQmCC",
    },
    {
      id: "castle",
      name: "Castelo",
      icon: "/icons/castle.png",
      color: "from-purple-400 to-purple-700",
      blurDataURL:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FAP5FDvcfRYWgAAAAAElFTkSuQmCC",
    },
    {
      id: "jungle",
      name: "Selva",
      icon: "/icons/jungle.png",
      color: "from-emerald-400 to-emerald-700",
      blurDataURL:
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAFUlEQVR42mNkYPhfz0AEYBxVSF+FAP5FDvcfRYWgAAAAAElFTkSuQmCC",
    },
  ]

  useEffect(() => {
    // Simular carregamento de ícones
    const timer = setTimeout(() => {
      setIconsLoaded(true)
      setAnimatingIcons(true)

      // Desativar animação após um tempo
      const animTimer = setTimeout(() => {
        setAnimatingIcons(false)
      }, 1500)

      return () => clearTimeout(animTimer)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  return { themes, iconsLoaded, animatingIcons }
}
