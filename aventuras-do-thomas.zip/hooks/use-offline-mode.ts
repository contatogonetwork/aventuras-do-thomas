"use client"

import { useState, useEffect, useCallback } from "react"

interface OfflineModeState {
  isOffline: boolean
  isInitialized: boolean
  swRegistered: boolean
}

export function useOfflineMode() {
  const [state, setState] = useState<OfflineModeState>({
    isOffline: false,
    isInitialized: false,
    swRegistered: false,
  })
  const [swRegistered, setSwRegistered] = useState(false)

  // Inicializar o estado offline
  useEffect(() => {
    // Verificar se o navegador está online ou offline
    const isCurrentlyOffline = typeof navigator !== "undefined" && !navigator.onLine

    setState((prev) => ({
      ...prev,
      isOffline: isCurrentlyOffline,
      isInitialized: true,
    }))

    // Registrar o service worker se disponível
    if (typeof navigator !== "undefined" && "serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js")
        .then((registration) => {
          console.log("Service Worker registrado com sucesso:", registration)
          setSwRegistered(true)
        })
        .catch((error) => {
          console.error("Erro ao registrar Service Worker:", error)
        })
    }

    // Adicionar event listeners para mudanças de conectividade
    const handleOffline = () => {
      console.log("Dispositivo está offline")
      setState((prev) => ({ ...prev, isOffline: true }))
    }

    const handleOnline = () => {
      console.log("Dispositivo está online")
      setState((prev) => ({ ...prev, isOffline: false }))
    }

    window.addEventListener("offline", handleOffline)
    window.addEventListener("online", handleOnline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  // Função para pré-cachear recursos de áudio
  const cacheAudioResources = useCallback((audioUrls: string[]) => {
    if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: "CACHE_AUDIO",
        urls: audioUrls,
      })
    }
  }, [])

  // Função para salvar uma história para acesso offline
  const saveStoryOffline = useCallback((story: any) => {
    try {
      // Obter histórias salvas anteriormente
      const savedStories = JSON.parse(localStorage.getItem("savedStories") || "[]")

      // Verificar se a história já existe
      const existingIndex = savedStories.findIndex((s: any) => s.id === story.id)

      if (existingIndex >= 0) {
        // Atualizar história existente
        savedStories[existingIndex] = story
      } else {
        // Adicionar nova história
        savedStories.push(story)
      }

      // Salvar no localStorage
      localStorage.setItem("savedStories", JSON.stringify(savedStories))

      return true
    } catch (error) {
      console.error("Erro ao salvar história offline:", error)
      return false
    }
  }, [])

  // Função para carregar histórias salvas offline
  const loadOfflineStories = useCallback(() => {
    try {
      const savedStories = JSON.parse(localStorage.getItem("savedStories") || "[]")
      return savedStories
    } catch (error) {
      console.error("Erro ao carregar histórias offline:", error)
      return []
    }
  }, [])

  return {
    ...state,
    cacheAudioResources,
    saveStoryOffline,
    loadOfflineStories,
    swRegistered,
  }
}
