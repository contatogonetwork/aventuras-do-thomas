"use client"

import { useEffect, useRef, useState } from "react"
import { applyParallaxEffect } from "@/lib/parallax"

interface AudioParallaxOptions {
  enabled?: boolean
  mobileEnabled?: boolean
  sensitivity?: number
  soundEffects?: boolean
  soundMapping?: Record<string, string>
  theme?: string
}

export function useAudioParallax<T extends HTMLElement>(options: AudioParallaxOptions = {}) {
  const {
    enabled = true,
    mobileEnabled = false,
    sensitivity = 1,
    soundEffects = true,
    soundMapping = {},
    theme,
  } = options

  const containerRef = useRef<T>(null)
  const [isMobile, setIsMobile] = useState(false)
  const [lastInteractedElement, setLastInteractedElement] = useState<string | null>(null)
  const interactionTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const [nightMode, setNightMode] = useState(false)
  const [playEffect, setPlayEffect] = useState<(effectId: string) => boolean>(() => false)

  // Tentar acessar o contexto de áudio e app
  useEffect(() => {
    let mounted = true // Flag to prevent state updates on unmounted component

    const loadContexts = async () => {
      try {
        // Importação dinâmica para evitar erros durante a renderização do servidor
        const { useAudio } = require("@/contexts/audio-context")
        const { useAppContext } = require("@/contexts/app-context")

        try {
          const audio = useAudio()
          if (mounted) {
            setPlayEffect(() => audio.playEffect)
          }
        } catch (error) {
          console.warn("Contexto de áudio não disponível:", error)
        }

        try {
          const appContext = useAppContext()
          if (mounted && appContext && appContext.nightMode !== undefined) {
            setNightMode(appContext.nightMode)
          }
        } catch (error) {
          console.warn("Contexto de app não disponível:", error)
        }
      } catch (error) {
        console.warn("Erro ao importar contextos:", error)
      }
    }

    loadContexts()

    return () => {
      mounted = false // Set flag to false when component unmounts
    }
  }, [])

  // Detectar dispositivo móvel
  useEffect(() => {
    const checkMobile = () => {
      const mobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
      setIsMobile(mobile)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)

    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  // Aplicar efeito de parallax com sons
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    // Não aplicar em dispositivos móveis se não estiver habilitado
    if (isMobile && !mobileEnabled) return

    // Aplicar efeito com sensibilidade personalizada
    const originalElements = container.querySelectorAll("[data-depth]")

    // Ajustar a sensibilidade
    originalElements.forEach((element) => {
      const originalDepth = Number.parseFloat(element.getAttribute("data-depth") || "0.1")
      element.setAttribute("data-depth", String(originalDepth * sensitivity))

      // Adicionar atributo de som se o elemento tiver um
      const elementId = element.getAttribute("id")
      if (elementId && soundMapping[elementId]) {
        element.setAttribute("data-sound", soundMapping[elementId])
      }
    })

    // Aplicar o efeito de parallax
    if (enabled) {
      const cleanup = applyParallaxEffect(container)

      // Adicionar eventos para sons de interação
      if (soundEffects) {
        const handleElementInteraction = (e: MouseEvent) => {
          const target = e.target as HTMLElement
          const closestParallaxElement = target.closest("[data-depth]") as HTMLElement

          if (closestParallaxElement) {
            const elementId = closestParallaxElement.id
            const soundId = closestParallaxElement.getAttribute("data-sound")

            // Evitar tocar o mesmo som repetidamente em um curto período
            if (elementId && elementId !== lastInteractedElement) {
              setLastInteractedElement(elementId)

              // Limpar timeout anterior se existir
              if (interactionTimeoutRef.current) {
                clearTimeout(interactionTimeoutRef.current)
              }

              // Definir um timeout para permitir nova interação com o mesmo elemento
              interactionTimeoutRef.current = setTimeout(() => {
                setLastInteractedElement(null)
              }, 1000)

              // Tocar som específico se definido, ou som padrão baseado no tema
              if (soundId) {
                playEffect(soundId)
              } else if (theme) {
                // Tocar som baseado no tema atual
                const themeSound = `hover_${theme}`
                playEffect(themeSound)
              }
            }
          }
        }

        container.addEventListener("mouseover", handleElementInteraction)

        return () => {
          cleanup()
          container.removeEventListener("mouseover", handleElementInteraction)
          if (interactionTimeoutRef.current) {
            clearTimeout(interactionTimeoutRef.current)
          }
        }
      }

      return cleanup
    }
  }, [
    enabled,
    isMobile,
    mobileEnabled,
    sensitivity,
    soundEffects,
    theme,
    lastInteractedElement,
    soundMapping,
    playEffect,
  ])

  return { containerRef, isMobile, nightMode }
}
