"use client"

import { useState, useEffect } from "react"

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void, boolean] {
  const [storedValue, setStoredValue] = useState<T>(initialValue)
  const [isStorageAvailable, setIsStorageAvailable] = useState(false)

  useEffect(() => {
    try {
      // Verificar se o localStorage está disponível
      const testKey = "__test__"
      localStorage.setItem(testKey, testKey)
      localStorage.removeItem(testKey)
      setIsStorageAvailable(true)

      // Tentar obter o valor do localStorage
      const item = localStorage.getItem(key)
      if (item) {
        setStoredValue(JSON.parse(item))
      }
    } catch (error) {
      console.warn("localStorage não está disponível:", error)
      setIsStorageAvailable(false)
    }
  }, [key])

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      // Permitir que o valor seja uma função para seguir o mesmo padrão do useState
      const valueToStore = value instanceof Function ? value(storedValue) : value
      setStoredValue(valueToStore)

      // Salvar no localStorage se disponível
      if (isStorageAvailable) {
        localStorage.setItem(key, JSON.stringify(valueToStore))
      }
    } catch (error) {
      console.warn("Erro ao salvar no localStorage:", error)
    }
  }

  return [storedValue, setValue, isStorageAvailable]
}
